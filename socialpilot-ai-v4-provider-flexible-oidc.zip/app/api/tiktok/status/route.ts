import { NextRequest, NextResponse } from "next/server";
import { cookieName, open } from "../../../../lib/connection";
export const runtime = "nodejs";
export async function GET(req: NextRequest) {
  const publishId = req.nextUrl.searchParams.get("publishId");
  const raw = req.cookies.get(cookieName("tiktok"))?.value;
  if (!publishId || !raw) return NextResponse.json({ error: "Missing publishId or TikTok connection" }, { status: 400 });
  try {
    const c: any = open(raw);
    const r = await fetch("https://open.tiktokapis.com/v2/post/publish/status/fetch/", { method: "POST", headers: { Authorization: `Bearer ${c.accessToken}`, "Content-Type": "application/json" }, body: JSON.stringify({ publish_id: publishId }), cache: "no-store" });
    const data = await r.json(); return NextResponse.json(data, { status: r.status });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Status check failed" }, { status: 500 }); }
}
