import { NextRequest, NextResponse } from "next/server";
import { cookieName, open } from "../../../../lib/connection";
export const runtime = "nodejs";
export async function GET(req: NextRequest) {
  const raw = req.cookies.get(cookieName("tiktok"))?.value;
  if (!raw) return NextResponse.json({ error: "TikTok is not connected" }, { status: 401 });
  try {
    const c: any = open(raw);
    const r = await fetch("https://open.tiktokapis.com/v2/post/publish/creator_info/query/", { method: "POST", headers: { Authorization: `Bearer ${c.accessToken}`, "Content-Type": "application/json" }, body: "{}", cache: "no-store" });
    const data = await r.json();
    return NextResponse.json(data, { status: r.status });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Creator lookup failed" }, { status: 500 }); }
}
