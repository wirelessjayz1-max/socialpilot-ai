import { NextRequest, NextResponse } from "next/server";
import { cookieName, seal } from "../../../../../lib/connection";

export const runtime = "nodejs";

async function tokenRequest(url: string, body: URLSearchParams) {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body, cache: "no-store" });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error_description || data.error?.message || "Token exchange failed");
  return data;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ platform: string }> }) {
  const { platform } = await params;
  const code = req.nextUrl.searchParams.get("code");
  const state = req.nextUrl.searchParams.get("state");
  const savedRaw = req.cookies.get(`sp_oauth_state_${platform}`)?.value;
  if (!code || !savedRaw) return NextResponse.redirect(new URL("/?accounts=error&message=Missing OAuth response", req.url));
  let saved: { state: string; redirect: string };
  try { saved = JSON.parse(savedRaw); } catch { return NextResponse.redirect(new URL("/?accounts=error&message=Invalid OAuth state", req.url)); }
  if (platform !== "instagram" && state !== saved.state) return NextResponse.redirect(new URL("/?accounts=error&message=OAuth state mismatch", req.url));

  try {
    let connection: any;
    if (platform === "tiktok") {
      const body = new URLSearchParams({ client_key: process.env.TIKTOK_CLIENT_KEY || "", client_secret: process.env.TIKTOK_CLIENT_SECRET || "", code, grant_type: "authorization_code", redirect_uri: saved.redirect });
      const token = await tokenRequest("https://open.tiktokapis.com/v2/oauth/token/", body);
      const profileRes = await fetch("https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url,profile_deep_link", { headers: { Authorization: `Bearer ${token.access_token}` }, cache: "no-store" });
      const profile = await profileRes.json();
      connection = { platform, accessToken: token.access_token, refreshToken: token.refresh_token, expiresAt: Date.now() + token.expires_in * 1000, profile: profile.data?.user || {} };
    } else if (platform === "youtube") {
      const body = new URLSearchParams({ client_id: process.env.YOUTUBE_CLIENT_ID || "", client_secret: process.env.YOUTUBE_CLIENT_SECRET || "", code, grant_type: "authorization_code", redirect_uri: saved.redirect });
      const token = await tokenRequest("https://oauth2.googleapis.com/token", body);
      const ch = await fetch("https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true", { headers: { Authorization: `Bearer ${token.access_token}` }, cache: "no-store" });
      const channel = await ch.json();
      connection = { platform, accessToken: token.access_token, refreshToken: token.refresh_token, expiresAt: Date.now() + (token.expires_in || 3600) * 1000, profile: channel.items?.[0] || {} };
    } else if (platform === "instagram") {
      const version = process.env.META_GRAPH_VERSION || "v24.0";
      const body = new URLSearchParams({ client_id: process.env.META_APP_ID || "", client_secret: process.env.META_APP_SECRET || "", redirect_uri: saved.redirect, code });
      const token = await tokenRequest(`https://graph.facebook.com/${version}/oauth/access_token`, body);
      const profileRes = await fetch(`https://graph.facebook.com/${version}/me?fields=id,name&access_token=${encodeURIComponent(token.access_token)}`, { cache: "no-store" });
      const profile = await profileRes.json();
      connection = { platform, accessToken: token.access_token, expiresAt: Date.now() + (token.expires_in || 3600) * 1000, profile };
    } else throw new Error("Unsupported platform");

    const response = NextResponse.redirect(new URL("/?accounts=connected", req.url));
    response.cookies.set(cookieName(platform), seal(connection), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", maxAge: 60 * 60 * 24 * 30, path: "/" });
    response.cookies.delete(`sp_oauth_state_${platform}`);
    return response;
  } catch (e) {
    const message = e instanceof Error ? e.message : "OAuth connection failed";
    return NextResponse.redirect(new URL(`/?accounts=error&message=${encodeURIComponent(message)}`, req.url));
  }
}
