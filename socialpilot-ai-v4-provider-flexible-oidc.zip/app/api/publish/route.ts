import { NextRequest, NextResponse } from "next/server";
import { cookieName, open } from "../../../lib/connection";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const { platform, videoUrl, caption = "", title = "", privacyLevel, allowComment = false, allowDuet = false, allowStitch = false } = body || {};
  if (!platform || !videoUrl) return NextResponse.json({ error: "platform and videoUrl are required" }, { status: 400 });
  const raw = req.cookies.get(cookieName(platform))?.value;
  if (!raw) return NextResponse.json({ error: `${platform} is not connected` }, { status: 401 });
  try {
    const c: any = open(raw);
    if (platform === "tiktok") {
      const creatorR = await fetch("https://open.tiktokapis.com/v2/post/publish/creator_info/query/", { method: "POST", headers: { Authorization: `Bearer ${c.accessToken}`, "Content-Type": "application/json" }, body: "{}", cache: "no-store" });
      const creator = await creatorR.json();
      const options = creator.data?.privacy_level_options || [];
      if (!privacyLevel || !options.includes(privacyLevel)) return NextResponse.json({ error: "Choose a valid TikTok privacy level from the connected creator's available options." }, { status: 400 });
      const r = await fetch("https://open.tiktokapis.com/v2/post/publish/video/init/", { method: "POST", headers: { Authorization: `Bearer ${c.accessToken}`, "Content-Type": "application/json" }, body: JSON.stringify({ post_info: { title: caption, privacy_level: privacyLevel, disable_comment: !allowComment, disable_duet: !allowDuet, disable_stitch: !allowStitch, is_aigc: true }, source_info: { source: "PULL_FROM_URL", video_url: videoUrl } }), cache: "no-store" });
      const data = await r.json(); return NextResponse.json(data, { status: r.status });
    }
    if (platform === "instagram") {
      const version = process.env.META_GRAPH_VERSION || "v24.0";
      const igUserId = c.profile?.id || c.profile?.user_id;
      if (!igUserId) return NextResponse.json({ error: "Instagram account ID was not returned during OAuth. Reconnect the account." }, { status: 400 });
      const params = new URLSearchParams({ media_type: "REELS", video_url: videoUrl, caption, access_token: c.accessToken });
      const create = await fetch(`https://graph.facebook.com/${version}/${igUserId}/media`, { method: "POST", body: params, cache: "no-store" });
      const container = await create.json(); if (!create.ok) return NextResponse.json(container, { status: create.status });
      const publish = await fetch(`https://graph.facebook.com/${version}/${igUserId}/media_publish`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ creation_id: container.id, access_token: c.accessToken }), cache: "no-store" });
      const result = await publish.json(); return NextResponse.json({ containerId: container.id, ...result }, { status: publish.status });
    }
    if (platform === "youtube") {
      const media = await fetch(videoUrl, { cache: "no-store" });
      if (!media.ok) return NextResponse.json({ error: "Could not fetch generated video for YouTube upload" }, { status: 502 });
      const bytes = await media.arrayBuffer();
      const metadata = { snippet: { title: title || caption.slice(0, 100) || "SocialPilot AI video", description: caption, tags: caption.match(/#[A-Za-z0-9_]+/g)?.map((x: string) => x.slice(1)) || [], categoryId: "22" }, status: { privacyStatus: "private", containsSyntheticMedia: true } };
      const init = await fetch("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status", { method: "POST", headers: { Authorization: `Bearer ${c.accessToken}`, "Content-Type": "application/json; charset=UTF-8", "X-Upload-Content-Type": media.headers.get("content-type") || "video/mp4", "X-Upload-Content-Length": String(bytes.byteLength) }, body: JSON.stringify(metadata), cache: "no-store" });
      if (!init.ok) return NextResponse.json(await init.json().catch(() => ({ error: "YouTube upload initialization failed" })), { status: init.status });
      const uploadUrl = init.headers.get("location"); if (!uploadUrl) return NextResponse.json({ error: "YouTube did not return an upload URL" }, { status: 502 });
      const upload = await fetch(uploadUrl, { method: "PUT", headers: { Authorization: `Bearer ${c.accessToken}`, "Content-Type": media.headers.get("content-type") || "video/mp4", "Content-Length": String(bytes.byteLength) }, body: bytes, cache: "no-store" });
      const result = await upload.json().catch(() => ({})); return NextResponse.json(result, { status: upload.status });
    }
    return NextResponse.json({ error: "Unsupported platform" }, { status: 400 });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Publish failed" }, { status: 500 }); }
}
