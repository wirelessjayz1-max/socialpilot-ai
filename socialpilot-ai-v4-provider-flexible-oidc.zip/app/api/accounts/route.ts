import { NextRequest, NextResponse } from "next/server";
import { cookieName, open } from "../../../lib/connection";
export const runtime = "nodejs";
export async function GET(req: NextRequest) {
  const platforms = ["tiktok", "instagram", "youtube"];
  const accounts = platforms.map(platform => {
    const raw = req.cookies.get(cookieName(platform))?.value;
    if (!raw) return { platform, connected: false };
    try { const c: any = open(raw); return { platform, connected: true, profile: c.profile || {} }; }
    catch { return { platform, connected: false }; }
  });
  return NextResponse.json({ accounts });
}
