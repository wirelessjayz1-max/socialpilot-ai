import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
    const key = process.env.HEYGEN_API_KEY;
    const videoId = new URL(req.url).searchParams.get("videoId");
    if (!key) return NextResponse.json({ error: "HEYGEN_API_KEY is not configured in Vercel." }, { status: 500 });
    if (!videoId) return NextResponse.json({ error: "videoId is required." }, { status: 400 });
    const response = await fetch(`https://api.heygen.com/v3/videos/${encodeURIComponent(videoId)}`, { headers: { "X-Api-Key": key }, cache: "no-store" });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data?.error || "Could not retrieve video status." }, { status: response.status });
    const v = data?.data || {};
    return NextResponse.json({ videoId, status: v.status || "processing", videoUrl: v.video_url || v.videoUrl || null, error: v.failure_reason || v.error || null });
  } catch (error) {
    console.error("Video status error", error);
    return NextResponse.json({ error: "Video status check failed." }, { status: 500 });
  }
}
