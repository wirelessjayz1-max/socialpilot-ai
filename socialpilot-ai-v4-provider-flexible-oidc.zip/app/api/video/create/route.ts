import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const key = process.env.HEYGEN_API_KEY;
    if (!key) return NextResponse.json({ error: "HEYGEN_API_KEY is not configured in Vercel yet." }, { status: 500 });
    const body = await req.json();
    const script = String(body.script || "").trim();
    if (!script) return NextResponse.json({ error: "Generate the content package first." }, { status: 400 });
    const visualPlan = Array.isArray(body.visualPlan) ? body.visualPlan.join("; ") : "";
    const prompt = `Create a polished short-form social video for ${body.platform || "TikTok / Reels / Shorts"}. Title: ${body.title || "Social video"}. Hook: ${body.hook || ""}. Spoken script: ${script}. Visual direction: ${visualPlan}. Use portrait orientation, fast pacing, strong on-screen captions, clean modern visuals, and a clear ending. Make it feel native to short-form social media.`;
    const response = await fetch("https://api.heygen.com/v3/video-agents", {
      method: "POST", headers: { "Content-Type": "application/json", "X-Api-Key": key },
      body: JSON.stringify({ prompt, mode: "generate", orientation: "portrait", incognito_mode: true }),
      cache: "no-store"
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data?.error || "HeyGen could not start the video." }, { status: response.status });
    return NextResponse.json({ videoId: data?.data?.video_id, sessionId: data?.data?.session_id, status: "processing" });
  } catch (error) {
    console.error("Video creation error", error);
    return NextResponse.json({ error: "Video creation failed. Check your Vercel logs." }, { status: 500 });
  }
}
