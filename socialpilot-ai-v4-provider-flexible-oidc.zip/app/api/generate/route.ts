import { generateObject } from 'ai';
import { NextResponse } from 'next/server';
import { z } from 'zod';

export const runtime = 'nodejs';

const socialContentSchema = z.object({
  title: z.string(),
  hook: z.string(),
  script: z.string(),
  caption: z.string(),
  hashtags: z.array(z.string()),
  callToAction: z.string(),
  visualPlan: z.array(z.string())
});

function getModels() {
  const primary = process.env.AI_MODEL || 'google/gemini-2.5-flash-lite';
  const fallback = (process.env.AI_FALLBACK_MODELS || 'google/gemini-2.5-flash,openai/gpt-5.6-luna,anthropic/claude-sonnet-4.6')
    .split(',')
    .map((model) => model.trim())
    .filter(Boolean);
  return Array.from(new Set([primary, ...fallback]));
}

function friendlyError(error: any, models: string[]) {
  const status = Number(error?.status) || Number(error?.cause?.status) || 500;
  const message = String(error?.message || error?.cause?.message || 'AI generation failed.');
  if (status === 401) {
    return { status: 401, message: 'Vercel AI Gateway authentication failed. This deployment is configured to use Vercel OIDC in production. If you are testing locally, set AI_GATEWAY_API_KEY.' };
  }
  if (status === 402 || status === 429) {
    return { status, message: `AI Gateway could not complete the request because of credits, billing, or rate limits. Models attempted: ${models.join(', ')}.` };
  }
  if (status === 403) {
    return { status: 403, message: 'Vercel AI Gateway denied the request. Check that AI Gateway is enabled for this Vercel project and that the selected model is available.' };
  }
  return { status: status >= 400 && status < 600 ? status : 500, message: `AI generation failed: ${message}` };
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const idea = String(body.idea || '').trim();
    const platform = String(body.platform || 'TikTok / Reels / Shorts');
    const tone = String(body.tone || 'high-energy');

    if (!idea) return NextResponse.json({ error: 'Tell the AI what you want the video to be about.' }, { status: 400 });
    if (idea.length > 1200) return NextResponse.json({ error: 'Keep the idea under 1,200 characters.' }, { status: 400 });

    const models = getModels();
    const primary = models[0];
    const fallbacks = models.slice(1);

    const result = await generateObject({
      model: primary,
      schema: socialContentSchema,
      system: `You are SocialPilot AI, an expert short-form content strategist. Create original, platform-native content designed to earn attention without making fake guarantees. Write naturally, avoid generic filler, and make every line useful. The user wants content for ${platform} in a ${tone} tone. Keep the spoken script under 140 words. The visual plan should contain 5-7 simple shot ideas.`,
      prompt: `Create a complete short-form video package from this idea:\n\n${idea}`,
      providerOptions: {
        gateway: {
          models: fallbacks
        }
      }
    });

    return NextResponse.json({
      ...result.object,
      aiModel: primary,
      aiProvider: primary.split('/')[0]
    });
  } catch (error: any) {
    console.error('SocialPilot AI generation error:', error);
    const models = getModels();
    const friendly = friendlyError(error, models);
    return NextResponse.json({ error: friendly.message }, { status: friendly.status });
  }
}
