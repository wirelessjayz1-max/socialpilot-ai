# DRAIG V8 — Account Launch + Social Execution

V8 keeps the stable V3 cloud-isolation fix, the V6 Execution Engine, and V7 official social execution, then adds an Account Launch Assistant for starting new social brands safely.

## What V8 adds
- New **Launch Accounts** workspace
- AI-generated brand name, niche positioning, audience, and display name
- 5–12 username/handle ideas without false availability claims
- Paste-ready TikTok and Instagram bios plus YouTube channel description
- Profile-image and banner prompts
- Platform-specific launch checklist with human-required steps clearly labeled
- Progress tracking for signup/setup steps, synced to Neon
- Official signup links for TikTok, Instagram, and YouTube
- Seven-post launch-week content plan
- One-tap handoff from a launch-plan post into the existing content generator
- One-tap handoff from completed signup to the V7 official account connector

## Human-only account creation guardrails
Social Pilot does **not** enter passwords, verification codes, CAPTCHAs, identity documents, payment details, or accept platform terms on the user's behalf. Platforms may require age, phone/email, identity, business, or developer-app verification. V8 prepares everything around those steps and tracks progress, but the user completes the protected signup actions.

## Existing V7 social execution
- TikTok OAuth + Direct Post using the official Content Posting API
- TikTok creator-info validation, disclosure controls, token refresh, and status checks
- Instagram OAuth + Reels publishing
- Instagram Inbox for approval-gated replies to existing conversations
- Encrypted social tokens in Neon
- Meta webhook verification

## Free-first stack
- Vercel Hobby hosting
- Neon Postgres
- Google Gemini (`gemini-3.5-flash-lite` default)
- Daily Vercel Autopilot cron

## Core environment variables
1. `GOOGLE_GENERATIVE_AI_API_KEY`
2. `DATABASE_URL`
3. `SOCIALPILOT_OWNER_KEY`
4. `CRON_SECRET`
5. `SOCIALPILOT_SESSION_SECRET`
6. `APP_URL` (optional override; live request origin is preferred where supported)

## Optional social connector variables
TikTok: `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET`

Instagram: `META_APP_ID`, `META_APP_SECRET`, optional `META_GRAPH_VERSION`, `META_WEBHOOK_VERIFY_TOKEN`

YouTube: `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`

## Existing cloud data
V8 is compatible with the existing `socialpilot_state` row. Account-launch plans and checklist progress are merged into the same cloud state without replacing Analytics, Revenue, Leads, Content, or Autopilot data.

## DRAIG V8.2 Voice
- Visible assistant name: **DRAIG**
- Wake phrase: **Hey DRAIG**
- Browser-native microphone recognition and spoken replies (no paid voice API required)
- Voice navigation across DRAIG workspaces
- Voice content generation and full-post creation
- Voice Autopilot planning and execution of approved internal actions
- Voice save commands
- Publishing is confirmation-gated: a publish request requires a second explicit **“Hey DRAIG, confirm publish”** command
- Destructive/account-security actions are not voice-automated

On iPad/iPhone, voice mode must be enabled from the page and microphone permission granted. Browser suspension, screen lock, or closing Safari can stop listening; this build does not bypass iOS background restrictions.
