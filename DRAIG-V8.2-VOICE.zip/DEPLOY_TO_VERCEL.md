# Deploy DRAIG V6.1 on Vercel Hobby

Use the same server secrets already used by the working V3 deployment:

- GOOGLE_GENERATIVE_AI_API_KEY
- DATABASE_URL
- SOCIALPILOT_OWNER_KEY
- CRON_SECRET
- SOCIALPILOT_SESSION_SECRET

APP_URL is optional in V6.1 because the app automatically uses the live request origin.

After deployment:
1. Open `/api/health` and confirm `ready: true`.
2. Open Settings → Cloud Sync and enter the owner key.
3. Load cloud state.
4. Turn Autopilot ON.
5. Run Autopilot once and verify the Action Queue.

The included Vercel cron runs once daily at 12:00 UTC, which is compatible with Vercel Hobby.
