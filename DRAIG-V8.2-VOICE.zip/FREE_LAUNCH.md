# DRAIG V8 — Free Launch Checklist

1. Deploy the V8 project to Vercel.
2. Reuse the working core Gemini + Neon + Social Pilot secrets from the previous deployment.
3. Open `/api/health` and confirm the core stack is ready.
4. Open Settings → Cloud Sync and load the existing cloud state.
5. Open **Launch Accounts** and generate a brand/account launch kit.
6. Use the official platform links to complete human-controlled signup and verification.
7. Mark setup steps complete in V8.
8. Connect the finished accounts under **Accounts** if you want official API publishing.
9. Turn Autopilot on and run it once manually.

No paid AI provider is required for the default setup.
