import { neon } from '@neondatabase/serverless';

export type CloudState = {
  savedPosts?: unknown[];
  businessPlan?: unknown | null;
  accountLaunchPlan?: unknown | null;
  accountLaunchCompleted?: number[];
  leads?: unknown[];
  orders?: unknown[];
  supportTickets?: unknown[];
  retentionActions?: unknown[];
  performanceMetrics?: unknown[];
  optimizationAdvice?: unknown | null;
  autopilotEnabled?: boolean;
  autopilotTasks?: unknown[];
  autopilotSummary?: string;
  executionLog?: unknown[];
  scheduleDates?: Record<string, string>;
  updatedAt?: string;
  lastAutopilotRun?: string;
  revenueGoal?: number;
  revenueEntries?: unknown[];
  revenueAdvice?: unknown | null;
  funnelPlan?: unknown | null;
  websitePlan?: unknown | null;
  websitePublished?: boolean;
};

function getSql() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error('Missing DATABASE_URL. Add your Neon connection string in Vercel Environment Variables.');
  return neon(url);
}

export async function ensureCloudTable() {
  const sql = getSql();
  await sql`CREATE TABLE IF NOT EXISTS socialpilot_state (
    owner_id TEXT PRIMARY KEY,
    state JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  return sql;
}

export async function readCloudState(): Promise<CloudState | null> {
  const sql = await ensureCloudTable();
  const rows = await sql`SELECT state, updated_at FROM socialpilot_state WHERE owner_id = 'primary' LIMIT 1`;
  if (!rows.length) return null;
  const state = (rows[0].state || {}) as CloudState;
  return { ...state, updatedAt: new Date(rows[0].updated_at as string).toISOString() };
}

export async function writeCloudState(state: CloudState): Promise<CloudState> {
  const sql = await ensureCloudTable();
  const payload = { ...state, updatedAt: new Date().toISOString() };
  const rows = await sql`
    INSERT INTO socialpilot_state (owner_id, state, updated_at)
    VALUES ('primary', ${JSON.stringify(payload)}::jsonb, NOW())
    ON CONFLICT (owner_id)
    DO UPDATE SET state = COALESCE(socialpilot_state.state, '{}'::jsonb) || EXCLUDED.state, updated_at = NOW()
    RETURNING state, updated_at
  `;
  const merged = (rows[0]?.state || payload) as CloudState;
  return { ...merged, updatedAt: new Date(rows[0]?.updated_at as string || new Date()).toISOString() };
}

export type AutopilotPatch = {
  autopilotTasks?: unknown[];
  autopilotSummary?: string;
  executionLog?: unknown[];
  autopilotEnabled?: boolean;
  lastAutopilotRun?: string;
};

export async function writeAutopilotPatch(input: AutopilotPatch): Promise<CloudState> {
  const sql = await ensureCloudTable();
  const patch: AutopilotPatch & { updatedAt: string } = { updatedAt: new Date().toISOString() };
  if (Array.isArray(input.autopilotTasks)) patch.autopilotTasks = input.autopilotTasks;
  if (typeof input.autopilotSummary === 'string') patch.autopilotSummary = input.autopilotSummary;
  if (typeof input.autopilotEnabled === 'boolean') patch.autopilotEnabled = input.autopilotEnabled;
  if (typeof input.lastAutopilotRun === 'string') patch.lastAutopilotRun = input.lastAutopilotRun;
  if (Array.isArray(input.executionLog)) patch.executionLog = input.executionLog;

  const rows = await sql`
    INSERT INTO socialpilot_state (owner_id, state, updated_at)
    VALUES ('primary', ${JSON.stringify(patch)}::jsonb, NOW())
    ON CONFLICT (owner_id)
    DO UPDATE SET state = COALESCE(socialpilot_state.state, '{}'::jsonb) || EXCLUDED.state, updated_at = NOW()
    RETURNING state, updated_at
  `;
  const merged = (rows[0]?.state || patch) as CloudState;
  return { ...merged, updatedAt: new Date(rows[0]?.updated_at as string || new Date()).toISOString() };
}
