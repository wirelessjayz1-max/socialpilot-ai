import { neon } from '@neondatabase/serverless';
import { open, seal } from './connection';

export type SocialPlatform = 'tiktok' | 'instagram' | 'youtube';
export type SocialConnection = {
  platform: SocialPlatform;
  accessToken: string;
  refreshToken?: string;
  expiresAt?: number;
  refreshExpiresAt?: number;
  scope?: string;
  profile?: Record<string, any>;
  pageId?: string;
  igUserId?: string;
  openId?: string;
  tokenType?: string;
};

function sqlClient() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL is not configured');
  return neon(url);
}

export async function ensureSocialTables() {
  const sql = sqlClient();
  await sql`CREATE TABLE IF NOT EXISTS socialpilot_social_connections (
    platform TEXT PRIMARY KEY,
    sealed_data TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`CREATE TABLE IF NOT EXISTS socialpilot_inbox (
    id TEXT PRIMARY KEY,
    platform TEXT NOT NULL,
    sender_id TEXT,
    recipient_id TEXT,
    message_text TEXT,
    event_time TIMESTAMPTZ,
    raw JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  return sql;
}

export async function saveSocialConnection(connection: SocialConnection) {
  const sql = await ensureSocialTables();
  const payload = seal(connection);
  await sql`
    INSERT INTO socialpilot_social_connections(platform, sealed_data, updated_at)
    VALUES (${connection.platform}, ${payload}, NOW())
    ON CONFLICT(platform) DO UPDATE SET sealed_data = EXCLUDED.sealed_data, updated_at = NOW()
  `;
}

export async function getSocialConnection(platform: SocialPlatform): Promise<SocialConnection | null> {
  const sql = await ensureSocialTables();
  const rows = await sql`SELECT sealed_data FROM socialpilot_social_connections WHERE platform = ${platform} LIMIT 1`;
  if (!rows.length) return null;
  try { return open<SocialConnection>(String(rows[0].sealed_data)); } catch { return null; }
}

export async function deleteSocialConnection(platform: SocialPlatform) {
  const sql = await ensureSocialTables();
  await sql`DELETE FROM socialpilot_social_connections WHERE platform = ${platform}`;
}

export async function listSocialConnections() {
  const platforms: SocialPlatform[] = ['tiktok', 'instagram', 'youtube'];
  return Promise.all(platforms.map(async platform => {
    const c = await getSocialConnection(platform);
    return c ? {
      platform,
      connected: true,
      profile: c.profile || {},
      scope: c.scope || '',
      expiresAt: c.expiresAt || null,
      pageId: c.pageId || null,
      igUserId: c.igUserId || null
    } : { platform, connected: false };
  }));
}

export async function getValidTikTokConnection() {
  const current = await getSocialConnection('tiktok');
  if (!current) return null;
  if (!current.refreshToken || !current.expiresAt || current.expiresAt - Date.now() > 20 * 60 * 1000) return current;
  const clientKey = process.env.TIKTOK_CLIENT_KEY;
  const clientSecret = process.env.TIKTOK_CLIENT_SECRET;
  if (!clientKey || !clientSecret) return current;
  const body = new URLSearchParams({ client_key: clientKey, client_secret: clientSecret, grant_type: 'refresh_token', refresh_token: current.refreshToken });
  const r = await fetch('https://open.tiktokapis.com/v2/oauth/token/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Cache-Control': 'no-cache' }, body, cache: 'no-store' });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.access_token) return current;
  const refreshed: SocialConnection = {
    ...current,
    accessToken: data.access_token,
    refreshToken: data.refresh_token || current.refreshToken,
    expiresAt: Date.now() + Number(data.expires_in || 86400) * 1000,
    refreshExpiresAt: data.refresh_expires_in ? Date.now() + Number(data.refresh_expires_in) * 1000 : current.refreshExpiresAt,
    scope: data.scope || current.scope,
    openId: data.open_id || current.openId,
    tokenType: data.token_type || current.tokenType
  };
  await saveSocialConnection(refreshed);
  return refreshed;
}

export async function saveInboxEvent(input: { id: string; platform: string; senderId?: string; recipientId?: string; messageText?: string; eventTime?: string; raw: unknown }) {
  const sql = await ensureSocialTables();
  await sql`
    INSERT INTO socialpilot_inbox(id, platform, sender_id, recipient_id, message_text, event_time, raw, created_at)
    VALUES (${input.id}, ${input.platform}, ${input.senderId || null}, ${input.recipientId || null}, ${input.messageText || null}, ${input.eventTime || null}, ${JSON.stringify(input.raw)}::jsonb, NOW())
    ON CONFLICT(id) DO NOTHING
  `;
}

export async function listInboxEvents(platform = 'instagram', limit = 100) {
  const sql = await ensureSocialTables();
  const n = Math.max(1, Math.min(200, limit));
  return sql`SELECT id, platform, sender_id, recipient_id, message_text, event_time, created_at FROM socialpilot_inbox WHERE platform = ${platform} ORDER BY COALESCE(event_time, created_at) DESC LIMIT ${n}`;
}
