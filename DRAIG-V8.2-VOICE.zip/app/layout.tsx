import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'DRAIG',description:'Voice-activated AI business and social media assistant'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
