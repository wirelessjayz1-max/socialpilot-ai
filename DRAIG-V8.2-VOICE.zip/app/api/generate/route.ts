import { generateObject } from 'ai';
import { createGoogleGenerativeAI } from '@ai-sdk/google';
import { NextResponse } from 'next/server';
import { z } from 'zod';

export const runtime = 'nodejs';

const socialContentSchema = z.object({
  title: z.string(),
  hook: z.string(),
  script: z.string(),
  caption: z.string(),
  hashtags: z.array(z.string()),
  callToAction: z.string(),
  visualPlan: z.array(z.string())
});

const ideaBatchSchema = z.object({
  ideas: z.array(z.object({
    title: z.string(),
    angle: z.string(),
    hook: z.string()
  })).min(3).max(10)
});

const followupSchema = z.object({ subject: z.string(), message: z.string() });
const supportReplySchema = z.object({ subject: z.string(), message: z.string() });
const optimizationSchema = z.object({
  summary: z.string(),
  working: z.array(z.string()).min(1).max(6),
  improve: z.array(z.string()).min(1).max(6),
  nextExperiment: z.string(),
  actions: z.array(z.string()).min(3).max(7)
});
const revenueSchema = z.object({ summary: z.string(), nextMove: z.string(), why: z.string(), target: z.string(), actions: z.array(z.string()).min(3).max(7) });
const funnelSchema = z.object({
  funnelName: z.string(), offerName: z.string(), audience: z.string(), promise: z.string(), price: z.string(),
  leadMagnetTitle: z.string(), leadMagnetOutline: z.array(z.string()).min(3).max(8),
  landingHeadline: z.string(), landingSubheadline: z.string(), benefits: z.array(z.string()).min(3).max(7),
  callToAction: z.string(), funnelSteps: z.array(z.string()).min(4).max(8),
  followupSequence: z.array(z.object({ day: z.string(), subject: z.string(), message: z.string() })).min(3).max(7),
  contentAngles: z.array(z.string()).min(5).max(10)
});
const websiteSchema = z.object({
  siteName: z.string(), tagline: z.string(), heroHeadline: z.string(), heroSubheadline: z.string(), about: z.string(),
  products: z.array(z.object({ name: z.string(), description: z.string(), price: z.string(), buttonLabel: z.string() })).min(1).max(4),
  benefits: z.array(z.string()).min(3).max(6),
  faq: z.array(z.object({ question: z.string(), answer: z.string() })).min(3).max(6),
  finalCta: z.string(), contactText: z.string()
});

const managerPlanSchema = z.object({
  summary: z.string(),
  tasks: z.array(z.object({
    title: z.string(),
    reason: z.string(),
    actionType: z.enum(['content','sales','business','review','publish']),
    priority: z.enum(['high','medium','low']),
    requiresApproval: z.boolean()
  })).min(3).max(8)
});


const accountLaunchSchema = z.object({
  brandName: z.string(),
  niche: z.string(),
  audience: z.string(),
  positioning: z.string(),
  displayName: z.string(),
  usernameIdeas: z.array(z.string()).min(5).max(12),
  tiktokBio: z.string(),
  instagramBio: z.string(),
  youtubeDescription: z.string(),
  profileImagePrompt: z.string(),
  bannerPrompt: z.string(),
  category: z.string(),
  linkInBioText: z.string(),
  launchChecklist: z.array(z.object({
    platform: z.enum(['TikTok','Instagram','YouTube','All']),
    title: z.string(),
    instruction: z.string(),
    humanRequired: z.boolean()
  })).min(8).max(18),
  first7Posts: z.array(z.object({
    day: z.string(),
    platform: z.string(),
    title: z.string(),
    hook: z.string(),
    goal: z.string()
  })).min(7).max(7),
  firstWeekGoal: z.string(),
  safetyNotes: z.array(z.string()).min(2).max(6)
});

const businessPlanSchema = z.object({
  businessName: z.string(),
  niche: z.string(),
  targetCustomer: z.string(),
  problemSolved: z.string(),
  offer: z.string(),
  pricing: z.string(),
  businessModel: z.string(),
  positioning: z.string(),
  launchSteps: z.array(z.string()).min(5).max(10),
  firstProducts: z.array(z.string()).min(1).max(5),
  marketingChannels: z.array(z.string()).min(2).max(6),
  first10Posts: z.array(z.string()).min(5).max(10),
  thirtyDayGoal: z.string()
});

type ProviderModel = {
  model: any;
  id: string;
  provider: string;
};

function getModelIds() {
  const primary = process.env.AI_MODEL || 'google/gemini-3.5-flash-lite';
  const fallback = (process.env.AI_FALLBACK_MODELS || 'google/gemini-3.5-flash-lite')
    .split(',')
    .map((model) => model.trim())
    .filter(Boolean);

  return Array.from(new Set([primary, ...fallback])).filter((id) => id.startsWith('google/'));
}

function createDirectModel(modelId: string): ProviderModel {
  const [provider, ...parts] = modelId.split('/');
  const name = parts.join('/');
  if (provider !== 'google' || !name) {
    throw new Error(`Invalid free AI model '${modelId}'. Use a Google Gemini model such as google/gemini-3.5-flash-lite.`);
  }

  const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  if (!apiKey) throw new Error('Missing GOOGLE_GENERATIVE_AI_API_KEY. Add your Gemini API key in Vercel Environment Variables.');
  const google = createGoogleGenerativeAI({ apiKey });
  return { model: google(name), id: modelId, provider };
}

function getDirectModels() {
  if (!process.env.GOOGLE_GENERATIVE_AI_API_KEY) {
    throw new Error('No free AI provider is configured. Add GOOGLE_GENERATIVE_AI_API_KEY in Vercel Environment Variables.');
  }
  const modelIds = getModelIds();
  if (!modelIds.length) throw new Error('AI_MODEL must use a Google Gemini model in this free-first build.');
  return modelIds.map(createDirectModel);
}

function friendlyError(error: any, models: string[]) {
  const status = Number(error?.status) || Number(error?.cause?.status) || 500;
  const message = String(error?.message || error?.cause?.message || 'AI generation failed.');

  if (message.includes('No free AI provider is configured') || message.includes('Missing ') || message.includes('AI_MODEL must use')) {
    return {
      status: 503,
      message: `${message} DRAIG V8 uses Gemini directly and does not require Vercel AI Gateway credits.`
    };
  }

  if (status === 401) {
    return { status: 401, message: 'Gemini authentication failed. Check GOOGLE_GENERATIVE_AI_API_KEY in Vercel Environment Variables.' };
  }
  if (status === 402 || status === 429) {
    return { status, message: `Gemini could not complete the request because of quota, billing, or rate limits. Models attempted: ${models.join(', ')}.` };
  }
  if (status === 403) {
    return { status: 403, message: 'Gemini denied the request. Check the API key, Google AI project permissions, and model access.' };
  }
  return { status: status >= 400 && status < 600 ? status : 500, message: `AI generation failed: ${message}` };
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const idea = String(body.idea || '').trim();
    const platform = String(body.platform || 'TikTok / Reels / Shorts');
    const tone = String(body.tone || 'high-energy');
    const mode = String(body.mode || 'package');
    const count = Math.max(3, Math.min(10, Number(body.count || 5)));

    if (!idea) return NextResponse.json({ error: mode === 'business' ? 'Tell the AI what kind of business you want to build.' : 'Tell the AI what you want the video to be about.' }, { status: 400 });

    // Keep direct user-entered content prompts short, but allow DRAIG's
    // internal business engines to pass bounded structured context (analytics,
    // CRM, revenue, funnel, website, support, and Autopilot data).
    const internalContextModes = new Set(['optimize', 'support', 'followup', 'website', 'funnel', 'revenue', 'manager']);
    const maxIdeaLength = internalContextModes.has(mode) ? 20_000 : 1_200;
    if (idea.length > maxIdeaLength) {
      return NextResponse.json(
        { error: internalContextModes.has(mode) ? 'The business context is too large. Reduce older records and try again.' : 'Keep the idea under 1,200 characters.' },
        { status: 400 }
      );
    }

    const models = getDirectModels();
    const failures: string[] = [];

    for (const providerModel of models) {
      try {
        if (mode === 'ideas') {
          const result = await generateObject({
            model: providerModel.model,
            schema: ideaBatchSchema,
            system: `You are DRAIG's Content Copilot. Generate original short-form content ideas that are practical, platform-native, and easy for a solo creator to make. Avoid fake guarantees, spammy claims, and generic filler. The user wants ideas for ${platform} in a ${tone} tone.`,
            prompt: `Generate ${count} distinct short-form content ideas around this topic or niche:\n\n${idea}\n\nFor each idea provide a concise title, a fresh angle, and a strong first-line hook.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'optimize') {
          const result = await generateObject({
            model: providerModel.model,
            schema: optimizationSchema,
            system: `You are DRAIG's Analytics + Optimization Engine. Analyze only the real data provided. Identify evidence-backed patterns, weak points, and one practical next experiment. Never invent platform metrics, attribution, customers, or causality. Distinguish observations from hypotheses. Prefer free/low-cost experiments. Spending, publishing, account changes, or outreach to real people must remain approval-gated.`,
            prompt: `Analyze this business performance context and produce a concise optimization plan:

${idea}`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'support') {
          const result = await generateObject({
            model: providerModel.model,
            schema: supportReplySchema,
            system: `You are DRAIG's Customer Support Assistant. Draft a helpful, concise customer-support reply for a solo online business. Be empathetic and practical without admitting fault, inventing refunds, promises, policies, discounts, delivery dates, or facts not provided. Do not claim any action has already been taken. Keep it under 140 words.`,
            prompt: `Draft a support reply from this context:

${idea}

Return a concise subject and message.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'followup') {
          const result = await generateObject({
            model: providerModel.model,
            schema: followupSchema,
            system: `You are DRAIG's Sales Assistant. Write a short, natural follow-up message for a small online business. Be friendly, specific, and non-pushy. Never invent facts, discounts, deadlines, or guarantees. Keep the message under 90 words.`,
            prompt: `Create a follow-up message from these CRM details:\n\n${idea}\n\nReturn a short subject and a message that can be sent by DM, text, or email.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'website') {
          const result = await generateObject({
            model: providerModel.model,
            schema: websiteSchema,
            system: `You are DRAIG's Website + Store Builder. Create concise, credible copy for a one-page website for a solo online business. Use only the context provided. Do not invent testimonials, customers, guarantees, certifications, scarcity, or results. Keep product/store cards realistic and suitable for a free starter site.`,
            prompt: `Build a complete one-page website/store from this business context:

${idea}

Return a site name, tagline, hero headline/subheadline, short about section, 1-4 offer/product cards with price text and button labels, 3-6 benefits, 3-6 FAQs, a final CTA, and short contact text.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'funnel') {
          const result = await generateObject({
            model: providerModel.model,
            schema: funnelSchema,
            system: `You are DRAIG's Offer + Funnel Engine. Build a simple, ethical sales funnel for a solo online business using free or low-cost channels. Make the offer concrete, the promise realistic, and the copy specific. Do not invent testimonials, scarcity, customers, results, guarantees, or fake urgency. Prefer a free lead magnet and manual/free follow-up workflow. Messages are drafts and must not be described as already sent.`,
            prompt: `Build a complete starter funnel from this business context:

${idea}

Return a funnel name, offer, audience, realistic promise, starter price, free lead magnet with outline, landing page headline/subheadline/benefits/CTA, step-by-step funnel, 3-7 follow-up drafts, and 5-10 content angles that feed the funnel.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'revenue') {
          const result = await generateObject({
            model: providerModel.model,
            schema: revenueSchema,
            system: `You are DRAIG's Revenue Engine. Analyze a solo online business using only the data provided. Recommend the single highest-leverage next move that could improve revenue or profit. Do not promise earnings, invent customers, invent conversion data, or tell the system to spend money automatically. Prefer actions using existing leads, offers, content, and free channels. Any spending, external publishing, account changes, or outreach to real people must remain subject to user approval.`,
            prompt: `Analyze this business revenue context and return one focused money move with 3-7 concrete steps:

${idea}`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'manager') {
          const result = await generateObject({
            model: providerModel.model,
            schema: managerPlanSchema,
            system: `You are DRAIG's Autonomous Business Manager. Create a focused daily operating plan for a solo online business. Prioritize actions that can realistically move the business forward today. Safe planning, drafting, analysis, CRM updates, and content preparation can be marked as not requiring approval. Publishing, spending money, changing external accounts, legal actions, deleting important data, or sending messages to real people must require approval. Never claim an external action has happened unless the app actually performs it. IMPORTANT ANALYTICS RULE: when analytics.topPerformer or analytics.latestOptimization is present, explicitly use that evidence in the plan. Unless an urgent customer/support issue is more important, include at least one HIGH-priority task that repeats, repurposes, distributes, or tests a variation of the proven winning campaign/channel. Name the winning campaign/channel and cite its supplied performance numbers in the task reason. Do not replace evidence-based actions with generic 'make more content' advice.`,
            prompt: `Create today's autonomous operating plan from this business context:

${idea}

Return a concise summary and 3-8 prioritized tasks. Keep tasks specific and executable.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }


        if (mode === 'account-launch') {
          const result = await generateObject({
            model: providerModel.model,
            schema: accountLaunchSchema,
            system: `You are DRAIG's Account Launch Assistant. Build a practical launch kit for new creator/business accounts on TikTok, Instagram, and YouTube. Generate brand-safe names, bios, profile concepts, setup guidance, and a seven-post launch plan. Never claim an account, handle, username, domain, or verification is available or reserved. Never instruct the user to bypass CAPTCHA, age gates, identity checks, phone/email verification, platform review, or terms. Mark steps that require a human when they involve signup, credentials, verification, accepting terms, identity, payment, or security. Keep claims realistic and free-first.`,
            prompt: `Create a complete social account launch kit from this brief:

${idea}

Give 5-12 username ideas (ideas only, not availability claims), optimized bios for TikTok and Instagram, a YouTube description, profile/banner image prompts, a platform-by-platform setup checklist, and exactly 7 first-post ideas for the first week.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        if (mode === 'business') {
          const result = await generateObject({
            model: providerModel.model,
            schema: businessPlanSchema,
            system: `You are DRAIG's Business Builder. Help a solo beginner create a realistic online business that can be started cheaply. Prefer simple offers, digital products, services, affiliate/content models, or lightweight ecommerce. Do not promise income. Keep the plan practical, specific, and suitable for one person using free or low-cost tools.`,
            prompt: `Build a complete starter business plan from this user's description:

${idea}

Include a clear business name, niche, target customer, problem solved, offer, starter pricing, business model, positioning, launch steps, first products or services, best marketing channels, ten starter content ideas, and a realistic 30-day goal.`
          });
          return NextResponse.json({ ...result.object, aiModel: providerModel.id, aiProvider: providerModel.provider, aiMode: 'direct' });
        }

        const result = await generateObject({
          model: providerModel.model,
          schema: socialContentSchema,
          system: `You are DRAIG, an expert short-form content strategist. Create original, platform-native content designed to earn attention without making fake guarantees. Write naturally, avoid generic filler, and make every line useful. The user wants content for ${platform} in a ${tone} tone. Keep the spoken script under 140 words. The visual plan should contain 5-7 simple shot ideas.`,
          prompt: `Create a complete short-form video package from this idea:\n\n${idea}`
        });

        return NextResponse.json({
          ...result.object,
          aiModel: providerModel.id,
          aiProvider: providerModel.provider,
          aiRequestedModel: models[0]?.id,
          aiMode: 'direct'
        });
      } catch (error: any) {
        console.error(`SocialPilot provider ${providerModel.id} failed:`, error);
        failures.push(`${providerModel.id}: ${String(error?.message || 'request failed')}`);
      }
    }

    const lastError = failures[failures.length - 1] || 'All configured providers failed.';
    throw new Error(`All configured AI providers failed. ${lastError}`);
  } catch (error: any) {
    console.error('DRAIG generation error:', error);
    const friendly = friendlyError(error, getModelIds());
    return NextResponse.json({ error: friendly.message }, { status: friendly.status });
  }
}
