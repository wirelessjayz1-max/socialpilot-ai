import { NextResponse } from 'next/server';
import { listInboxEvents } from '../../../../lib/social-connections';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET() {
  try { return NextResponse.json({ ok: true, events: await listInboxEvents('instagram', 100) }); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : 'Could not load inbox', events: [] }, { status: 500 }); }
}
