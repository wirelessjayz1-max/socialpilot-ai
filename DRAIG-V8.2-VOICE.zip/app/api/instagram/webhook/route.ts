import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { saveInboxEvent } from '../../../../lib/social-connections';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const mode = req.nextUrl.searchParams.get('hub.mode');
  const token = req.nextUrl.searchParams.get('hub.verify_token');
  const challenge = req.nextUrl.searchParams.get('hub.challenge');
  if (mode === 'subscribe' && token && token === process.env.META_WEBHOOK_VERIFY_TOKEN) return new NextResponse(challenge || '', { status: 200 });
  return NextResponse.json({ error: 'Webhook verification failed' }, { status: 403 });
}

function verifyMetaSignature(rawBody: string, signature: string | null, secret: string) {
  if (!signature?.startsWith('sha256=')) return false;
  const expected = `sha256=${crypto.createHmac('sha256', secret).update(rawBody).digest('hex')}`;
  const supplied = Buffer.from(signature);
  const wanted = Buffer.from(expected);
  return supplied.length === wanted.length && crypto.timingSafeEqual(supplied, wanted);
}

export async function POST(req: NextRequest) {
  try {
    const appSecret = process.env.META_APP_SECRET;
    if (!appSecret) return NextResponse.json({ error: 'META_APP_SECRET is not configured' }, { status: 503 });

    const rawBody = await req.text();
    const signature = req.headers.get('x-hub-signature-256');
    if (!verifyMetaSignature(rawBody, signature, appSecret)) {
      return NextResponse.json({ error: 'Invalid Meta webhook signature' }, { status: 401 });
    }

    const body = JSON.parse(rawBody || '{}');
    const jobs: Promise<any>[] = [];
    for (const entry of body?.entry || []) {
      for (const event of entry?.messaging || []) {
        const message = event?.message;
        if (!message) continue;
        const id = String(message.mid || crypto.createHash('sha256').update(JSON.stringify(event)).digest('hex'));
        jobs.push(saveInboxEvent({
          id,
          platform: 'instagram',
          senderId: event.sender?.id ? String(event.sender.id) : undefined,
          recipientId: event.recipient?.id ? String(event.recipient.id) : undefined,
          messageText: message.text ? String(message.text) : undefined,
          eventTime: event.timestamp ? new Date(Number(event.timestamp)).toISOString() : undefined,
          raw: event
        }));
      }
    }
    await Promise.all(jobs);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Webhook processing failed' }, { status: 500 });
  }
}
