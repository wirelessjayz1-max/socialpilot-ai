import { NextRequest, NextResponse } from 'next/server';
import { getSocialConnection } from '../../../../lib/social-connections';

export const runtime = 'nodejs';

async function eligibleRecipientIds(pageId: string, igUserId: string | undefined, accessToken: string, version: string) {
  const url = new URL(`https://graph.facebook.com/${version}/${pageId}/conversations`);
  url.searchParams.set('platform', 'instagram');
  url.searchParams.set('fields', 'participants');
  url.searchParams.set('limit', '100');
  url.searchParams.set('access_token', accessToken);
  const r = await fetch(url, { cache: 'no-store' });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error?.message || 'Could not verify Instagram recipient');
  const ids = new Set<string>();
  for (const convo of data.data || []) {
    for (const p of convo.participants?.data || []) {
      const id = p?.id ? String(p.id) : '';
      if (id && id !== pageId && id !== igUserId) ids.add(id);
    }
  }
  return ids;
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const recipientId = String(body?.recipientId || '');
  const message = String(body?.message || '').trim();
  const approved = body?.approved === true;
  if (!approved) return NextResponse.json({ error: 'Explicit approval is required before sending a real message.' }, { status: 400 });
  if (!recipientId || !message) return NextResponse.json({ error: 'recipientId and message are required' }, { status: 400 });
  if (message.length > 1000) return NextResponse.json({ error: 'Message is too long.' }, { status: 400 });

  try {
    const c = await getSocialConnection('instagram');
    if (!c) return NextResponse.json({ error: 'Instagram is not connected' }, { status: 401 });
    if (!c.pageId) return NextResponse.json({ error: 'Instagram Page ID is missing. Reconnect Instagram.' }, { status: 400 });
    const version = process.env.META_GRAPH_VERSION || 'v24.0';
    const eligible = await eligibleRecipientIds(c.pageId, c.igUserId, c.accessToken, version);
    if (!eligible.has(recipientId)) return NextResponse.json({ error: 'Instagram only allows this integration to reply to people who already initiated a conversation with the connected professional account.' }, { status: 403 });

    const r = await fetch(`https://graph.facebook.com/${version}/${c.pageId}/messages?access_token=${encodeURIComponent(c.accessToken)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ recipient: { id: recipientId }, messaging_type: 'RESPONSE', message: { text: message } }),
      cache: 'no-store'
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return NextResponse.json(data, { status: r.status });
    return NextResponse.json({ ok: true, sent: true, recipientId: data.recipient_id || recipientId, messageId: data.message_id || null });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Instagram message failed' }, { status: 500 });
  }
}
