import { NextResponse } from 'next/server';
import { getSocialConnection } from '../../../../lib/social-connections';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const c = await getSocialConnection('instagram');
    if (!c) return NextResponse.json({ error: 'Instagram is not connected' }, { status: 401 });
    if (!c.pageId) return NextResponse.json({ error: 'Instagram Page ID is missing. Reconnect Instagram.' }, { status: 400 });
    const version = process.env.META_GRAPH_VERSION || 'v24.0';
    const url = new URL(`https://graph.facebook.com/${version}/${c.pageId}/conversations`);
    url.searchParams.set('platform', 'instagram');
    url.searchParams.set('fields', 'id,updated_time,participants,messages.limit(12){id,message,from,to,created_time}');
    url.searchParams.set('limit', '25');
    url.searchParams.set('access_token', c.accessToken);
    const r = await fetch(url, { cache: 'no-store' });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return NextResponse.json(data, { status: r.status });
    return NextResponse.json({ ok: true, conversations: data.data || [], paging: data.paging || null });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Could not load Instagram conversations' }, { status: 500 });
  }
}
