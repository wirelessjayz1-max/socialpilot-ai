import { NextRequest, NextResponse } from 'next/server';
import { saveSocialConnection, type SocialConnection } from '../../../../../lib/social-connections';

export const runtime = 'nodejs';

async function postForm(url: string, body: URLSearchParams) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body, cache: 'no-store' });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error_description || data.error?.message || data.error || 'Token exchange failed');
  return data;
}

async function metaGet(path: string, params: Record<string, string>) {
  const version = process.env.META_GRAPH_VERSION || 'v24.0';
  const url = new URL(`https://graph.facebook.com/${version}/${path}`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const r = await fetch(url, { cache: 'no-store' });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error?.message || 'Meta API request failed');
  return data;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ platform: string }> }) {
  const { platform } = await params;
  const code = req.nextUrl.searchParams.get('code');
  const state = req.nextUrl.searchParams.get('state');
  const oauthError = req.nextUrl.searchParams.get('error_message') || req.nextUrl.searchParams.get('error_description') || req.nextUrl.searchParams.get('error');
  if (oauthError) return NextResponse.redirect(new URL(`/?accounts=error&message=${encodeURIComponent(oauthError)}`, req.url));

  const savedRaw = req.cookies.get(`sp_oauth_state_${platform}`)?.value;
  if (!code || !savedRaw) return NextResponse.redirect(new URL('/?accounts=error&message=Missing OAuth response', req.url));
  let saved: { state: string; redirectUri: string };
  try { saved = JSON.parse(savedRaw); } catch { return NextResponse.redirect(new URL('/?accounts=error&message=Invalid OAuth state', req.url)); }
  if (!state || state !== saved.state) return NextResponse.redirect(new URL('/?accounts=error&message=OAuth state mismatch', req.url));

  try {
    let connection: SocialConnection;

    if (platform === 'tiktok') {
      const token = await postForm('https://open.tiktokapis.com/v2/oauth/token/', new URLSearchParams({
        client_key: process.env.TIKTOK_CLIENT_KEY || '',
        client_secret: process.env.TIKTOK_CLIENT_SECRET || '',
        code,
        grant_type: 'authorization_code',
        redirect_uri: saved.redirectUri
      }));
      const profileRes = await fetch('https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url,profile_deep_link', { headers: { Authorization: `Bearer ${token.access_token}` }, cache: 'no-store' });
      const profileData = await profileRes.json().catch(() => ({}));
      connection = {
        platform: 'tiktok',
        accessToken: token.access_token,
        refreshToken: token.refresh_token,
        expiresAt: Date.now() + Number(token.expires_in || 86400) * 1000,
        refreshExpiresAt: Date.now() + Number(token.refresh_expires_in || 31536000) * 1000,
        scope: token.scope || '',
        openId: token.open_id,
        tokenType: token.token_type || 'Bearer',
        profile: profileData.data?.user || { open_id: token.open_id }
      };
    } else if (platform === 'instagram') {
      const appId = process.env.META_APP_ID || '';
      const appSecret = process.env.META_APP_SECRET || '';
      const version = process.env.META_GRAPH_VERSION || 'v24.0';
      const tokenUrl = new URL(`https://graph.facebook.com/${version}/oauth/access_token`);
      tokenUrl.searchParams.set('client_id', appId);
      tokenUrl.searchParams.set('client_secret', appSecret);
      tokenUrl.searchParams.set('redirect_uri', saved.redirectUri);
      tokenUrl.searchParams.set('code', code);
      const tokenRes = await fetch(tokenUrl, { cache: 'no-store' });
      const shortToken = await tokenRes.json().catch(() => ({}));
      if (!tokenRes.ok || !shortToken.access_token) throw new Error(shortToken.error?.message || 'Meta token exchange failed');

      let userToken = shortToken.access_token as string;
      let expiresIn = Number(shortToken.expires_in || 3600);
      try {
        const longToken = await metaGet('oauth/access_token', {
          grant_type: 'fb_exchange_token', client_id: appId, client_secret: appSecret, fb_exchange_token: userToken
        });
        if (longToken.access_token) { userToken = longToken.access_token; expiresIn = Number(longToken.expires_in || 60 * 24 * 60 * 60); }
      } catch {}

      const pages = await metaGet('me/accounts', {
        fields: 'id,name,access_token,tasks,instagram_business_account{id,username,name,profile_picture_url}',
        access_token: userToken
      });
      const page = (pages.data || []).find((p: any) => p.instagram_business_account?.id);
      if (!page) throw new Error('No Instagram Professional account linked to a Facebook Page was found. Link a Business or Creator Instagram account to a Page, then reconnect.');
      connection = {
        platform: 'instagram',
        accessToken: page.access_token,
        expiresAt: Date.now() + expiresIn * 1000,
        scope: 'instagram_basic,instagram_content_publish,instagram_manage_messages,pages_manage_metadata,pages_read_engagement',
        pageId: page.id,
        igUserId: page.instagram_business_account.id,
        profile: {
          id: page.instagram_business_account.id,
          username: page.instagram_business_account.username,
          name: page.instagram_business_account.name || page.name,
          profile_picture_url: page.instagram_business_account.profile_picture_url,
          pageName: page.name,
          tasks: page.tasks || []
        }
      };
    } else if (platform === 'youtube') {
      const token = await postForm('https://oauth2.googleapis.com/token', new URLSearchParams({
        client_id: process.env.YOUTUBE_CLIENT_ID || '',
        client_secret: process.env.YOUTUBE_CLIENT_SECRET || '',
        code,
        grant_type: 'authorization_code',
        redirect_uri: saved.redirectUri
      }));
      const ch = await fetch('https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true', { headers: { Authorization: `Bearer ${token.access_token}` }, cache: 'no-store' });
      const channel = await ch.json().catch(() => ({}));
      connection = { platform: 'youtube', accessToken: token.access_token, refreshToken: token.refresh_token, expiresAt: Date.now() + Number(token.expires_in || 3600) * 1000, scope: token.scope || '', profile: channel.items?.[0] || {} };
    } else {
      throw new Error('Unsupported platform');
    }

    await saveSocialConnection(connection);
    const response = NextResponse.redirect(new URL('/?accounts=connected', req.url));
    response.cookies.delete(`sp_oauth_state_${platform}`);
    return response;
  } catch (error) {
    const message = error instanceof Error ? error.message : 'OAuth connection failed';
    return NextResponse.redirect(new URL(`/?accounts=error&message=${encodeURIComponent(message)}`, req.url));
  }
}
