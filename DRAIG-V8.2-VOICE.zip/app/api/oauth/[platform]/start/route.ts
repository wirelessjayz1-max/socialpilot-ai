import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

export const runtime = 'nodejs';

function origin(req: NextRequest) {
  return req.nextUrl.origin || process.env.APP_URL || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : '');
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ platform: string }> }) {
  const { platform } = await params;
  const state = crypto.randomBytes(24).toString('hex');
  const redirectUri = `${origin(req)}/api/oauth/${platform}/callback`;
  let url: URL;

  if (platform === 'tiktok') {
    const key = process.env.TIKTOK_CLIENT_KEY;
    if (!key) return NextResponse.json({ error: 'TIKTOK_CLIENT_KEY is not configured' }, { status: 500 });
    url = new URL('https://www.tiktok.com/v2/auth/authorize/');
    url.searchParams.set('client_key', key);
    url.searchParams.set('scope', 'user.info.basic,video.publish');
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('redirect_uri', redirectUri);
    url.searchParams.set('state', state);
  } else if (platform === 'instagram') {
    const appId = process.env.META_APP_ID;
    if (!appId) return NextResponse.json({ error: 'META_APP_ID is not configured' }, { status: 500 });
    const version = process.env.META_GRAPH_VERSION || 'v24.0';
    url = new URL(`https://www.facebook.com/${version}/dialog/oauth`);
    url.searchParams.set('client_id', appId);
    url.searchParams.set('redirect_uri', redirectUri);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('scope', 'pages_show_list,pages_read_engagement,pages_manage_metadata,instagram_basic,instagram_content_publish,instagram_manage_messages');
    url.searchParams.set('state', state);
  } else if (platform === 'youtube') {
    const clientId = process.env.YOUTUBE_CLIENT_ID;
    if (!clientId) return NextResponse.json({ error: 'YOUTUBE_CLIENT_ID is not configured' }, { status: 500 });
    url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    url.searchParams.set('client_id', clientId);
    url.searchParams.set('redirect_uri', redirectUri);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('access_type', 'offline');
    url.searchParams.set('prompt', 'consent');
    url.searchParams.set('scope', 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly');
    url.searchParams.set('state', state);
  } else {
    return NextResponse.json({ error: 'Unsupported platform' }, { status: 400 });
  }

  const out = NextResponse.redirect(url);
  out.cookies.set(`sp_oauth_state_${platform}`, JSON.stringify({ state, redirectUri }), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 600,
    path: '/'
  });
  return out;
}
