import { NextRequest, NextResponse } from 'next/server';
import { getSocialConnection, getValidTikTokConnection } from '../../../lib/social-connections';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function instagramContainerReady(version: string, containerId: string, accessToken: string) {
  for (let i = 0; i < 15; i++) {
    const url = new URL(`https://graph.facebook.com/${version}/${containerId}`);
    url.searchParams.set('fields', 'status_code,status');
    url.searchParams.set('access_token', accessToken);
    const r = await fetch(url, { cache: 'no-store' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error?.message || 'Could not check Instagram upload status');
    if (d.status_code === 'FINISHED') return d;
    if (d.status_code === 'ERROR' || d.status_code === 'EXPIRED') throw new Error(d.status || `Instagram container ${d.status_code}`);
    await sleep(2000);
  }
  return null;
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const {
    platform,
    videoUrl,
    caption = '',
    title = '',
    privacyLevel,
    allowComment = true,
    allowDuet = true,
    allowStitch = true,
    consent = false,
    isAigc = true,
    promotesOwnBusiness = false,
    paidPartnership = false
  } = body || {};

  if (!platform || !videoUrl) return NextResponse.json({ error: 'platform and videoUrl are required' }, { status: 400 });
  if (!/^https:\/\//i.test(videoUrl)) return NextResponse.json({ error: 'Direct publishing requires a public HTTPS media URL.' }, { status: 400 });
  if (!consent) return NextResponse.json({ error: 'Explicit approval is required before publishing to a real social account.' }, { status: 400 });

  try {
    if (platform === 'tiktok') {
      const c = await getValidTikTokConnection();
      if (!c) return NextResponse.json({ error: 'TikTok is not connected' }, { status: 401 });

      const creatorR = await fetch('https://open.tiktokapis.com/v2/post/publish/creator_info/query/', {
        method: 'POST',
        headers: { Authorization: `Bearer ${c.accessToken}`, 'Content-Type': 'application/json; charset=UTF-8' },
        body: '{}', cache: 'no-store'
      });
      const creator = await creatorR.json().catch(() => ({}));
      if (!creatorR.ok || creator.error?.code && creator.error.code !== 'ok') return NextResponse.json(creator, { status: creatorR.status || 400 });
      const info = creator.data || {};
      const options: string[] = info.privacy_level_options || [];
      if (!privacyLevel || !options.includes(privacyLevel)) return NextResponse.json({ error: 'Choose one of the privacy levels currently allowed by the connected TikTok account.', creator: info }, { status: 400 });

      const postInfo = {
        title: `${caption || title}`.slice(0, 2200),
        privacy_level: privacyLevel,
        disable_comment: info.comment_disabled ? true : !allowComment,
        disable_duet: info.duet_disabled ? true : !allowDuet,
        disable_stitch: info.stitch_disabled ? true : !allowStitch,
        brand_content_toggle: Boolean(paidPartnership),
        brand_organic_toggle: Boolean(promotesOwnBusiness),
        is_aigc: Boolean(isAigc)
      };
      const r = await fetch('https://open.tiktokapis.com/v2/post/publish/video/init/', {
        method: 'POST',
        headers: { Authorization: `Bearer ${c.accessToken}`, 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify({ post_info: postInfo, source_info: { source: 'PULL_FROM_URL', video_url: videoUrl } }),
        cache: 'no-store'
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok || data.error?.code && data.error.code !== 'ok') return NextResponse.json(data, { status: r.status || 400 });
      return NextResponse.json({ ok: true, platform, pending: true, published: false, publishId: data.data?.publish_id, data: data.data, creator: info });
    }

    if (platform === 'instagram') {
      const c = await getSocialConnection('instagram');
      if (!c) return NextResponse.json({ error: 'Instagram is not connected' }, { status: 401 });
      if (!c.igUserId) return NextResponse.json({ error: 'Instagram Professional account ID is missing. Reconnect Instagram.' }, { status: 400 });
      const version = process.env.META_GRAPH_VERSION || 'v24.0';
      const createParams = new URLSearchParams({
        media_type: 'REELS',
        video_url: videoUrl,
        caption: String(caption || title).slice(0, 2200),
        share_to_feed: 'true',
        access_token: c.accessToken
      });
      const create = await fetch(`https://graph.facebook.com/${version}/${c.igUserId}/media`, { method: 'POST', body: createParams, cache: 'no-store' });
      const container = await create.json().catch(() => ({}));
      if (!create.ok || !container.id) return NextResponse.json(container, { status: create.status || 400 });

      const ready = await instagramContainerReady(version, container.id, c.accessToken);
      if (!ready) return NextResponse.json({ ok: true, platform, pending: true, published: false, containerId: container.id, message: 'Instagram accepted the Reel and is still processing it. Retry publish after processing finishes.' });

      const publish = await fetch(`https://graph.facebook.com/${version}/${c.igUserId}/media_publish`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ creation_id: container.id, access_token: c.accessToken }),
        cache: 'no-store'
      });
      const result = await publish.json().catch(() => ({}));
      if (!publish.ok || !result.id) return NextResponse.json(result, { status: publish.status || 400 });
      return NextResponse.json({ ok: true, platform, published: true, pending: false, containerId: container.id, mediaId: result.id });
    }

    if (platform === 'youtube') {
      const c = await getSocialConnection('youtube');
      if (!c) return NextResponse.json({ error: 'YouTube is not connected' }, { status: 401 });
      const media = await fetch(videoUrl, { cache: 'no-store' });
      if (!media.ok) return NextResponse.json({ error: 'Could not fetch the public video URL for YouTube upload' }, { status: 502 });
      const bytes = await media.arrayBuffer();
      const metadata = {
        snippet: { title: String(title || caption).slice(0, 100) || 'SocialPilot AI video', description: caption, tags: String(caption).match(/#[A-Za-z0-9_]+/g)?.map((x: string) => x.slice(1)) || [], categoryId: '22' },
        status: { privacyStatus: 'private', containsSyntheticMedia: Boolean(isAigc) }
      };
      const init = await fetch('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status', {
        method: 'POST',
        headers: { Authorization: `Bearer ${c.accessToken}`, 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': media.headers.get('content-type') || 'video/mp4', 'X-Upload-Content-Length': String(bytes.byteLength) },
        body: JSON.stringify(metadata), cache: 'no-store'
      });
      if (!init.ok) return NextResponse.json(await init.json().catch(() => ({ error: 'YouTube upload initialization failed' })), { status: init.status });
      const uploadUrl = init.headers.get('location');
      if (!uploadUrl) return NextResponse.json({ error: 'YouTube did not return an upload URL' }, { status: 502 });
      const upload = await fetch(uploadUrl, { method: 'PUT', headers: { Authorization: `Bearer ${c.accessToken}`, 'Content-Type': media.headers.get('content-type') || 'video/mp4', 'Content-Length': String(bytes.byteLength) }, body: bytes, cache: 'no-store' });
      const result = await upload.json().catch(() => ({}));
      if (!upload.ok) return NextResponse.json(result, { status: upload.status });
      return NextResponse.json({ ok: true, platform, published: true, mediaId: result.id, data: result });
    }

    return NextResponse.json({ error: 'Unsupported platform' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Publish failed' }, { status: 500 });
  }
}
