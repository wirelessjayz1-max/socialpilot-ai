import { NextRequest, NextResponse } from 'next/server';
import { getValidTikTokConnection } from '../../../../lib/social-connections';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  const publishId = req.nextUrl.searchParams.get('publishId');
  if (!publishId) return NextResponse.json({ error: 'Missing publishId' }, { status: 400 });
  try {
    const c = await getValidTikTokConnection();
    if (!c) return NextResponse.json({ error: 'TikTok is not connected' }, { status: 401 });
    const r = await fetch('https://open.tiktokapis.com/v2/post/publish/status/fetch/', { method: 'POST', headers: { Authorization: `Bearer ${c.accessToken}`, 'Content-Type': 'application/json; charset=UTF-8' }, body: JSON.stringify({ publish_id: publishId }), cache: 'no-store' });
    return NextResponse.json(await r.json().catch(() => ({})), { status: r.status });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : 'Status check failed' }, { status: 500 }); }
}
