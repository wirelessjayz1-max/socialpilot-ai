import { NextResponse } from 'next/server';
import { readCloudState } from '../../../lib/cloud-state';
import { listSocialConnections } from '../../../lib/social-connections';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const env = {
    gemini: Boolean(process.env.GOOGLE_GENERATIVE_AI_API_KEY),
    database: Boolean(process.env.DATABASE_URL),
    ownerKey: Boolean(process.env.SOCIALPILOT_OWNER_KEY),
    cronSecret: Boolean(process.env.CRON_SECRET),
    sessionSecret: Boolean(process.env.SOCIALPILOT_SESSION_SECRET),
    appUrl: true
  };

  const social = {
    tiktokConfigured: Boolean(process.env.TIKTOK_CLIENT_KEY && process.env.TIKTOK_CLIENT_SECRET),
    instagramConfigured: Boolean(process.env.META_APP_ID && process.env.META_APP_SECRET),
    instagramWebhookConfigured: Boolean(process.env.META_WEBHOOK_VERIFY_TOKEN),
    youtubeConfigured: Boolean(process.env.YOUTUBE_CLIENT_ID && process.env.YOUTUBE_CLIENT_SECRET)
  };

  let databaseReachable = false;
  let cloudStateFound = false;
  let cloudUpdatedAt: string | null = null;
  let databaseError: string | null = null;
  let accounts: any[] = [];

  if (env.database) {
    try {
      const state = await readCloudState();
      databaseReachable = true;
      cloudStateFound = Boolean(state);
      cloudUpdatedAt = state?.updatedAt || null;
      accounts = await listSocialConnections();
    } catch (error) {
      databaseError = error instanceof Error ? error.message : 'Database check failed';
    }
  }

  const configured = Object.values(env).every(Boolean);
  const ready = configured && databaseReachable;
  return NextResponse.json({
    ok: true,
    ready,
    version: '8.2.0-draig-voice',
    model: 'gemini-3.5-flash-lite',
    mode: 'free-first',
    env,
    social,
    connectedAccounts: accounts,
    database: { reachable: databaseReachable, cloudStateFound, updatedAt: cloudUpdatedAt, error: databaseError },
    autopilot: { schedule: '0 12 * * *', cadence: 'daily' },
    message: ready ? 'DRAIG V8.2 core is ready. Social connectors are optional and become active when their free developer credentials are configured.' : 'DRAIG is deployed, but one or more core launch requirements still need configuration.'
  }, { headers: { 'Cache-Control': 'no-store' } });
}
