import { NextResponse } from 'next/server';
import { writeAutopilotPatch } from '../../../../lib/cloud-state';

export const runtime = 'nodejs';

function authorized(req: Request) {
  const expected = process.env.SOCIALPILOT_OWNER_KEY;
  if (!expected) return false;
  return req.headers.get('x-socialpilot-owner-key') === expected;
}

export async function PUT(req: Request) {
  if (!authorized(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const state = await writeAutopilotPatch({
      autopilotTasks: Array.isArray(body?.autopilotTasks) ? body.autopilotTasks : undefined,
      autopilotSummary: typeof body?.autopilotSummary === 'string' ? body.autopilotSummary : undefined,
      autopilotEnabled: typeof body?.autopilotEnabled === 'boolean' ? body.autopilotEnabled : undefined,
      lastAutopilotRun: typeof body?.lastAutopilotRun === 'string' ? body.lastAutopilotRun : undefined,
      executionLog: Array.isArray(body?.executionLog) ? body.executionLog : undefined,
    });
    return NextResponse.json({ ok: true, state });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Could not save Autopilot state' }, { status: 500 });
  }
}
