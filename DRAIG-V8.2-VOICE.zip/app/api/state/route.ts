import { NextResponse } from 'next/server';
import { readCloudState, writeCloudState } from '../../../lib/cloud-state';

export const runtime = 'nodejs';

function authorized(req: Request) {
  const expected = process.env.SOCIALPILOT_OWNER_KEY;
  if (!expected) return false;
  return req.headers.get('x-socialpilot-owner-key') === expected;
}

export async function GET(req: Request) {
  if (!authorized(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const state = await readCloudState();
    return NextResponse.json({ state });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Cloud state unavailable' }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  if (!authorized(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const state = await writeCloudState(body?.state || {});
    return NextResponse.json({ ok: true, state });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Could not save cloud state' }, { status: 500 });
  }
}
