import { NextResponse } from 'next/server';
import { generateObject } from 'ai';
import { createGoogleGenerativeAI } from '@ai-sdk/google';
import { z } from 'zod';
import { readCloudState, writeAutopilotPatch, writeCloudState } from '../../../../lib/cloud-state';

export const runtime = 'nodejs';


const socialContentSchema = z.object({
  title: z.string(), hook: z.string(), script: z.string(), caption: z.string(), hashtags: z.array(z.string()), callToAction: z.string(), visualPlan: z.array(z.string())
});
const followupSchema = z.object({ subject: z.string(), message: z.string() });

const managerPlanSchema = z.object({
  summary: z.string(),
  tasks: z.array(z.object({
    title: z.string(),
    reason: z.string(),
    actionType: z.enum(['content','sales','business','review','publish']),
    priority: z.enum(['high','medium','low']),
    requiresApproval: z.boolean()
  })).min(3).max(8)
});

function cronAuthorized(req: Request) {
  const secret = process.env.CRON_SECRET;
  return Boolean(secret) && req.headers.get('authorization') === `Bearer ${secret}`;
}

export async function GET(req: Request) {
  if (!cronAuthorized(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const state: any = (await readCloudState()) || {};
    if (!state.autopilotEnabled) return NextResponse.json({ ok: true, skipped: true, reason: 'Autopilot is off.' });

    const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY;
    if (!apiKey) throw new Error('Missing GOOGLE_GENERATIVE_AI_API_KEY');
    const google = createGoogleGenerativeAI({ apiKey });
    const modelName = (process.env.AI_MODEL || 'google/gemini-3.5-flash-lite').split('/').slice(1).join('/') || 'gemini-3.5-flash-lite';

    const savedPosts: any[] = Array.isArray(state.savedPosts) ? state.savedPosts : [];
    const leads: any[] = Array.isArray(state.leads) ? state.leads : [];
    const businessPlan: any = state.businessPlan || null;
    const funnelPlan: any = state.funnelPlan || null;
    const websitePlan: any = state.websitePlan || null;
    const revenueEntries: any[] = Array.isArray(state.revenueEntries) ? state.revenueEntries : [];
    const orders: any[] = Array.isArray(state.orders) ? state.orders : [];
    const supportTickets: any[] = Array.isArray(state.supportTickets) ? state.supportTickets : [];
    const retentionActions: any[] = Array.isArray(state.retentionActions) ? state.retentionActions : [];
    const performanceMetrics: any[] = Array.isArray(state.performanceMetrics) ? state.performanceMetrics : [];
    const optimizationAdvice: any = state.optimizationAdvice || null;
    const revenueGoal = Number(state.revenueGoal || 0);
    const revenueTotal = revenueEntries.filter(e => e.kind === 'revenue').reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const expenseTotal = revenueEntries.filter(e => e.kind === 'expense').reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const today = new Date().toISOString().slice(0, 10);
    const activeLeads = leads.filter(l => l.status !== 'customer' && l.status !== 'lost');
    const customers = leads.filter(l => l.status === 'customer');
    const dueLeads = leads.filter(l => l.followUpDate && l.followUpDate <= today && l.status !== 'customer' && l.status !== 'lost').slice(0, 8);
    const pipeline = activeLeads.reduce((sum, l) => sum + (Number(l.value) || 0), 0);

    const topPerformance = performanceMetrics.length
      ? [...performanceMetrics].sort((a, b) => ((Number(b.revenue) || 0) - (Number(a.revenue) || 0)) || ((Number(b.sales) || 0) - (Number(a.sales) || 0)) || ((Number(b.leads) || 0) - (Number(a.leads) || 0)) || ((Number(b.clicks) || 0) - (Number(a.clicks) || 0)))[0]
      : null;

    const context = {
      business: businessPlan ? { name: businessPlan.businessName, niche: businessPlan.niche, offer: businessPlan.offer, goal: businessPlan.thirtyDayGoal } : null,
      content: {
        total: savedPosts.length,
        drafts: savedPosts.filter(p => p.status === 'draft').length,
        ready: savedPosts.filter(p => p.status === 'ready').length,
        published: savedPosts.filter(p => p.status === 'published').length,
        recent: savedPosts.slice(0, 5).map(p => p.title)
      },
      sales: { activeLeads: activeLeads.length, customers: customers.length, pipeline, followupsDue: dueLeads.length, dueLeads: dueLeads.map(l => ({ name: l.name, status: l.status, offer: l.offer })) },
      revenue: { goal: revenueGoal, revenue: revenueTotal, expenses: expenseTotal, profit: revenueTotal - expenseTotal },
      orders: { total: orders.length, new: orders.filter(o => o.status === 'new').length, paid: orders.filter(o => o.status === 'paid').length, fulfilling: orders.filter(o => o.status === 'fulfilling').length, completed: orders.filter(o => o.status === 'completed').length, value: orders.filter(o => o.status !== 'cancelled').reduce((sum, o) => sum + (Number(o.amount) || 0), 0) },
      customerOps: { openSupport: supportTickets.filter(t => t.status !== 'resolved').length, highPrioritySupport: supportTickets.filter(t => t.status !== 'resolved' && t.priority === 'high').length, retentionDue: retentionActions.filter(a => !a.done && a.dueDate && a.dueDate <= today).length },
      analytics: {
        records: performanceMetrics.slice(0,20),
        latestOptimization: optimizationAdvice,
        topPerformer: topPerformance ? {
          campaign: topPerformance.campaign, channel: topPerformance.channel, impressions: Number(topPerformance.impressions) || 0, clicks: Number(topPerformance.clicks) || 0, leads: Number(topPerformance.leads) || 0, sales: Number(topPerformance.sales) || 0, revenue: Number(topPerformance.revenue) || 0,
          ctrPct: Number(topPerformance.impressions) ? Number((((Number(topPerformance.clicks) || 0) / Number(topPerformance.impressions)) * 100).toFixed(1)) : 0,
          leadRatePct: Number(topPerformance.clicks) ? Number((((Number(topPerformance.leads) || 0) / Number(topPerformance.clicks)) * 100).toFixed(1)) : 0,
          salesRatePct: Number(topPerformance.leads) ? Number((((Number(topPerformance.sales) || 0) / Number(topPerformance.leads)) * 100).toFixed(1)) : 0
        } : null
      },
      funnel: funnelPlan ? { offer: funnelPlan.offerName, audience: funnelPlan.audience, leadMagnet: funnelPlan.leadMagnetTitle, cta: funnelPlan.callToAction, steps: funnelPlan.funnelSteps } : null,
      website: websitePlan ? { siteName: websitePlan.siteName, headline: websitePlan.heroHeadline, products: websitePlan.products?.map((p:any)=>({ name:p.name, price:p.price })), published: Boolean(state.websitePublished) } : null
    };

    const result = await generateObject({
      model: google(modelName),
      schema: managerPlanSchema,
      system: `You are DRAIG's scheduled Autonomous Business Manager. Create a focused daily operating plan for a solo online business. Planning, drafting, analysis, CRM updates, and content preparation may be prepared automatically. Publishing, spending money, changing accounts, legal actions, deleting important data, or sending messages to real people must require approval. Never claim an external action happened unless another system actually performed it. IMPORTANT ANALYTICS RULE: when analytics.topPerformer or analytics.latestOptimization is present, explicitly use that evidence in the plan. Unless an urgent customer/support issue is more important, include at least one HIGH-priority task that repeats, repurposes, distributes, or tests a variation of the proven winning campaign/channel. Name the winning campaign/channel and cite its supplied performance numbers in the task reason. Do not replace evidence-based actions with generic 'make more content' advice.`,
      prompt: `Create today's operating plan from this cloud business context:\n\n${JSON.stringify(context)}`
    });

    const tasks = result.object.tasks.map((task) => ({
      ...task,
      id: crypto.randomUUID(),
      status: task.requiresApproval ? 'pending' : 'approved'
    }));

    // V7 cloud executor: run only safe tasks that do not require user approval or browser-bound connectors.
    // External publishing, spending, account changes, and real-person outreach are never performed here.
    const executionLog: any[] = Array.isArray(state.executionLog) ? [...state.executionLog] : [];
    let nextPosts = [...savedPosts];
    const executedTasks = [] as any[];

    for (const original of tasks) {
      const task: any = { ...original };
      if (task.requiresApproval || task.status !== 'approved' || task.actionType === 'publish') { executedTasks.push(task); continue; }
      const startedAt = new Date().toISOString();
      executionLog.unshift({ id: crypto.randomUUID(), taskId: task.id, title: task.title, actionType: task.actionType, status: 'running', message: 'Scheduled V7 execution started', createdAt: startedAt });
      try {
        let message = '';
        if (task.actionType === 'content') {
          const content = await generateObject({
            model: google(modelName), schema: socialContentSchema,
            system: `You are DRAIG V7's Execution Engine. Create an original, platform-native short-form content package. Do not invent results or guarantees. Keep the script under 140 words and the visual plan to 5-7 practical shots.`,
            prompt: `Execute this approved safe content task:
Title: ${task.title}
Reason: ${task.reason}
Business: ${businessPlan?.businessName || 'current business'}
Offer: ${businessPlan?.offer || funnelPlan?.offerName || 'current offer'}`
          });
          const post = { ...content.object, id: crypto.randomUUID(), idea: task.title, platform: 'TikTok / Reels / Shorts', tone: 'high-energy', createdAt: new Date().toISOString(), status: 'draft', aiModel: `google/${modelName}`, aiProvider: 'google' };
          nextPosts = [post, ...nextPosts];
          message = `Created draft content package: ${post.title}.`;
        } else if (task.actionType === 'sales') {
          const lead = dueLeads[0] || activeLeads[0];
          if (!lead) throw new Error('No active lead is available for this sales action.');
          const followup = await generateObject({
            model: google(modelName), schema: followupSchema,
            system: `You are DRAIG V7's Sales Assistant. Prepare a concise, natural follow-up draft. Never claim it was sent and never invent discounts, facts, deadlines, or guarantees.`,
            prompt: `Prepare, but do not send, a follow-up for ${lead.name}. Source: ${lead.source || 'unknown'}. Offer: ${lead.offer || businessPlan?.offer || 'current offer'}. Stage: ${lead.status}. Notes: ${lead.notes || 'none'}. Task: ${task.title}.`
          });
          message = `Prepared follow-up for ${lead.name}: ${followup.object.subject}. Draft: ${followup.object.message}`;
        } else if (task.actionType === 'review') {
          message = `Internal review completed: ${savedPosts.length} content items, ${leads.length} CRM records, $${revenueTotal.toFixed(2)} revenue, $${expenseTotal.toFixed(2)} expenses.`;
        } else {
          // Business/funnel/site generation is left approved for the browser executor, where the user can inspect the generated artifact immediately.
          executedTasks.push(task);
          continue;
        }
        const completedAt = new Date().toISOString();
        task.status = 'completed'; task.result = message; task.startedAt = startedAt; task.completedAt = completedAt;
        executionLog.unshift({ id: crypto.randomUUID(), taskId: task.id, title: task.title, actionType: task.actionType, status: 'completed', message, createdAt: completedAt });
      } catch (e) {
        const failedAt = new Date().toISOString();
        const message = e instanceof Error ? e.message : 'Scheduled execution failed';
        task.status = 'failed'; task.error = message; task.startedAt = startedAt; task.completedAt = failedAt;
        executionLog.unshift({ id: crypto.randomUUID(), taskId: task.id, title: task.title, actionType: task.actionType, status: 'failed', message, createdAt: failedAt });
      }
      executedTasks.push(task);
    }

    if (nextPosts.length !== savedPosts.length) await writeCloudState({ savedPosts: nextPosts });
    await writeAutopilotPatch({
      autopilotTasks: executedTasks,
      autopilotSummary: result.object.summary,
      executionLog: executionLog.slice(0, 100),
      lastAutopilotRun: new Date().toISOString()
    });
    return NextResponse.json({ ok: true, tasks: executedTasks.length, executed: executedTasks.filter(t => t.status === 'completed').length, summary: result.object.summary });
  } catch (error) {
    console.error('Scheduled autopilot failed:', error);
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Scheduled autopilot failed' }, { status: 500 });
  }
}
