import { NextRequest, NextResponse } from 'next/server';
import { deleteSocialConnection, listSocialConnections, type SocialPlatform } from '../../../lib/social-connections';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    return NextResponse.json({ accounts: await listSocialConnections() });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Could not load accounts', accounts: [] }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const platform = req.nextUrl.searchParams.get('platform') as SocialPlatform | null;
  if (!platform || !['tiktok', 'instagram', 'youtube'].includes(platform)) return NextResponse.json({ error: 'Unsupported platform' }, { status: 400 });
  try {
    await deleteSocialConnection(platform);
    return NextResponse.json({ ok: true, platform });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Could not disconnect account' }, { status: 500 });
  }
}
