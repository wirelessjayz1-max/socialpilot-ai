import { readCloudState } from '../../lib/cloud-state';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

type WebsitePlan = {
  siteName?: string;
  tagline?: string;
  heroHeadline?: string;
  heroSubheadline?: string;
  about?: string;
  products?: { name?: string; description?: string; price?: string; buttonLabel?: string }[];
  benefits?: string[];
  faq?: { question?: string; answer?: string }[];
  finalCta?: string;
  contactText?: string;
  actionUrl?: string;
};

function safeHref(value?: string) {
  if (!value) return '#contact';
  try {
    const url = new URL(value);
    if (['http:', 'https:', 'mailto:', 'tel:'].includes(url.protocol)) return value;
  } catch {}
  return '#contact';
}

export default async function PublicStorefront() {
  let state: any = null;
  try { state = await readCloudState(); } catch {}
  const plan: WebsitePlan | null = state?.websitePlan || null;
  const published = Boolean(state?.websitePublished && plan);

  if (!published || !plan) {
    return (
      <main style={{minHeight:'100vh',display:'grid',placeItems:'center',padding:24,fontFamily:'Arial, sans-serif',background:'#f7f7f8',color:'#171717'}}>
        <div style={{maxWidth:640,textAlign:'center',background:'white',padding:32,borderRadius:22,border:'1px solid #e5e5e5'}}>
          <div style={{fontSize:38}}>✦</div>
          <h1 style={{fontSize:30,margin:'12px 0'}}>This DRAIG storefront is not published yet.</h1>
          <p style={{lineHeight:1.6,color:'#666'}}>The owner can publish it from DRAIG → Website.</p>
        </div>
      </main>
    );
  }

  const actionHref = safeHref(plan.actionUrl);
  const products = Array.isArray(plan.products) ? plan.products : [];
  const benefits = Array.isArray(plan.benefits) ? plan.benefits : [];
  const faq = Array.isArray(plan.faq) ? plan.faq : [];

  return (
    <main style={{fontFamily:'Arial, sans-serif',color:'#171717',background:'#fff'}}>
      <header style={{maxWidth:1100,margin:'0 auto',padding:'26px 24px',display:'flex',justifyContent:'space-between',gap:20,alignItems:'center'}}>
        <strong style={{fontSize:20}}>{plan.siteName || 'Online Store'}</strong>
        <a href={actionHref} style={{textDecoration:'none',color:'#171717',fontWeight:700}}>Get started →</a>
      </header>

      <section style={{padding:'78px 24px 88px',background:'linear-gradient(180deg,#f5f5f7 0%,#fff 100%)'}}>
        <div style={{maxWidth:900,margin:'0 auto',textAlign:'center'}}>
          <p style={{fontWeight:800,letterSpacing:1.5,textTransform:'uppercase',fontSize:12}}>{plan.tagline}</p>
          <h1 style={{fontSize:'clamp(42px,8vw,78px)',lineHeight:1.02,margin:'16px 0 22px',letterSpacing:-2}}>{plan.heroHeadline}</h1>
          <p style={{fontSize:20,lineHeight:1.6,color:'#555',maxWidth:720,margin:'0 auto 30px'}}>{plan.heroSubheadline}</p>
          <a href={actionHref} style={{display:'inline-block',background:'#171717',color:'#fff',padding:'16px 24px',borderRadius:999,textDecoration:'none',fontWeight:800}}>Get started</a>
        </div>
      </section>

      {benefits.length > 0 && <section style={{maxWidth:1050,margin:'0 auto',padding:'60px 24px'}}>
        <h2 style={{fontSize:36,marginBottom:26}}>Why this offer</h2>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:16}}>{benefits.map((b,i)=><div key={i} style={{padding:22,border:'1px solid #e8e8e8',borderRadius:18,lineHeight:1.55}}><strong>✓</strong> {b}</div>)}</div>
      </section>}

      {products.length > 0 && <section style={{background:'#f7f7f8',padding:'68px 24px'}}>
        <div style={{maxWidth:1050,margin:'0 auto'}}>
          <h2 style={{fontSize:36,margin:'0 0 28px'}}>Choose your offer</h2>
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:18}}>{products.map((p,i)=><article key={i} style={{background:'#fff',padding:26,borderRadius:22,border:'1px solid #e5e5e5'}}><div style={{fontWeight:800,fontSize:14}}>{p.price}</div><h3 style={{fontSize:26,margin:'12px 0'}}>{p.name}</h3><p style={{color:'#666',lineHeight:1.6,minHeight:76}}>{p.description}</p><a href={actionHref} style={{display:'inline-block',marginTop:12,textDecoration:'none',background:'#171717',color:'#fff',padding:'12px 18px',borderRadius:999,fontWeight:800}}>{p.buttonLabel || 'Get started'}</a></article>)}</div>
        </div>
      </section>}

      <section style={{maxWidth:900,margin:'0 auto',padding:'68px 24px'}}>
        <h2 style={{fontSize:36}}>About</h2>
        <p style={{fontSize:19,lineHeight:1.75,color:'#555'}}>{plan.about}</p>
      </section>

      {faq.length > 0 && <section style={{maxWidth:900,margin:'0 auto',padding:'20px 24px 68px'}}>
        <h2 style={{fontSize:36}}>Frequently asked questions</h2>
        <div>{faq.map((f,i)=><details key={i} style={{padding:'18px 0',borderBottom:'1px solid #e8e8e8'}}><summary style={{fontWeight:800,cursor:'pointer'}}>{f.question}</summary><p style={{color:'#666',lineHeight:1.6}}>{f.answer}</p></details>)}</div>
      </section>}

      <section id="contact" style={{background:'#171717',color:'#fff',padding:'70px 24px',textAlign:'center'}}>
        <div style={{maxWidth:760,margin:'0 auto'}}><h2 style={{fontSize:42,margin:'0 0 16px'}}>{plan.finalCta}</h2><p style={{color:'#ccc',fontSize:18,lineHeight:1.6}}>{plan.contactText}</p><a href={actionHref} style={{display:'inline-block',marginTop:18,textDecoration:'none',background:'#fff',color:'#171717',padding:'14px 22px',borderRadius:999,fontWeight:800}}>Take the next step</a></div>
      </section>

      <footer style={{padding:'28px 24px',textAlign:'center',color:'#777',fontSize:13}}>Built with DRAIG</footer>
    </main>
  );
}
