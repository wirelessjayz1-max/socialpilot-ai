"use client";

import { useEffect, useRef, useState } from "react";

type Generated = {
  title: string; hook: string; script: string; caption: string; hashtags: string[]; callToAction: string; visualPlan: string[];
  aiModel?: string; aiProvider?: string;
};

type VideoJob = { videoId?: string; sessionId?: string; status: string; videoUrl?: string; error?: string; localFile?: boolean; fileName?: string };
type SavedPost = Generated & { id: string; idea: string; platform: string; tone: string; createdAt: string; status: "draft" | "ready" | "published"; videoUrl?: string; videoFileName?: string };
type CopilotIdea = { title: string; angle: string; hook: string };
type BusinessPlan = { businessName: string; niche: string; targetCustomer: string; problemSolved: string; offer: string; pricing: string; businessModel: string; positioning: string; launchSteps: string[]; firstProducts: string[]; marketingChannels: string[]; first10Posts: string[]; thirtyDayGoal: string; aiModel?: string; aiProvider?: string };
type LeadStatus = "new" | "contacted" | "interested" | "customer" | "lost";
type Lead = { id: string; name: string; contact: string; source: string; offer: string; value: number; status: LeadStatus; followUpDate: string; notes: string; createdAt: string };
type FollowupDraft = { subject: string; message: string };
type ActionStatus = "pending" | "approved" | "running" | "completed" | "failed" | "queued" | "done";
type AutopilotTask = {
  id: string; title: string; reason: string;
  actionType: "content" | "sales" | "business" | "review" | "publish";
  priority: "high" | "medium" | "low"; requiresApproval: boolean; status: ActionStatus;
  targetId?: string; result?: string; error?: string; startedAt?: string; completedAt?: string;
};
type ExecutionRecord = { id: string; taskId: string; title: string; actionType: AutopilotTask["actionType"]; status: "running" | "completed" | "failed"; message: string; createdAt: string };

function canonicalActionStatus(status: ActionStatus | string): "pending" | "approved" | "running" | "completed" | "failed" {
  if (status === "queued") return "pending";
  if (status === "done") return "completed";
  if (["pending","approved","running","completed","failed"].includes(status)) return status as any;
  return "pending";
}
function normalizeAutopilotTask(task: any): AutopilotTask { return { ...task, status: canonicalActionStatus(task?.status || (task?.requiresApproval ? "pending" : "approved")) }; }
type RevenueEntry = { id: string; kind: "revenue" | "expense"; amount: number; label: string; date: string; createdAt: string };
type RevenueAdvice = { summary: string; nextMove: string; why: string; target: string; actions: string[] };
type FunnelPlan = {
  funnelName: string; offerName: string; audience: string; promise: string; price: string;
  leadMagnetTitle: string; leadMagnetOutline: string[]; landingHeadline: string; landingSubheadline: string;
  benefits: string[]; callToAction: string; funnelSteps: string[];
  followupSequence: { day: string; subject: string; message: string }[]; contentAngles: string[];
  aiModel?: string; aiProvider?: string;
};
type WebsitePlan = {
  siteName: string; tagline: string; heroHeadline: string; heroSubheadline: string; about: string;
  products: { name: string; description: string; price: string; buttonLabel: string }[];
  benefits: string[]; faq: { question: string; answer: string }[]; finalCta: string; contactText: string;
  actionUrl?: string; aiModel?: string; aiProvider?: string;
};
type OrderStatus = "new" | "paid" | "fulfilling" | "completed" | "cancelled";
type Order = { id: string; customerName: string; contact: string; item: string; amount: number; status: OrderStatus; source: string; notes: string; createdAt: string; revenueLinked?: boolean };
type SupportStatus = "open" | "waiting" | "resolved";
type SupportTicket = { id: string; customerName: string; contact: string; subject: string; message: string; status: SupportStatus; priority: "high" | "medium" | "low"; createdAt: string; lastReply?: string };
type RetentionAction = { id: string; customerName: string; contact: string; kind: "review" | "reengage" | "followup"; dueDate: string; notes: string; done: boolean; createdAt: string };
type SupportReply = { subject: string; message: string };
type PerformanceMetric = { id: string; channel: string; campaign: string; impressions: number; clicks: number; leads: number; sales: number; revenue: number; date: string; notes: string; createdAt: string };
type OptimizationAdvice = { summary: string; working: string[]; improve: string[]; nextExperiment: string; actions: string[] };
type LaunchHealth = {
  ready: boolean; version: string; model: string; mode: string;
  env: { gemini: boolean; database: boolean; ownerKey: boolean; cronSecret: boolean; sessionSecret: boolean; appUrl: boolean };
  database: { reachable: boolean; cloudStateFound: boolean; updatedAt?: string | null; error?: string | null };
  autopilot: { schedule: string; cadence: string };
  social?: { tiktokConfigured: boolean; instagramConfigured: boolean; instagramWebhookConfigured: boolean; youtubeConfigured: boolean };
  message: string;
};
type InstagramConversation = { id: string; updated_time?: string; participants?: { data?: any[] }; messages?: { data?: any[] } };

type AccountLaunchPlan = {
  brandName: string; niche: string; audience: string; positioning: string; displayName: string;
  usernameIdeas: string[]; tiktokBio: string; instagramBio: string; youtubeDescription: string;
  profileImagePrompt: string; bannerPrompt: string; category: string; linkInBioText: string;
  launchChecklist: { platform: "TikTok" | "Instagram" | "YouTube" | "All"; title: string; instruction: string; humanRequired: boolean }[];
  first7Posts: { day: string; platform: string; title: string; hook: string; goal: string }[];
  firstWeekGoal: string; safetyNotes: string[]; aiModel?: string; aiProvider?: string;
};

export default function Home() {
  const [idea, setIdea] = useState("");
  const [platform, setPlatform] = useState("TikTok / Reels / Shorts");
  const [tone, setTone] = useState("high-energy");
  const [tab, setTab] = useState("Create");
  const [loading, setLoading] = useState(false);
  const [videoLoading, setVideoLoading] = useState(false);
  const [result, setResult] = useState<Generated | null>(null);
  const [video, setVideo] = useState<VideoJob | null>(null);
  const [error, setError] = useState("");
  const [accounts, setAccounts] = useState<any[]>([]);
  const [publishPlatform, setPublishPlatform] = useState("tiktok");
  const [privacyLevel, setPrivacyLevel] = useState("");
  const [creatorInfo, setCreatorInfo] = useState<any>(null);
  const [publishing, setPublishing] = useState(false);
  const [publishResult, setPublishResult] = useState<any>(null);
  const [disconnecting, setDisconnecting] = useState("");
  const [publishConsent, setPublishConsent] = useState(false);
  const [isAigc, setIsAigc] = useState(true);
  const [promotesOwnBusiness, setPromotesOwnBusiness] = useState(false);
  const [paidPartnership, setPaidPartnership] = useState(false);
  const [tiktokPublishId, setTiktokPublishId] = useState("");
  const [instagramConversations, setInstagramConversations] = useState<InstagramConversation[]>([]);
  const [instagramLoading, setInstagramLoading] = useState(false);
  const [instagramReplyDrafts, setInstagramReplyDrafts] = useState<Record<string,string>>({});
  const [instagramSendingId, setInstagramSendingId] = useState("");
  const [instagramMessageStatus, setInstagramMessageStatus] = useState("");
  const [savedPosts, setSavedPosts] = useState<SavedPost[]>([]);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [libraryQuery, setLibraryQuery] = useState("");
  const [libraryFilter, setLibraryFilter] = useState("all");
  const [scheduleDates, setScheduleDates] = useState<Record<string, string>>({});
  const [heygenPrompt, setHeygenPrompt] = useState("");
  const [finishedVideoUrl, setFinishedVideoUrl] = useState("");
  const [copilotTopic, setCopilotTopic] = useState("");
  const [copilotIdeas, setCopilotIdeas] = useState<CopilotIdea[]>([]);
  const [copilotLoading, setCopilotLoading] = useState(false);
  const [businessBrief, setBusinessBrief] = useState("");
  const [businessPlan, setBusinessPlan] = useState<BusinessPlan | null>(null);
  const [businessLoading, setBusinessLoading] = useState(false);
  const [accountLaunchBrief, setAccountLaunchBrief] = useState("");
  const [accountLaunchPlan, setAccountLaunchPlan] = useState<AccountLaunchPlan | null>(null);
  const [accountLaunchLoading, setAccountLaunchLoading] = useState(false);
  const [accountLaunchCompleted, setAccountLaunchCompleted] = useState<number[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [leadName, setLeadName] = useState("");
  const [leadContact, setLeadContact] = useState("");
  const [leadSource, setLeadSource] = useState("TikTok");
  const [leadOffer, setLeadOffer] = useState("");
  const [leadValue, setLeadValue] = useState("");
  const [leadFollowUpDate, setLeadFollowUpDate] = useState("");
  const [leadNotes, setLeadNotes] = useState("");
  const [leadFilter, setLeadFilter] = useState<"all" | LeadStatus>("all");
  const [followupDrafts, setFollowupDrafts] = useState<Record<string, FollowupDraft>>({});
  const [followupLoadingId, setFollowupLoadingId] = useState("");
  const [autopilotEnabled, setAutopilotEnabled] = useState(false);
  const [autopilotSummary, setAutopilotSummary] = useState("");
  const [autopilotTasks, setAutopilotTasks] = useState<AutopilotTask[]>([]);
  const [autopilotLoading, setAutopilotLoading] = useState(false);
  const [executionLog, setExecutionLog] = useState<ExecutionRecord[]>([]);
  const [executionBusyId, setExecutionBusyId] = useState("");
  const [cloudOwnerKey, setCloudOwnerKey] = useState("");
  const [cloudStatus, setCloudStatus] = useState("Local only");
  const [cloudBusy, setCloudBusy] = useState(false);
  const [lastCloudSync, setLastCloudSync] = useState("");
  const [launchHealth, setLaunchHealth] = useState<LaunchHealth | null>(null);
  const [launchHealthLoading, setLaunchHealthLoading] = useState(false);
  const [revenueGoal, setRevenueGoal] = useState(500);
  const [revenueEntries, setRevenueEntries] = useState<RevenueEntry[]>([]);
  const [moneyKind, setMoneyKind] = useState<"revenue" | "expense">("revenue");
  const [moneyAmount, setMoneyAmount] = useState("");
  const [moneyLabel, setMoneyLabel] = useState("");
  const [moneyDate, setMoneyDate] = useState(new Date().toISOString().slice(0,10));
  const [revenueAdvice, setRevenueAdvice] = useState<RevenueAdvice | null>(null);
  const [revenueLoading, setRevenueLoading] = useState(false);
  const [funnelBrief, setFunnelBrief] = useState("");
  const [funnelPlan, setFunnelPlan] = useState<FunnelPlan | null>(null);
  const [funnelLoading, setFunnelLoading] = useState(false);
  const [websiteBrief, setWebsiteBrief] = useState("");
  const [websitePlan, setWebsitePlan] = useState<WebsitePlan | null>(null);
  const [websiteActionUrl, setWebsiteActionUrl] = useState("");
  const [websitePublished, setWebsitePublished] = useState(false);
  const [websiteLoading, setWebsiteLoading] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderCustomerName, setOrderCustomerName] = useState("");
  const [orderContact, setOrderContact] = useState("");
  const [orderItem, setOrderItem] = useState("");
  const [orderAmount, setOrderAmount] = useState("");
  const [orderSource, setOrderSource] = useState("Website");
  const [orderNotes, setOrderNotes] = useState("");
  const [orderFilter, setOrderFilter] = useState<"all" | OrderStatus>("all");
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [supportName, setSupportName] = useState("");
  const [supportContact, setSupportContact] = useState("");
  const [supportSubject, setSupportSubject] = useState("");
  const [supportMessage, setSupportMessage] = useState("");
  const [supportPriority, setSupportPriority] = useState<"high" | "medium" | "low">("medium");
  const [supportFilter, setSupportFilter] = useState<"all" | SupportStatus>("all");
  const [supportReplyDrafts, setSupportReplyDrafts] = useState<Record<string, SupportReply>>({});
  const [supportReplyLoadingId, setSupportReplyLoadingId] = useState("");
  const [retentionActions, setRetentionActions] = useState<RetentionAction[]>([]);
  const [retentionCustomer, setRetentionCustomer] = useState("");
  const [retentionContact, setRetentionContact] = useState("");
  const [retentionKind, setRetentionKind] = useState<"review" | "reengage" | "followup">("review");
  const [retentionDate, setRetentionDate] = useState(new Date().toISOString().slice(0,10));
  const [retentionNotes, setRetentionNotes] = useState("");
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetric[]>([]);
  const [metricChannel, setMetricChannel] = useState("TikTok");
  const [metricCampaign, setMetricCampaign] = useState("");
  const [metricImpressions, setMetricImpressions] = useState("");
  const [metricClicks, setMetricClicks] = useState("");
  const [metricLeads, setMetricLeads] = useState("");
  const [metricSales, setMetricSales] = useState("");
  const [metricRevenue, setMetricRevenue] = useState("");
  const [metricDate, setMetricDate] = useState(new Date().toISOString().slice(0,10));
  const [metricNotes, setMetricNotes] = useState("");
  const [optimizationAdvice, setOptimizationAdvice] = useState<OptimizationAdvice | null>(null);
  const [optimizationLoading, setOptimizationLoading] = useState(false);

  // DRAIG V8.2 Voice: browser-native speech recognition + speech synthesis.
  // Voice stays off until the user explicitly enables microphone access.
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [voiceAvailable, setVoiceAvailable] = useState(true);
  const [voiceStatus, setVoiceStatus] = useState("Voice off");
  const [voiceTranscript, setVoiceTranscript] = useState("");
  const [voiceName, setVoiceName] = useState("");
  const [voiceOptions, setVoiceOptions] = useState<SpeechSynthesisVoice[]>([]);
  const [voicePendingAction, setVoicePendingAction] = useState<"publish" | null>(null);
  const recognitionRef = useRef<any>(null);
  const voiceEnabledRef = useRef(false);
  const awaitingVoiceCommandRef = useRef(false);
  const voicePendingActionRef = useRef<"publish" | null>(null);
  const voiceCommandHandlerRef = useRef<(command: string) => Promise<void> | void>(() => {});

  useEffect(() => {
    if (typeof window === "undefined") return;
    const SpeechRecognitionCtor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    setVoiceAvailable(Boolean(SpeechRecognitionCtor && window.speechSynthesis));
    const loadVoices = () => {
      const voices = window.speechSynthesis?.getVoices?.() || [];
      setVoiceOptions(voices);
      if (!voiceName && voices.length) {
        const preferred = voices.find(v => /en[-_]US/i.test(v.lang)) || voices.find(v => /^en/i.test(v.lang)) || voices[0];
        setVoiceName(preferred?.name || "");
      }
    };
    loadVoices();
    window.speechSynthesis?.addEventListener?.("voiceschanged", loadVoices);
    return () => window.speechSynthesis?.removeEventListener?.("voiceschanged", loadVoices);
  }, []);

  useEffect(() => () => {
    voiceEnabledRef.current = false;
    try { recognitionRef.current?.stop?.(); } catch {}
    try { window.speechSynthesis?.cancel(); } catch {}
  }, []);

  async function loadAccounts() { const r = await fetch("/api/accounts", { cache: "no-store" }); const d = await r.json(); setAccounts(d.accounts || []); }

  async function loadInstagramConversations() {
    setInstagramLoading(true); setInstagramMessageStatus("");
    try {
      const r = await fetch("/api/instagram/conversations", { cache: "no-store" });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error?.message || d.error || "Could not load Instagram inbox");
      setInstagramConversations(d.conversations || []);
    } catch (e) { setInstagramMessageStatus(e instanceof Error ? e.message : "Could not load Instagram inbox"); }
    finally { setInstagramLoading(false); }
  }

  function instagramRecipient(convo: InstagramConversation) {
    const ig = accounts.find(a=>a.platform==="instagram");
    const own = new Set([String(ig?.pageId || ""), String(ig?.igUserId || ""), String(ig?.profile?.id || "")]);
    return (convo.participants?.data || []).find((p:any)=>p?.id && !own.has(String(p.id))) || (convo.participants?.data || [])[0] || null;
  }

  async function sendInstagramReply(convo: InstagramConversation) {
    const recipient = instagramRecipient(convo);
    const message = (instagramReplyDrafts[convo.id] || "").trim();
    if (!recipient?.id || !message) { setInstagramMessageStatus("Choose a conversation and write a reply first."); return; }
    setInstagramSendingId(convo.id); setInstagramMessageStatus("");
    try {
      const r = await fetch("/api/instagram/messages", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ recipientId:String(recipient.id), message, approved:true }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error?.message || d.error || "Instagram message failed");
      setInstagramReplyDrafts(prev=>({...prev,[convo.id]:""}));
      setInstagramMessageStatus(`Message sent to ${recipient.username || recipient.name || "Instagram user"}.`);
      await loadInstagramConversations();
    } catch (e) { setInstagramMessageStatus(e instanceof Error ? e.message : "Instagram message failed"); }
    finally { setInstagramSendingId(""); }
  }
  useEffect(() => {
    loadAccounts();
    try { setSavedPosts(JSON.parse(localStorage.getItem("socialpilot_saved_posts") || "[]")); } catch { setSavedPosts([]); }
    try { setBusinessPlan(JSON.parse(localStorage.getItem("socialpilot_business_plan") || "null")); } catch { setBusinessPlan(null); }
    try { setAccountLaunchPlan(JSON.parse(localStorage.getItem("socialpilot_account_launch_plan") || "null")); } catch { setAccountLaunchPlan(null); }
    try { setAccountLaunchCompleted(JSON.parse(localStorage.getItem("socialpilot_account_launch_completed") || "[]")); } catch { setAccountLaunchCompleted([]); }
    try { setLeads(JSON.parse(localStorage.getItem("socialpilot_leads") || "[]")); } catch { setLeads([]); }
    try { setAutopilotEnabled(localStorage.getItem("socialpilot_autopilot_enabled") === "true"); } catch {}
    try { setAutopilotTasks((JSON.parse(localStorage.getItem("socialpilot_autopilot_tasks") || "[]") || []).map(normalizeAutopilotTask)); } catch { setAutopilotTasks([]); }
    try { setExecutionLog(JSON.parse(localStorage.getItem("socialpilot_execution_log") || "[]")); } catch { setExecutionLog([]); }
    try { setAutopilotSummary(localStorage.getItem("socialpilot_autopilot_summary") || ""); } catch {}
    try { setRevenueGoal(Number(localStorage.getItem("socialpilot_revenue_goal") || "500")); } catch {}
    try { setRevenueEntries(JSON.parse(localStorage.getItem("socialpilot_revenue_entries") || "[]")); } catch { setRevenueEntries([]); }
    try { setRevenueAdvice(JSON.parse(localStorage.getItem("socialpilot_revenue_advice") || "null")); } catch { setRevenueAdvice(null); }
    try { setFunnelPlan(JSON.parse(localStorage.getItem("socialpilot_funnel_plan") || "null")); } catch { setFunnelPlan(null); }
    try { setWebsitePlan(JSON.parse(localStorage.getItem("socialpilot_website_plan") || "null")); } catch { setWebsitePlan(null); }
    try { setWebsiteActionUrl(localStorage.getItem("socialpilot_website_action_url") || ""); } catch {}
    try { setWebsitePublished(localStorage.getItem("socialpilot_website_published") === "true"); } catch {}
    try { setOrders(JSON.parse(localStorage.getItem("socialpilot_orders") || "[]")); } catch { setOrders([]); }
    try { setSupportTickets(JSON.parse(localStorage.getItem("socialpilot_support_tickets") || "[]")); } catch { setSupportTickets([]); }
    try { setRetentionActions(JSON.parse(localStorage.getItem("socialpilot_retention_actions") || "[]")); } catch { setRetentionActions([]); }
    try { setPerformanceMetrics(JSON.parse(localStorage.getItem("socialpilot_performance_metrics") || "[]")); } catch { setPerformanceMetrics([]); }
    try { setOptimizationAdvice(JSON.parse(localStorage.getItem("socialpilot_optimization_advice") || "null")); } catch { setOptimizationAdvice(null); }
    try { const key = localStorage.getItem("socialpilot_owner_key") || ""; setCloudOwnerKey(key); if (key) setTimeout(() => pullCloudState(key), 150); } catch {}
  }, []);

  function currentCloudState() {
    return { savedPosts, businessPlan, accountLaunchPlan, accountLaunchCompleted, leads, orders, supportTickets, retentionActions, performanceMetrics, optimizationAdvice, autopilotEnabled, autopilotTasks, autopilotSummary, executionLog, scheduleDates, revenueGoal, revenueEntries, revenueAdvice, funnelPlan, websitePlan: websitePlan ? { ...websitePlan, actionUrl: websiteActionUrl } : null, websitePublished };
  }

  async function pushCloudState(key = cloudOwnerKey, stateOverride?: any) {
    if (!key) return;
    setCloudBusy(true);
    try {
      const r = await fetch("/api/state", { method: "PUT", headers: { "Content-Type": "application/json", "x-socialpilot-owner-key": key }, body: JSON.stringify({ state: stateOverride || currentCloudState() }) });
      const d = await r.json(); if (!r.ok) throw new Error(d.error || "Cloud save failed");
      setCloudStatus("Cloud connected"); setLastCloudSync(new Date().toLocaleString());
    } catch (e) { setCloudStatus(e instanceof Error ? e.message : "Cloud save failed"); }
    finally { setCloudBusy(false); }
  }

  async function pullCloudState(key = cloudOwnerKey) {
    if (!key) return;
    setCloudBusy(true);
    try {
      const r = await fetch("/api/state", { headers: { "x-socialpilot-owner-key": key }, cache: "no-store" });
      const d = await r.json(); if (!r.ok) throw new Error(d.error || "Cloud load failed");
      if (d.state) {
        const st = d.state;
        if (Array.isArray(st.savedPosts)) { setSavedPosts(st.savedPosts); localStorage.setItem("socialpilot_saved_posts", JSON.stringify(st.savedPosts)); }
        if ("businessPlan" in st) { setBusinessPlan(st.businessPlan || null); localStorage.setItem("socialpilot_business_plan", JSON.stringify(st.businessPlan || null)); }
        if ("accountLaunchPlan" in st) { setAccountLaunchPlan(st.accountLaunchPlan || null); localStorage.setItem("socialpilot_account_launch_plan", JSON.stringify(st.accountLaunchPlan || null)); }
        if (Array.isArray(st.accountLaunchCompleted)) { setAccountLaunchCompleted(st.accountLaunchCompleted); localStorage.setItem("socialpilot_account_launch_completed", JSON.stringify(st.accountLaunchCompleted)); }
        if (Array.isArray(st.leads)) { setLeads(st.leads); localStorage.setItem("socialpilot_leads", JSON.stringify(st.leads)); }
        if (Array.isArray(st.orders)) { setOrders(st.orders); localStorage.setItem("socialpilot_orders", JSON.stringify(st.orders)); }
        if (Array.isArray(st.supportTickets)) { setSupportTickets(st.supportTickets); localStorage.setItem("socialpilot_support_tickets", JSON.stringify(st.supportTickets)); }
        if (Array.isArray(st.retentionActions)) { setRetentionActions(st.retentionActions); localStorage.setItem("socialpilot_retention_actions", JSON.stringify(st.retentionActions)); }
        if (Array.isArray(st.performanceMetrics)) { setPerformanceMetrics(st.performanceMetrics); localStorage.setItem("socialpilot_performance_metrics", JSON.stringify(st.performanceMetrics)); }
        if ("optimizationAdvice" in st) { setOptimizationAdvice(st.optimizationAdvice || null); localStorage.setItem("socialpilot_optimization_advice", JSON.stringify(st.optimizationAdvice || null)); }
        if (typeof st.autopilotEnabled === "boolean") { setAutopilotEnabled(st.autopilotEnabled); localStorage.setItem("socialpilot_autopilot_enabled", String(st.autopilotEnabled)); }
        if (Array.isArray(st.autopilotTasks)) { const normalized = st.autopilotTasks.map(normalizeAutopilotTask); setAutopilotTasks(normalized); localStorage.setItem("socialpilot_autopilot_tasks", JSON.stringify(normalized)); }
        if (Array.isArray(st.executionLog)) { setExecutionLog(st.executionLog); localStorage.setItem("socialpilot_execution_log", JSON.stringify(st.executionLog)); }
        if (typeof st.autopilotSummary === "string") { setAutopilotSummary(st.autopilotSummary); localStorage.setItem("socialpilot_autopilot_summary", st.autopilotSummary); }
        if (st.scheduleDates && typeof st.scheduleDates === "object") setScheduleDates(st.scheduleDates);
        if (typeof st.revenueGoal === "number") { setRevenueGoal(st.revenueGoal); localStorage.setItem("socialpilot_revenue_goal", String(st.revenueGoal)); }
        if (Array.isArray(st.revenueEntries)) { setRevenueEntries(st.revenueEntries); localStorage.setItem("socialpilot_revenue_entries", JSON.stringify(st.revenueEntries)); }
        if ("revenueAdvice" in st) { setRevenueAdvice(st.revenueAdvice || null); localStorage.setItem("socialpilot_revenue_advice", JSON.stringify(st.revenueAdvice || null)); }
        if ("funnelPlan" in st) { setFunnelPlan(st.funnelPlan || null); localStorage.setItem("socialpilot_funnel_plan", JSON.stringify(st.funnelPlan || null)); }
        if ("websitePlan" in st) {
          const wp = st.websitePlan || null; setWebsitePlan(wp); localStorage.setItem("socialpilot_website_plan", JSON.stringify(wp));
          if (wp?.actionUrl) { setWebsiteActionUrl(wp.actionUrl); localStorage.setItem("socialpilot_website_action_url", wp.actionUrl); }
        }
        if (typeof st.websitePublished === "boolean") { setWebsitePublished(st.websitePublished); localStorage.setItem("socialpilot_website_published", String(st.websitePublished)); }
        setLastCloudSync(st.updatedAt ? new Date(st.updatedAt).toLocaleString() : new Date().toLocaleString());
      }
      setCloudStatus("Cloud connected");
    } catch (e) { setCloudStatus(e instanceof Error ? e.message : "Cloud load failed"); }
    finally { setCloudBusy(false); }
  }

  async function connectCloud() {
    const key = cloudOwnerKey.trim(); if (!key) { setCloudStatus("Enter your owner key first"); return; }
    localStorage.setItem("socialpilot_owner_key", key);
    // Connecting must never overwrite an existing cloud workspace with an empty/stale browser snapshot.
    // Load the authoritative cloud state first. Individual features then save only the fields they change.
    await pullCloudState(key);
  }


  function persistPerformance(next: PerformanceMetric[], advice = optimizationAdvice) {
    setPerformanceMetrics(next); setOptimizationAdvice(advice);
    try { localStorage.setItem("socialpilot_performance_metrics", JSON.stringify(next)); localStorage.setItem("socialpilot_optimization_advice", JSON.stringify(advice)); } catch {}
    void pushCloudState(cloudOwnerKey, { performanceMetrics: next, optimizationAdvice: advice });
  }

  function addPerformanceMetric() {
    const nums = [metricImpressions, metricClicks, metricLeads, metricSales, metricRevenue].map(v => Number(v || 0));
    if (!metricCampaign.trim()) { setError("Add a campaign or post name first."); return; }
    if (nums.some(n => !Number.isFinite(n) || n < 0)) { setError("Enter valid non-negative performance numbers."); return; }
    const [impressions, clicks, leadsCount, salesCount, revenue] = nums;
    const metric: PerformanceMetric = { id: crypto.randomUUID(), channel: metricChannel, campaign: metricCampaign.trim(), impressions, clicks, leads: leadsCount, sales: salesCount, revenue, date: metricDate || new Date().toISOString().slice(0,10), notes: metricNotes.trim(), createdAt: new Date().toISOString() };
    persistPerformance([metric, ...performanceMetrics], null);
    setMetricCampaign(""); setMetricImpressions(""); setMetricClicks(""); setMetricLeads(""); setMetricSales(""); setMetricRevenue(""); setMetricNotes(""); setError("");
  }

  function deletePerformanceMetric(id: string) { persistPerformance(performanceMetrics.filter(m => m.id !== id), null); }

  async function runOptimization() {
    setOptimizationLoading(true); setError("");
    try {
      const context = { business: businessPlan, revenue: { goal: revenueGoal, revenue: revenueTotal, expenses: expenseTotal, profit: profitTotal }, pipeline: salesStats, orders: orderStats, metrics: performanceMetrics.slice(0,30), content: { total: counts.total, drafts: counts.drafts, ready: counts.ready, published: counts.published }, support: { open: openSupportCount, retentionDue: dueRetentionCount }, executionFeedback: executionLog.slice(0,20) };
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "optimize", idea: JSON.stringify(context) }) });
      const d = await r.json(); if (!r.ok) throw new Error(d.error || "Could not analyze performance");
      const advice: OptimizationAdvice = { summary: d.summary, working: d.working || [], improve: d.improve || [], nextExperiment: d.nextExperiment, actions: d.actions || [] };
      persistPerformance(performanceMetrics, advice);
    } catch(e) { setError(e instanceof Error ? e.message : "Could not analyze performance"); } finally { setOptimizationLoading(false); }
  }


  function persistOrders(next: Order[]) {
    setOrders(next);
    try { localStorage.setItem("socialpilot_orders", JSON.stringify(next)); } catch {}
    void pushCloudState(cloudOwnerKey, { orders: next });
  }

  function addOrder() {
    const customerName = orderCustomerName.trim();
    const item = orderItem.trim() || websitePlan?.products?.[0]?.name || funnelPlan?.offerName || businessPlan?.offer || "Order";
    const amount = Number(orderAmount || 0);
    if (!customerName) { setError("Add the customer name first."); return; }
    if (!Number.isFinite(amount) || amount < 0) { setError("Enter a valid order amount."); return; }
    const order: Order = { id: crypto.randomUUID(), customerName, contact: orderContact.trim(), item, amount, status: "new", source: orderSource || "Other", notes: orderNotes.trim(), createdAt: new Date().toISOString(), revenueLinked: false };
    persistOrders([order, ...orders]);
    setOrderCustomerName(""); setOrderContact(""); setOrderItem(""); setOrderAmount(""); setOrderNotes(""); setError("");
  }

  function updateOrder(id: string, patch: Partial<Order>) { persistOrders(orders.map(o => o.id === id ? { ...o, ...patch } : o)); }
  function deleteOrder(id: string) { persistOrders(orders.filter(o => o.id !== id)); }

  function linkOrderRevenue(order: Order) {
    if (order.revenueLinked || order.amount <= 0) return;
    const entry: RevenueEntry = { id: crypto.randomUUID(), kind: "revenue", amount: order.amount, label: `Order: ${order.item} — ${order.customerName}`, date: new Date().toISOString().slice(0,10), createdAt: new Date().toISOString() };
    const nextEntries = [entry, ...revenueEntries];
    setRevenueEntries(nextEntries);
    try { localStorage.setItem("socialpilot_revenue_entries", JSON.stringify(nextEntries)); } catch {}
    const nextOrders = orders.map(o => o.id === order.id ? { ...o, revenueLinked: true, status: (o.status === "new" ? "paid" : o.status) as OrderStatus } : o);
    setOrders(nextOrders);
    try { localStorage.setItem("socialpilot_orders", JSON.stringify(nextOrders)); } catch {}
    void pushCloudState(cloudOwnerKey, { revenueEntries: nextEntries, orders: nextOrders });
  }


  function persistSupport(next: SupportTicket[]) {
    setSupportTickets(next);
    try { localStorage.setItem("socialpilot_support_tickets", JSON.stringify(next)); } catch {}
    void pushCloudState(cloudOwnerKey, { supportTickets: next });
  }

  function addSupportTicket() {
    if (!supportName.trim() || !supportSubject.trim() || !supportMessage.trim()) { setError("Add the customer name, subject, and message first."); return; }
    const ticket: SupportTicket = { id: crypto.randomUUID(), customerName: supportName.trim(), contact: supportContact.trim(), subject: supportSubject.trim(), message: supportMessage.trim(), status: "open", priority: supportPriority, createdAt: new Date().toISOString() };
    persistSupport([ticket, ...supportTickets]);
    setSupportName(""); setSupportContact(""); setSupportSubject(""); setSupportMessage(""); setError("");
  }
  function updateSupportTicket(id: string, patch: Partial<SupportTicket>) { persistSupport(supportTickets.map(t => t.id === id ? { ...t, ...patch } : t)); }
  function deleteSupportTicket(id: string) { persistSupport(supportTickets.filter(t => t.id !== id)); }
  async function generateSupportReply(ticket: SupportTicket) {
    setSupportReplyLoadingId(ticket.id); setError("");
    try {
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "support", idea: JSON.stringify({ customerName: ticket.customerName, subject: ticket.subject, message: ticket.message, business: businessPlan ? { name: businessPlan.businessName, offer: businessPlan.offer } : null }) }) });
      const d = await r.json(); if (!r.ok) throw new Error(d.error || "Could not draft support reply");
      setSupportReplyDrafts(prev => ({ ...prev, [ticket.id]: { subject: d.subject, message: d.message } }));
    } catch(e) { setError(e instanceof Error ? e.message : "Could not draft support reply"); }
    finally { setSupportReplyLoadingId(""); }
  }

  function persistRetention(next: RetentionAction[]) {
    setRetentionActions(next);
    try { localStorage.setItem("socialpilot_retention_actions", JSON.stringify(next)); } catch {}
    void pushCloudState(cloudOwnerKey, { retentionActions: next });
  }
  function addRetentionAction() {
    if (!retentionCustomer.trim()) { setError("Add a customer name first."); return; }
    const item: RetentionAction = { id: crypto.randomUUID(), customerName: retentionCustomer.trim(), contact: retentionContact.trim(), kind: retentionKind, dueDate: retentionDate, notes: retentionNotes.trim(), done: false, createdAt: new Date().toISOString() };
    persistRetention([item, ...retentionActions]);
    setRetentionCustomer(""); setRetentionContact(""); setRetentionNotes(""); setError("");
  }
  function updateRetentionAction(id: string, patch: Partial<RetentionAction>) { persistRetention(retentionActions.map(a => a.id === id ? { ...a, ...patch } : a)); }
  function deleteRetentionAction(id: string) { persistRetention(retentionActions.filter(a => a.id !== id)); }


  function persistWebsite(plan: WebsitePlan | null, published = websitePublished, actionUrl = websiteActionUrl) {
    const withUrl = plan ? { ...plan, actionUrl } : null;
    setWebsitePlan(withUrl); setWebsitePublished(published); setWebsiteActionUrl(actionUrl);
    try {
      localStorage.setItem("socialpilot_website_plan", JSON.stringify(withUrl));
      localStorage.setItem("socialpilot_website_action_url", actionUrl);
      localStorage.setItem("socialpilot_website_published", String(published));
    } catch {}
    void pushCloudState(cloudOwnerKey, { websitePlan: withUrl, websitePublished: published });
  }

  async function buildWebsite() {
    const brief = websiteBrief.trim() || funnelPlan?.offerName || businessPlan?.offer || businessPlan?.niche || "";
    if (!brief) { setError("Describe the business or offer you want the website to sell."); return; }
    setWebsiteLoading(true); setError("");
    try {
      const context = JSON.stringify({
        request: brief,
        business: businessPlan ? { name: businessPlan.businessName, niche: businessPlan.niche, audience: businessPlan.targetCustomer, offer: businessPlan.offer, pricing: businessPlan.pricing, positioning: businessPlan.positioning } : null,
        funnel: funnelPlan ? { offer: funnelPlan.offerName, audience: funnelPlan.audience, promise: funnelPlan.promise, price: funnelPlan.price, benefits: funnelPlan.benefits, cta: funnelPlan.callToAction } : null
      });
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "website", idea: context }) });
      const data = await r.json(); if (!r.ok) throw new Error(data.error || "Could not build website");
      persistWebsite(data, false, websiteActionUrl);
    } catch (e) { setError(e instanceof Error ? e.message : "Could not build website"); }
    finally { setWebsiteLoading(false); }
  }

  function saveWebsiteActionUrl() {
    if (!websitePlan) return;
    persistWebsite(websitePlan, websitePublished, websiteActionUrl.trim());
  }

  function toggleWebsitePublished() {
    if (!websitePlan) { setError("Build your website first."); return; }
    persistWebsite(websitePlan, !websitePublished, websiteActionUrl.trim());
  }

  function persistFunnel(plan: FunnelPlan | null) {
    setFunnelPlan(plan);
    try { localStorage.setItem("socialpilot_funnel_plan", JSON.stringify(plan)); } catch {}
    void pushCloudState(cloudOwnerKey, { funnelPlan: plan });
  }

  async function buildFunnel() {
    const brief = funnelBrief.trim() || businessPlan?.offer || businessPlan?.niche || "";
    if (!brief) { setError("Describe the offer or business you want to build a funnel for."); return; }
    setFunnelLoading(true); setError("");
    try {
      const context = JSON.stringify({
        request: brief,
        business: businessPlan ? { name: businessPlan.businessName, niche: businessPlan.niche, audience: businessPlan.targetCustomer, offer: businessPlan.offer, pricing: businessPlan.pricing, positioning: businessPlan.positioning } : null,
        revenueGoal,
        existingCustomers: salesStats.customers,
        pipeline: salesStats.pipeline
      });
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "funnel", idea: context }) });
      const data = await r.json(); if (!r.ok) throw new Error(data.error || "Could not build funnel");
      persistFunnel(data);
    } catch (e) { setError(e instanceof Error ? e.message : "Could not build funnel"); }
    finally { setFunnelLoading(false); }
  }

  function useFunnelContentIdea(angle: string) {
    setIdea(angle);
    setTab("Create");
  }

  function persistRevenue(entries = revenueEntries, goal = revenueGoal, advice = revenueAdvice) {
    setRevenueEntries(entries); setRevenueGoal(goal); setRevenueAdvice(advice);
    try {
      localStorage.setItem("socialpilot_revenue_entries", JSON.stringify(entries));
      localStorage.setItem("socialpilot_revenue_goal", String(goal));
      localStorage.setItem("socialpilot_revenue_advice", JSON.stringify(advice));
    } catch {}
    void pushCloudState(cloudOwnerKey, { revenueEntries: entries, revenueGoal: goal, revenueAdvice: advice });
  }

  function addMoneyEntry() {
    const amount = Number(moneyAmount);
    if (!moneyLabel.trim() || !Number.isFinite(amount) || amount <= 0) { setError("Add a label and a positive amount first."); return; }
    const entry: RevenueEntry = { id: crypto.randomUUID(), kind: moneyKind, amount, label: moneyLabel.trim(), date: moneyDate || new Date().toISOString().slice(0,10), createdAt: new Date().toISOString() };
    persistRevenue([entry, ...revenueEntries]); setMoneyAmount(""); setMoneyLabel(""); setError("");
  }

  function deleteMoneyEntry(id: string) { persistRevenue(revenueEntries.filter(e => e.id !== id)); }

  async function generateRevenueAdvice() {
    setRevenueLoading(true); setError("");
    try {
      const revenue = revenueEntries.filter(e=>e.kind==="revenue").reduce((s,e)=>s+e.amount,0);
      const expenses = revenueEntries.filter(e=>e.kind==="expense").reduce((s,e)=>s+e.amount,0);
      const context = JSON.stringify({
        goal: revenueGoal, revenue, expenses, profit: revenue-expenses,
        business: businessPlan ? { name: businessPlan.businessName, niche: businessPlan.niche, offer: businessPlan.offer, pricing: businessPlan.pricing, goal: businessPlan.thirtyDayGoal } : null,
        sales: { activeLeads: salesStats.leads, customers: salesStats.customers, pipeline: salesStats.pipeline, followupsDue: salesStats.due },
        content: { drafts: counts.drafts, ready: counts.ready, published: counts.published },
        funnel: funnelPlan ? { offer: funnelPlan.offerName, audience: funnelPlan.audience, cta: funnelPlan.callToAction } : null,
        recentMoney: revenueEntries.slice(0,12)
      });
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "revenue", idea: context }) });
      const data = await r.json(); if (!r.ok) throw new Error(data.error || "Could not create revenue plan");
      const advice: RevenueAdvice = { summary: data.summary, nextMove: data.nextMove, why: data.why, target: data.target, actions: data.actions || [] };
      persistRevenue(revenueEntries, revenueGoal, advice);
    } catch (e) { setError(e instanceof Error ? e.message : "Could not create revenue plan"); } finally { setRevenueLoading(false); }
  }

  async function checkLaunchHealth() {
    setLaunchHealthLoading(true);
    try {
      const r = await fetch("/api/health", { cache: "no-store" });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Launch check failed");
      setLaunchHealth(data);
    } catch (e) {
      setLaunchHealth({
        ready: false, version: "6.1.0-free-launch", model: "gemini-3.5-flash-lite", mode: "free-first",
        env: { gemini:false, database:false, ownerKey:false, cronSecret:false, sessionSecret:false, appUrl:false },
        database: { reachable:false, cloudStateFound:false, error: e instanceof Error ? e.message : "Launch check failed" },
        autopilot: { schedule:"0 12 * * *", cadence:"daily" },
        message: e instanceof Error ? e.message : "Launch check failed"
      });
    } finally { setLaunchHealthLoading(false); }
  }

  async function pushAutopilotState(patch: { autopilotTasks?: AutopilotTask[]; autopilotSummary?: string; autopilotEnabled?: boolean; lastAutopilotRun?: string; executionLog?: ExecutionRecord[] }) {
    const key = cloudOwnerKey.trim();
    if (!key) return;
    try {
      const r = await fetch("/api/state/autopilot", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-socialpilot-owner-key": key },
        body: JSON.stringify(patch)
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Autopilot cloud save failed");
      setCloudStatus("Cloud connected");
      setLastCloudSync(new Date().toLocaleString());
    } catch (e) {
      setCloudStatus(e instanceof Error ? e.message : "Autopilot cloud save failed");
    }
  }

  function persistAutopilot(tasks: AutopilotTask[], summary = autopilotSummary, log = executionLog) {
    const normalized = tasks.map(normalizeAutopilotTask);
    setAutopilotTasks(normalized); setAutopilotSummary(summary); setExecutionLog(log);
    try {
      localStorage.setItem("socialpilot_autopilot_tasks", JSON.stringify(normalized));
      localStorage.setItem("socialpilot_autopilot_summary", summary);
      localStorage.setItem("socialpilot_execution_log", JSON.stringify(log));
    } catch {}
    void pushAutopilotState({ autopilotTasks: normalized, autopilotSummary: summary, executionLog: log, lastAutopilotRun: new Date().toISOString() });
  }

  function toggleAutopilot() {
    const next = !autopilotEnabled; setAutopilotEnabled(next);
    try { localStorage.setItem("socialpilot_autopilot_enabled", String(next)); } catch {}
    void pushAutopilotState({ autopilotEnabled: next });
  }

  async function runAutopilot() {
    setAutopilotLoading(true); setError("");
    try {
      // Prefer the authoritative Neon copy at the moment Autopilot runs. This prevents a stale
      // browser render from producing a zero-data plan immediately after Cloud Sync.
      let source: any = currentCloudState();
      const key = cloudOwnerKey.trim();
      if (key) {
        try {
          const cloudResponse = await fetch("/api/state", { headers: { "x-socialpilot-owner-key": key }, cache: "no-store" });
          if (cloudResponse.ok) {
            const cloudData = await cloudResponse.json();
            if (cloudData?.state) source = { ...source, ...cloudData.state };
          }
        } catch {}
      }

      const sourcePosts: SavedPost[] = Array.isArray(source.savedPosts) ? source.savedPosts : [];
      const sourceLeads: Lead[] = Array.isArray(source.leads) ? source.leads : [];
      const sourceOrders: Order[] = Array.isArray(source.orders) ? source.orders : [];
      const sourceRevenueEntries: RevenueEntry[] = Array.isArray(source.revenueEntries) ? source.revenueEntries : [];
      const sourceMetrics: PerformanceMetric[] = Array.isArray(source.performanceMetrics) ? source.performanceMetrics : [];
      const sourceBusiness = source.businessPlan || null;
      const sourceFunnel = source.funnelPlan || null;
      const sourceOptimization = source.optimizationAdvice || null;
      const sourceRevenueGoal = Number(source.revenueGoal ?? revenueGoal) || 0;

      const sourceCounts = {
        total: sourcePosts.length,
        drafts: sourcePosts.filter((p:any)=>p.status==="draft").length,
        ready: sourcePosts.filter((p:any)=>p.status==="ready").length,
        published: sourcePosts.filter((p:any)=>p.status==="published").length
      };
      const sourceSales = {
        leads: sourceLeads.filter((l:any)=>l.status!=="customer" && l.status!=="lost").length,
        customers: sourceLeads.filter((l:any)=>l.status==="customer").length,
        pipeline: sourceLeads.filter((l:any)=>l.status!=="lost").reduce((sum:number,l:any)=>sum+(Number(l.value)||0),0),
        due: sourceLeads.filter((l:any)=>l.followUpDate && l.followUpDate <= today && l.status!=="customer" && l.status!=="lost").length
      };
      const topPerformance = sourceMetrics.length
        ? [...sourceMetrics].sort((a:any,b:any) => ((Number(b.revenue)||0) - (Number(a.revenue)||0)) || ((Number(b.sales)||0) - (Number(a.sales)||0)) || ((Number(b.leads)||0) - (Number(a.leads)||0)) || ((Number(b.clicks)||0) - (Number(a.clicks)||0)))[0]
        : null;
      const top = topPerformance ? {
        campaign: topPerformance.campaign,
        channel: topPerformance.channel,
        impressions: Number(topPerformance.impressions)||0,
        clicks: Number(topPerformance.clicks)||0,
        leads: Number(topPerformance.leads)||0,
        sales: Number(topPerformance.sales)||0,
        revenue: Number(topPerformance.revenue)||0,
        ctrPct: Number(topPerformance.impressions) ? Number(((Number(topPerformance.clicks) / Number(topPerformance.impressions)) * 100).toFixed(1)) : 0,
        leadRatePct: Number(topPerformance.clicks) ? Number(((Number(topPerformance.leads) / Number(topPerformance.clicks)) * 100).toFixed(1)) : 0,
        salesRatePct: Number(topPerformance.leads) ? Number(((Number(topPerformance.sales) / Number(topPerformance.leads)) * 100).toFixed(1)) : 0
      } : null;

      const context = JSON.stringify({
        business: sourceBusiness ? { name: sourceBusiness.businessName, niche: sourceBusiness.niche, offer: sourceBusiness.offer, goal: sourceBusiness.thirtyDayGoal } : null,
        content: { total: sourceCounts.total, drafts: sourceCounts.drafts, ready: sourceCounts.ready, published: sourceCounts.published, recent: sourcePosts.slice(0,5).map((p:any)=>p.title) },
        sales: { activeLeads: sourceSales.leads, customers: sourceSales.customers, pipeline: sourceSales.pipeline, followupsDue: sourceSales.due, dueLeads: sourceLeads.filter((l:any)=>l.followUpDate && l.followUpDate <= today && l.status !== "customer" && l.status !== "lost").slice(0,5).map((l:any)=>({name:l.name,status:l.status,offer:l.offer})) },
        orders: { total: sourceOrders.length, new: sourceOrders.filter((o:any)=>o.status==="new").length, paid: sourceOrders.filter((o:any)=>o.status==="paid").length, fulfilling: sourceOrders.filter((o:any)=>o.status==="fulfilling").length, completed: sourceOrders.filter((o:any)=>o.status==="completed").length, value: sourceOrders.filter((o:any)=>o.status!=="cancelled").reduce((sum:number,o:any)=>sum+(Number(o.amount)||0),0) },
        funnel: sourceFunnel ? { offer: sourceFunnel.offerName, audience: sourceFunnel.audience, leadMagnet: sourceFunnel.leadMagnetTitle, cta: sourceFunnel.callToAction, steps: sourceFunnel.funnelSteps } : null,
        revenue: { goal: sourceRevenueGoal, revenue: sourceRevenueEntries.filter((e:any)=>e.kind==="revenue").reduce((s:number,e:any)=>s+(Number(e.amount)||0),0), expenses: sourceRevenueEntries.filter((e:any)=>e.kind==="expense").reduce((s:number,e:any)=>s+(Number(e.amount)||0),0) },
        analytics: { records: sourceMetrics.slice(0,20), latestOptimization: sourceOptimization, topPerformer: top, recentExecutions: (Array.isArray(source.executionLog) ? source.executionLog : executionLog).slice(0,12) }
      });
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "manager", idea: context }) });
      const data = await r.json(); if (!r.ok) throw new Error(data.error || "Could not build today's plan");
      let tasks: AutopilotTask[] = (data.tasks || []).map((t:any)=>({ ...t, id: crypto.randomUUID(), status: t.requiresApproval ? "pending" : "approved" }));

      // Deterministic analytics guardrail: if a real winner exists, Autopilot must act on it even
      // if the model's generated task list is too generic.
      if (top) {
        const mentionsWinner = tasks.some((t:any)=>`${t.title} ${t.reason}`.toLowerCase().includes(String(top.campaign || "").toLowerCase()));
        if (!mentionsWinner) {
          const winnerTask: AutopilotTask = {
            id: crypto.randomUUID(),
            title: `Repurpose winning campaign: ${top.campaign}`,
            reason: `${top.channel} winner produced ${top.impressions} impressions, ${top.clicks} clicks, ${top.leads} leads, ${top.sales} sales, and $${top.revenue.toFixed(2)} revenue. Create and test a variation of this proven pattern before starting unrelated content.`,
            actionType: "content",
            priority: "high",
            requiresApproval: false,
            status: "approved"
          };
          tasks = [winnerTask, ...tasks].slice(0,8);
        }
      }

      const summary = top
        ? `Top performer ${top.campaign} on ${top.channel} is guiding today's plan (${top.sales} sales, $${top.revenue.toFixed(2)} revenue). ${data.summary || ""}`.trim()
        : (data.summary || "Today's operating plan is ready.");
      persistAutopilot(tasks, summary);
      if (autopilotEnabled) await executeApprovedBatch(tasks, executionLog, summary);
    } catch(e) { setError(e instanceof Error ? e.message : "Could not run Autopilot"); } finally { setAutopilotLoading(false); }
  }

  function updateAutopilotTask(id: string, patch: Partial<AutopilotTask>) {
    persistAutopilot(autopilotTasks.map(t=>t.id===id?normalizeAutopilotTask({...t,...patch}):t));
  }

  async function freshExecutionSource() {
    let source: any = currentCloudState();
    const key = cloudOwnerKey.trim();
    if (!key) return source;
    try {
      const r = await fetch("/api/state", { headers: { "x-socialpilot-owner-key": key }, cache: "no-store" });
      const d = await r.json();
      if (r.ok && d?.state) source = { ...source, ...d.state };
    } catch {}
    return source;
  }

  async function executeAutopilotTask(rawTask: AutopilotTask, baseQueue = autopilotTasks, baseLog = executionLog, summaryOverride = autopilotSummary): Promise<{queue: AutopilotTask[]; log: ExecutionRecord[]}> {
    const task = normalizeAutopilotTask(rawTask);
    const status = canonicalActionStatus(task.status);
    if (task.requiresApproval && status === "pending") { setError("Approve this action before V7 executes it."); return { queue: baseQueue, log: baseLog }; }
    if (status === "running" || status === "completed") return { queue: baseQueue, log: baseLog };

    setExecutionBusyId(task.id); setError("");
    const startedAt = new Date().toISOString();
    const startRecord: ExecutionRecord = { id: crypto.randomUUID(), taskId: task.id, title: task.title, actionType: task.actionType, status: "running", message: "Execution started", createdAt: startedAt };
    let queue = baseQueue.map(t=>t.id===task.id?{...normalizeAutopilotTask(t),status:"running" as ActionStatus,startedAt,error:undefined}:normalizeAutopilotTask(t));
    let log = [startRecord, ...baseLog].slice(0,100);
    persistAutopilot(queue, summaryOverride, log);

    try {
      const source: any = await freshExecutionSource();
      let message = "Task completed.";
      const taskText = `${task.title} ${task.reason}`.toLowerCase();

      if (task.actionType === "content") {
        const prompt = `Autopilot execution task: ${task.title}. Reason: ${task.reason}. Business: ${source.businessPlan?.businessName || "DRAIG business"}. Offer: ${source.businessPlan?.offer || source.funnelPlan?.offerName || "current offer"}. Create a fresh variation inspired by the task without copying an existing post.`;
        const r = await fetch("/api/generate", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ idea: prompt.slice(0,1200), platform:"TikTok / Reels / Shorts", tone:"high-energy" }) });
        const d = await r.json(); if (!r.ok) throw new Error(d.error || "Could not generate content action");
        const post: SavedPost = { ...d, id: crypto.randomUUID(), idea: task.title, platform:"TikTok / Reels / Shorts", tone:"high-energy", createdAt:new Date().toISOString(), status:"draft" };
        const currentPosts: SavedPost[] = Array.isArray(source.savedPosts) ? source.savedPosts : [];
        const nextPosts = [post, ...currentPosts];
        setSavedPosts(nextPosts); try { localStorage.setItem("socialpilot_saved_posts", JSON.stringify(nextPosts)); } catch {}
        await pushCloudState(cloudOwnerKey, { savedPosts: nextPosts });
        message = `Created draft content package: ${post.title}. It is saved in Videos for review.`;
      } else if (task.actionType === "sales") {
        const sourceLeads: Lead[] = Array.isArray(source.leads) ? source.leads : [];
        const sourceOrders: Order[] = Array.isArray(source.orders) ? source.orders : [];
        const todayIso = new Date().toISOString().slice(0,10);
        const lead = sourceLeads.find(l=>l.followUpDate && l.followUpDate <= todayIso && !["customer","lost"].includes(l.status)) || sourceLeads.find(l=>!["customer","lost"].includes(l.status));
        if (!lead) throw new Error("No active lead is available for this sales action.");
        const r = await fetch("/api/generate", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ mode:"followup", idea:`Lead: ${lead.name}. Contact: ${lead.contact || "unknown"}. Source: ${lead.source}. Offer: ${lead.offer || source.businessPlan?.offer || "our offer"}. Stage: ${lead.status}. Notes: ${lead.notes || "none"}. Autopilot task: ${task.title}.` }) });
        const d = await r.json(); if (!r.ok) throw new Error(d.error || "Could not prepare lead follow-up");
        setFollowupDrafts(prev=>({...prev,[lead.id]:{subject:d.subject || "Follow-up",message:d.message || ""}}));
        let nextLeads = sourceLeads;
        const matchedOrder = sourceOrders.find(o => ["paid","completed"].includes(o.status) && ((lead.contact && o.contact === lead.contact) || o.customerName.toLowerCase() === lead.name.toLowerCase()));
        if (matchedOrder && lead.status !== "customer") {
          nextLeads = sourceLeads.map(l=>l.id===lead.id?{...l,status:"customer" as LeadStatus,notes:`${l.notes ? l.notes+"\n" : ""}V7 matched this lead to a recorded ${matchedOrder.status} order on ${new Date().toLocaleDateString()}.`}:l);
          setLeads(nextLeads); try { localStorage.setItem("socialpilot_leads", JSON.stringify(nextLeads)); } catch {}
          await pushCloudState(cloudOwnerKey, { leads: nextLeads });
        }
        message = `Prepared follow-up for ${lead.name}: ${d.subject}. Nothing was sent automatically${matchedOrder ? "; CRM status was updated to customer from a matching recorded order" : ""}.`;
      } else if (task.actionType === "business") {
        const businessContext = `Task: ${task.title}. Reason: ${task.reason}. Business: ${JSON.stringify(source.businessPlan || {})}. Funnel: ${JSON.stringify(source.funnelPlan || {})}. Website: ${JSON.stringify(source.websitePlan || {})}`;
        if (/funnel|landing|offer/.test(taskText)) {
          const r = await fetch("/api/generate", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ mode:"funnel", idea:businessContext }) });
          const d = await r.json(); if (!r.ok) throw new Error(d.error || "Could not build funnel action");
          const plan: FunnelPlan = { ...d };
          setFunnelPlan(plan); try { localStorage.setItem("socialpilot_funnel_plan", JSON.stringify(plan)); } catch {}
          await pushCloudState(cloudOwnerKey, { funnelPlan: plan });
          message = `Updated funnel draft: ${plan.funnelName}.`;
        } else if (/website|store|site|page|copy/.test(taskText)) {
          const r = await fetch("/api/generate", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ mode:"website", idea:businessContext }) });
          const d = await r.json(); if (!r.ok) throw new Error(d.error || "Could not build website action");
          const plan: WebsitePlan = { ...d, actionUrl: source.websitePlan?.actionUrl || websiteActionUrl };
          setWebsitePlan(plan); try { localStorage.setItem("socialpilot_website_plan", JSON.stringify(plan)); } catch {}
          await pushCloudState(cloudOwnerKey, { websitePlan: plan });
          message = `Updated website/store copy for ${plan.siteName}.`;
        } else {
          message = `Business operation reviewed and prepared: ${task.title}. No external account, spending, or destructive change was made.`;
        }
      } else if (task.actionType === "review") {
        const posts = Array.isArray(source.savedPosts) ? source.savedPosts : [];
        const sourceLeads = Array.isArray(source.leads) ? source.leads : [];
        const rev = Array.isArray(source.revenueEntries) ? source.revenueEntries : [];
        const revenue = rev.filter((e:any)=>e.kind==="revenue").reduce((n:number,e:any)=>n+(Number(e.amount)||0),0);
        const expenses = rev.filter((e:any)=>e.kind==="expense").reduce((n:number,e:any)=>n+(Number(e.amount)||0),0);
        message = `Review completed: ${posts.length} content items, ${sourceLeads.length} CRM records, $${revenue.toFixed(2)} revenue, $${expenses.toFixed(2)} expenses. No external action taken.`;
      } else if (task.actionType === "publish") {
        if (!task.requiresApproval || status !== "approved") throw new Error("Publishing requires explicit approval before execution.");
        const posts: SavedPost[] = Array.isArray(source.savedPosts) ? source.savedPosts : [];
        const post = posts.find(p=>p.status==="ready" && p.videoUrl);
        if (!post?.videoUrl) throw new Error("No ready post with a hosted video URL is available to publish.");
        const platformName = publishPlatform || "tiktok";
        if (platformName === "tiktok" && !privacyLevel) throw new Error("Choose a TikTok privacy level in Videos before executing this approved publish action.");
        const r = await fetch("/api/publish", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ platform:platformName, videoUrl:post.videoUrl, caption:`${post.caption}\n\n${(post.hashtags || []).join(" ")}`, title:post.title, privacyLevel, allowComment:true, allowDuet:true, allowStitch:true, consent:true, isAigc:true, promotesOwnBusiness:false, paidPartnership:false }) });
        const d = await r.json(); if (!r.ok) throw new Error(d.error?.message || d.error || "Publish failed");
        if (d.published) {
          const nextPosts = posts.map(p=>p.id===post.id?{...p,status:"published" as const}:p);
          setSavedPosts(nextPosts); try { localStorage.setItem("socialpilot_saved_posts", JSON.stringify(nextPosts)); } catch {}
          await pushCloudState(cloudOwnerKey, { savedPosts: nextPosts });
          message = `Published approved post "${post.title}" to ${platformName}.`;
        } else {
          if (d.publishId) setTiktokPublishId(d.publishId);
          message = `Submitted approved post "${post.title}" to ${platformName}; the platform is still processing it${d.publishId ? ` (publish ID ${d.publishId})` : ""}.`;
        }
      }

      const completedAt = new Date().toISOString();
      queue = queue.map(t=>t.id===task.id?{...t,status:"completed" as ActionStatus,result:message,error:undefined,completedAt}:t);
      const doneRecord: ExecutionRecord = { id: crypto.randomUUID(), taskId: task.id, title: task.title, actionType: task.actionType, status:"completed", message, createdAt:completedAt };
      log = [doneRecord, ...log].slice(0,100);
      persistAutopilot(queue, summaryOverride, log);
      return { queue, log };
    } catch (e) {
      const message = e instanceof Error ? e.message : "Execution failed";
      const failedAt = new Date().toISOString();
      queue = queue.map(t=>t.id===task.id?{...t,status:"failed" as ActionStatus,error:message,completedAt:failedAt}:t);
      const failedRecord: ExecutionRecord = { id: crypto.randomUUID(), taskId: task.id, title: task.title, actionType: task.actionType, status:"failed", message, createdAt:failedAt };
      log = [failedRecord, ...log].slice(0,100);
      persistAutopilot(queue, summaryOverride, log); setError(message);
      return { queue, log };
    } finally { setExecutionBusyId(""); }
  }

  async function executeApprovedBatch(initialQueue: AutopilotTask[], initialLog = executionLog, summaryOverride = autopilotSummary) {
    let queue = initialQueue.map(normalizeAutopilotTask);
    let log = initialLog;
    const ids = queue.filter(t=>canonicalActionStatus(t.status)==="approved" && t.actionType!=="publish").map(t=>t.id);
    for (const id of ids) {
      const task = queue.find(t=>t.id===id);
      if (!task || canonicalActionStatus(task.status)!=="approved") continue;
      const result = await executeAutopilotTask(task, queue, log, summaryOverride);
      queue = result.queue; log = result.log;
    }
    return { queue, log };
  }

  async function runApprovedActions() { await executeApprovedBatch(autopilotTasks, executionLog, autopilotSummary); }

  function openAutopilotTask(task: AutopilotTask) {
    if (task.actionType === "content") { setCopilotTopic(task.title); setTab("Copilot"); return; }
    if (task.actionType === "sales") { setTab("Sales"); return; }
    if (task.actionType === "business") { if (/funnel|offer|landing/i.test(task.title+" "+task.reason)) setTab("Funnel"); else if (/website|store|site/i.test(task.title+" "+task.reason)) setTab("Website"); else setTab("Business"); return; }
    if (task.actionType === "publish") { setTab("Videos"); return; }
    setTab("Analytics");
  }

  function persistLeads(next: Lead[]) {
    setLeads(next);
    try { localStorage.setItem("socialpilot_leads", JSON.stringify(next)); } catch {}
    void pushCloudState(cloudOwnerKey, { leads: next });
  }

  function addLead() {
    const name = leadName.trim();
    if (!name) { setError("Add a lead or customer name first."); return; }
    const lead: Lead = {
      id: crypto.randomUUID(), name, contact: leadContact.trim(), source: leadSource.trim() || "Other",
      offer: leadOffer.trim() || businessPlan?.offer || "", value: Math.max(0, Number(leadValue || 0)), status: "new",
      followUpDate: leadFollowUpDate, notes: leadNotes.trim(), createdAt: new Date().toISOString()
    };
    persistLeads([lead, ...leads]);
    setLeadName(""); setLeadContact(""); setLeadOffer(""); setLeadValue(""); setLeadFollowUpDate(""); setLeadNotes(""); setError("");
  }

  function updateLead(id: string, patch: Partial<Lead>) { persistLeads(leads.map(l => l.id === id ? { ...l, ...patch } : l)); }
  function deleteLead(id: string) { persistLeads(leads.filter(l => l.id !== id)); }

  async function generateLeadFollowup(lead: Lead) {
    setFollowupLoadingId(lead.id); setError("");
    try {
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "followup", idea: `Lead: ${lead.name}. Contact: ${lead.contact || "unknown"}. Source: ${lead.source}. Offer: ${lead.offer || businessPlan?.offer || "our offer"}. Stage: ${lead.status}. Notes: ${lead.notes || "none"}.` }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Could not create follow-up");
      setFollowupDrafts(d => ({ ...d, [lead.id]: { subject: data.subject || "Follow-up", message: data.message || "" } }));
    } catch (e) { setError(e instanceof Error ? e.message : "Could not create follow-up"); }
    finally { setFollowupLoadingId(""); }
  }

  function persistPosts(posts: SavedPost[]) {
    setSavedPosts(posts);
    try { localStorage.setItem("socialpilot_saved_posts", JSON.stringify(posts)); } catch {}
    void pushCloudState(cloudOwnerKey, { savedPosts: posts });
  }

  function upsertCurrentPost(patch: Partial<SavedPost> = {}) {
    if (!result) return null;
    const existing = selectedPostId ? savedPosts.find(p => p.id === selectedPostId) : undefined;
    const post: SavedPost = {
      ...(existing || {}),
      ...result,
      id: existing?.id || crypto.randomUUID(),
      idea, platform, tone,
      createdAt: existing?.createdAt || new Date().toISOString(),
      status: video?.videoUrl ? "ready" : (existing?.status || "draft"),
      videoUrl: video?.videoUrl && !video.localFile ? video.videoUrl : existing?.videoUrl,
      ...patch
    };
    persistPosts([post, ...savedPosts.filter(p => p.id !== post.id)]);
    setSelectedPostId(post.id);
    return post;
  }

  function saveCurrentPost() { upsertCurrentPost(); }

  function openVideoDb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open("socialpilot_free_videos", 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains("videos")) db.createObjectStore("videos");
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async function saveLocalVideo(postId: string, file: File) {
    const db = await openVideoDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("videos", "readwrite");
      tx.objectStore("videos").put(file, postId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  }

  async function loadLocalVideo(postId: string) {
    const db = await openVideoDb();
    const blob = await new Promise<Blob | undefined>((resolve, reject) => {
      const tx = db.transaction("videos", "readonly");
      const req = tx.objectStore("videos").get(postId);
      req.onsuccess = () => resolve(req.result as Blob | undefined);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return blob;
  }

  async function deleteLocalVideo(postId: string) {
    const db = await openVideoDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("videos", "readwrite");
      tx.objectStore("videos").delete(postId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  }

  async function openSavedPost(post: SavedPost) {
    setSelectedPostId(post.id);
    setIdea(post.idea); setPlatform(post.platform); setTone(post.tone); setResult(post); setFinishedVideoUrl(post.videoUrl || "");
    if (post.videoUrl) setVideo({ status: "ready", videoUrl: post.videoUrl });
    else if (post.videoFileName) {
      try {
        const blob = await loadLocalVideo(post.id);
        if (blob) setVideo({ status: "ready-local", videoUrl: URL.createObjectURL(blob), localFile: true, fileName: post.videoFileName });
        else setVideo(null);
      } catch { setVideo(null); }
    } else setVideo(null);
    setTab("Create"); setError("");
  }

  function duplicateSavedPost(post: SavedPost) {
    const copy: SavedPost = { ...post, id: crypto.randomUUID(), title: `${post.title} (Copy)`, createdAt: new Date().toISOString(), status: "draft" };
    persistPosts([copy, ...savedPosts]);
  }

  function updateSavedPost(post: SavedPost, patch: Partial<SavedPost>) {
    persistPosts(savedPosts.map(p => p.id === post.id ? { ...p, ...patch } : p));
  }

  function deleteSavedPost(id: string) {
    persistPosts(savedPosts.filter(p => p.id !== id));
    deleteLocalVideo(id).catch(() => {});
    if (selectedPostId === id) { setSelectedPostId(null); setResult(null); setVideo(null); }
  }
  useEffect(() => { if (publishPlatform === "tiktok") fetch("/api/tiktok/creator", { cache: "no-store" }).then(r => r.ok ? r.json() : null).then(d => { if (d?.data) { setCreatorInfo(d.data); setPrivacyLevel(""); } }); }, [publishPlatform]);
  useEffect(() => { if (tab === "Inbox" && accounts.some(a=>a.platform==="instagram" && a.connected)) void loadInstagramConversations(); }, [tab]);


  function stopSpeaking() {
    if (typeof window !== "undefined") window.speechSynthesis?.cancel();
  }

  function speakText(text: string) {
    if (typeof window === "undefined" || !window.speechSynthesis || !text.trim()) return;
    window.speechSynthesis.cancel();
    try { recognitionRef.current?.abort?.(); } catch {}
    const utterance = new SpeechSynthesisUtterance(text.replace(/[#*_`]/g, " ").slice(0, 1600));
    const voices = window.speechSynthesis.getVoices();
    const selected = voices.find(v => v.name === voiceName) || voices.find(v => /en[-_]US/i.test(v.lang)) || voices.find(v => /^en/i.test(v.lang));
    if (selected) utterance.voice = selected;
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.onend = () => {
      if (voiceEnabledRef.current) setTimeout(() => { try { recognitionRef.current?.start?.(); } catch {} }, 350);
    };
    window.speechSynthesis.speak(utterance);
  }

  function stopVoiceMode() {
    voiceEnabledRef.current = false;
    awaitingVoiceCommandRef.current = false;
    setVoiceEnabled(false);
    setVoiceStatus("Voice off");
    try { recognitionRef.current?.stop?.(); } catch {}
    stopSpeaking();
  }

  function startVoiceMode() {
    if (typeof window === "undefined") return;
    const SpeechRecognitionCtor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognitionCtor || !window.speechSynthesis) {
      setVoiceAvailable(false); setVoiceStatus("Voice recognition is not available in this browser"); return;
    }
    if (!recognitionRef.current) {
      const recognition = new SpeechRecognitionCtor();
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = "en-US";
      recognition.onresult = (event: any) => {
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (!event.results[i].isFinal) continue;
          const heard = String(event.results[i][0]?.transcript || "").trim();
          if (!heard) continue;
          setVoiceTranscript(heard);
          const lower = heard.toLowerCase();
          const wakeIndex = lower.indexOf("hey draig");
          if (wakeIndex >= 0) {
            const command = heard.slice(wakeIndex + "hey draig".length).trim();
            if (command) { awaitingVoiceCommandRef.current = false; void voiceCommandHandlerRef.current(command); }
            else { awaitingVoiceCommandRef.current = true; setVoiceStatus("Awake — say your command"); speakText("Yes?"); }
          } else if (awaitingVoiceCommandRef.current) {
            awaitingVoiceCommandRef.current = false;
            void voiceCommandHandlerRef.current(heard);
          }
        }
      };
      recognition.onerror = (event: any) => {
        if (event?.error === "not-allowed" || event?.error === "service-not-allowed") {
          voiceEnabledRef.current = false; setVoiceEnabled(false); setVoiceStatus("Microphone permission denied");
        } else if (voiceEnabledRef.current) setVoiceStatus(`Listening issue: ${event?.error || "unknown"}`);
      };
      recognition.onend = () => {
        if (voiceEnabledRef.current && !window.speechSynthesis?.speaking) {
          setTimeout(() => { try { recognition.start(); } catch {} }, 450);
        }
      };
      recognitionRef.current = recognition;
    }
    voiceEnabledRef.current = true;
    setVoiceEnabled(true);
    setVoiceStatus('Listening for “Hey DRAIG”');
    try { recognitionRef.current.start(); } catch {}
    speakText("DRAIG voice mode is on. Say Hey DRAIG, then your command.");
  }

  async function generateCopilotIdeas(topicOverride?: string) {
    const topic = (topicOverride ?? copilotTopic).trim();
    if (!topic) return;
    if (topicOverride) setCopilotTopic(topicOverride);
    setCopilotLoading(true); setError("");
    try {
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idea: topic, platform, tone, mode: "ideas", count: 5 }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Could not generate ideas");
      setCopilotIdeas(data.ideas || []);
      if (voiceEnabledRef.current) speakText(`I created ${(data.ideas || []).length || 5} content ideas. They are ready in Copilot.`);
    } catch (e) { setError(e instanceof Error ? e.message : "Could not generate ideas"); if (voiceEnabledRef.current) speakText("I could not create those ideas."); }
    finally { setCopilotLoading(false); }
  }

  function useCopilotIdea(item: CopilotIdea) {
    setIdea(`${item.title} — ${item.angle}. Hook: ${item.hook}`);
    setResult(null); setVideo(null); setSelectedPostId(null);
    setTab("Create");
  }

  function suggestNextPost() {
    const recent = savedPosts.slice(0, 5);
    const topic = recent.length
      ? `Based on these recent posts, suggest fresh follow-up ideas without repeating them: ${recent.map(p => p.title).join(" | ")}`
      : "Give me strong beginner-friendly short-form content ideas for growing a social media account";
    setCopilotTopic(topic);
    setTab("Copilot");
  }

  async function buildAccountLaunch() {
    const brief = accountLaunchBrief.trim();
    if (!brief) return;
    setAccountLaunchLoading(true); setError("");
    try {
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idea: brief, mode: "account-launch" }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Could not build the account launch kit");
      setAccountLaunchPlan(data); setAccountLaunchCompleted([]);
      try { localStorage.setItem("socialpilot_account_launch_plan", JSON.stringify(data)); localStorage.setItem("socialpilot_account_launch_completed", "[]"); } catch {}
      void pushCloudState(cloudOwnerKey, { accountLaunchPlan: data, accountLaunchCompleted: [] });
    } catch (e) { setError(e instanceof Error ? e.message : "Could not build the account launch kit"); }
    finally { setAccountLaunchLoading(false); }
  }

  function toggleAccountLaunchStep(index: number) {
    const next = accountLaunchCompleted.includes(index) ? accountLaunchCompleted.filter(i=>i!==index) : [...accountLaunchCompleted, index].sort((a,b)=>a-b);
    setAccountLaunchCompleted(next);
    try { localStorage.setItem("socialpilot_account_launch_completed", JSON.stringify(next)); } catch {}
    void pushCloudState(cloudOwnerKey, { accountLaunchCompleted: next });
  }

  async function copyLaunchText(text: string) {
    try { await navigator.clipboard.writeText(text); } catch {}
  }

  async function buildBusiness() {
    const brief = businessBrief.trim();
    if (!brief) return;
    setBusinessLoading(true); setError("");
    try {
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idea: brief, mode: "business" }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Could not build the business plan");
      setBusinessPlan(data);
      try { localStorage.setItem("socialpilot_business_plan", JSON.stringify(data)); } catch {}
      void pushCloudState(cloudOwnerKey, { businessPlan: data });
    } catch (e) { setError(e instanceof Error ? e.message : "Could not build the business plan"); }
    finally { setBusinessLoading(false); }
  }

  async function generateContent(ideaOverride?: string) {
    const contentIdea = (ideaOverride ?? idea).trim();
    if (!contentIdea) return;
    if (ideaOverride) setIdea(ideaOverride);
    setLoading(true); setError(""); setVideo(null);
    try {
      const r = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idea: contentIdea, platform, tone }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Generation failed");
      setResult(data);
      setSelectedPostId(null);
      if (voiceEnabledRef.current) speakText(`Your full post ${data.title ? `called ${data.title}` : ""} is ready.`);
    } catch (e) { setError(e instanceof Error ? e.message : "Generation failed"); if (voiceEnabledRef.current) speakText("I could not generate that post."); }
    finally { setLoading(false); }
  }

  async function createVideo() {
    if (!result) return;
    setVideoLoading(true); setError(""); setVideo(null);
    const prompt = `Create a polished short-form social video for ${platform}. Title: ${result.title}. Hook: ${result.hook}. Spoken script: ${result.script}. Visual direction: ${result.visualPlan.join("; ")}. Use portrait 9:16 orientation, fast pacing, strong on-screen captions, clean modern visuals, and a clear ending. Make it feel native to short-form social media. Keep the video at 60 seconds or less.`;
    setHeygenPrompt(prompt);
    try {
      // Open HeyGen immediately from the click so mobile browsers do not block the new tab.
      const heygenWindow = window.open("https://app.heygen.com/", "_blank", "noopener,noreferrer");
      let copied = false;
      try { await navigator.clipboard.writeText(prompt); copied = true; } catch {}
      if (!heygenWindow) setError("HeyGen was blocked by your browser. Tap Open HeyGen below.");
      setVideo({ status: "ready-to-create", error: copied ? "Prompt copied automatically. In HeyGen, open Video Agent, paste, then generate with your available free quota." : "HeyGen opened. Tap Copy HeyGen prompt below, then paste it into Video Agent." });
    } catch (e) { setError(e instanceof Error ? e.message : "Could not open HeyGen"); }
    finally { setVideoLoading(false); }
  }


  async function attachFinishedVideo(file: File | null) {
    if (!result || !file) return;
    setError("");
    try {
      const post = upsertCurrentPost({ status: "ready", videoFileName: file.name, videoUrl: undefined });
      if (!post) return;
      await saveLocalVideo(post.id, file);
      const objectUrl = URL.createObjectURL(file);
      setVideo({ status: "ready-local", videoUrl: objectUrl, localFile: true, fileName: file.name, error: "Saved on this device. Add a public video URL below when you want to publish through a connected social account." });
      setFinishedVideoUrl("");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not save the video on this device"); }
  }

  function saveFinishedVideoUrl() {
    if (!result) return;
    const url = finishedVideoUrl.trim();
    if (!/^https?:\/\//i.test(url)) { setError("Paste a public https:// video URL first."); return; }
    const post = upsertCurrentPost({ status: "ready", videoUrl: url, videoFileName: undefined });
    if (post) deleteLocalVideo(post.id).catch(() => {});
    setVideo({ status: "ready", videoUrl: url, localFile: false, error: "Video URL saved. This post is ready to publish." });
    setError("");
  }

  async function copyHeygenPrompt() {
    if (!heygenPrompt) return;
    try { await navigator.clipboard.writeText(heygenPrompt); setVideo(v => v ? {...v, error: "Copied! Return to HeyGen, paste into Video Agent, and generate."} : v); }
    catch { setError("Clipboard access was blocked. Select and copy the prompt below."); }
  }

  function publishCaptionText() {
    if (!result) return "";
    const tags = (result.hashtags || []).join(" ");
    return `${result.caption}${tags ? `\n\n${tags}` : ""}`.trim();
  }

  async function copyPublishCaption() {
    const text = publishCaptionText();
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setPublishResult({ manual: true, message: "Caption and hashtags copied." });
    } catch {
      setError("Clipboard access was blocked. Copy the caption from the AI package above.");
    }
  }

  function openManualPublisher(target: "tiktok" | "instagram" | "youtube") {
    const urls = {
      tiktok: "https://www.tiktok.com/upload",
      instagram: "https://www.instagram.com/",
      youtube: "https://www.youtube.com/upload"
    };
    window.open(urls[target], "_blank", "noopener,noreferrer");
  }

  async function saveVideoToDevice() {
    if (!video?.videoUrl) return;
    setError("");

    const safeBase = (result?.title || "socialpilot-video")
      .replace(/[^a-z0-9]+/gi, "-")
      .replace(/^-|-$/g, "")
      .toLowerCase() || "socialpilot-video";
    const fileName = video.fileName || `${safeBase}.mp4`;

    try {
      let blob: Blob | null = null;

      if (video.localFile && selectedPostId) {
        blob = (await loadLocalVideo(selectedPostId)) ?? null;
      }

      if (!blob && video.videoUrl.startsWith("blob:")) {
        const response = await fetch(video.videoUrl);
        blob = await response.blob();
      }

      if (!blob && /^https?:\/\//i.test(video.videoUrl)) {
        try {
          const response = await fetch(video.videoUrl);
          if (response.ok) blob = await response.blob();
        } catch {
          // Some public video hosts block cross-origin downloads. We fall back to opening the URL.
        }
      }

      if (blob) {
        const file = new File([blob], fileName, { type: blob.type || "video/mp4" });
        const shareData: ShareData = { files: [file], title: result?.title || "DRAIG video" };

        if (navigator.share && (!navigator.canShare || navigator.canShare(shareData))) {
          await navigator.share(shareData);
          setPublishResult({ manual: true, message: "Your device share sheet is open. Choose Save Video or Save to Files to keep the video." });
          return;
        }

        const objectUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = objectUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
        setPublishResult({ manual: true, message: "Download started. If your browser opened the video instead, use its Share menu to save it." });
        return;
      }

      window.open(video.videoUrl, "_blank", "noopener,noreferrer");
      setPublishResult({ manual: true, message: "The video opened in a new tab. Use the browser Share menu, then choose Save Video or Save to Files." });
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return;
      window.open(video.videoUrl, "_blank", "noopener,noreferrer");
      setError("Your browser could not download the video directly. The video was opened so you can use Share → Save Video or Save to Files.");
    }
  }

  const nav = ["Dashboard", "Action Queue", "Launch Accounts", "Inbox", "Revenue", "Orders", "Support", "Funnel", "Website", "Business", "Sales", "Copilot", "Create", "Videos", "Calendar", "Accounts", "Analytics", "Settings"];
  const counts = {
    total: savedPosts.length,
    drafts: savedPosts.filter(p => p.status === "draft").length,
    ready: savedPosts.filter(p => p.status === "ready").length,
    published: savedPosts.filter(p => p.status === "published").length
  };
  const today = new Date().toISOString().slice(0,10);
  const salesStats = {
    leads: leads.filter(l => l.status !== "customer" && l.status !== "lost").length,
    customers: leads.filter(l => l.status === "customer").length,
    pipeline: leads.filter(l => l.status !== "lost").reduce((sum,l) => sum + (Number(l.value) || 0), 0),
    due: leads.filter(l => l.followUpDate && l.followUpDate <= today && l.status !== "customer" && l.status !== "lost").length
  };
  const orderStats = {
    total: orders.length,
    open: orders.filter(o => ["new","paid","fulfilling"].includes(o.status)).length,
    completed: orders.filter(o => o.status === "completed").length,
    value: orders.filter(o => o.status !== "cancelled").reduce((sum,o)=>sum+(Number(o.amount)||0),0)
  };
  const visibleOrders = orders.filter(o => orderFilter === "all" || o.status === orderFilter);
  const visibleSupportTickets = supportTickets.filter(t => supportFilter === "all" || t.status === supportFilter);
  const openSupportCount = supportTickets.filter(t => t.status !== "resolved").length;
  const dueRetentionCount = retentionActions.filter(a => !a.done && a.dueDate <= new Date().toISOString().slice(0,10)).length;
  const visibleLeads = leads.filter(l => leadFilter === "all" || l.status === leadFilter);
  const revenueTotal = revenueEntries.filter(e=>e.kind === "revenue").reduce((sum,e)=>sum+e.amount,0);
  const expenseTotal = revenueEntries.filter(e=>e.kind === "expense").reduce((sum,e)=>sum+e.amount,0);
  const profitTotal = revenueTotal - expenseTotal;
  const goalProgress = revenueGoal > 0 ? Math.max(0, Math.min(100, Math.round((revenueTotal / revenueGoal) * 100))) : 0;
  const metricTotals = performanceMetrics.reduce((a,m)=>({ impressions:a.impressions+m.impressions, clicks:a.clicks+m.clicks, leads:a.leads+m.leads, sales:a.sales+m.sales, revenue:a.revenue+m.revenue }), { impressions:0, clicks:0, leads:0, sales:0, revenue:0 });
  const clickRate = metricTotals.impressions > 0 ? (metricTotals.clicks / metricTotals.impressions) * 100 : 0;
  const leadRate = metricTotals.clicks > 0 ? (metricTotals.leads / metricTotals.clicks) * 100 : 0;
  const closeRate = metricTotals.leads > 0 ? (metricTotals.sales / metricTotals.leads) * 100 : 0;
  const avgOrderValue = metricTotals.sales > 0 ? metricTotals.revenue / metricTotals.sales : (orderStats.completed > 0 ? orderStats.value / orderStats.completed : 0);
  const filteredPosts = savedPosts.filter(p => {
    const q = libraryQuery.trim().toLowerCase();
    const matchesQ = !q || [p.title, p.hook, p.idea, p.platform, p.tone].some(v => v.toLowerCase().includes(q));
    const matchesF = libraryFilter === "all" || p.status === libraryFilter;
    return matchesQ && matchesF;
  });
  async function disconnectAccount(platformName: string) {
    setDisconnecting(platformName); setError("");
    try {
      const r = await fetch(`/api/accounts?platform=${encodeURIComponent(platformName)}`, { method: "DELETE" });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || "Could not disconnect account");
      await loadAccounts();
      if (publishPlatform === platformName) setPublishPlatform("tiktok");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not disconnect account"); }
    finally { setDisconnecting(""); }
  }

  async function publishVideo(voiceApproved = false) {
    if (!video?.videoUrl) { setError("No finished video is ready to publish."); if (voiceEnabledRef.current) speakText("There is no finished video ready to publish yet."); return; }
    if (!publishConsent && !voiceApproved) { setError("Confirm the final post and approve publishing first."); return; }
    setPublishing(true); setPublishResult(null); setError("");
    try {
      const r = await fetch("/api/publish", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ platform: publishPlatform, videoUrl: video.videoUrl, caption: result?.caption + "\n\n" + (result?.hashtags || []).join(" "), title: result?.title, privacyLevel, allowComment: true, allowDuet: true, allowStitch: true, consent:true, isAigc, promotesOwnBusiness, paidPartnership }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error?.message || d.error || "Publish failed");
      setPublishResult(d);
      if (d.publishId) setTiktokPublishId(d.publishId);
      if (d.published && selectedPostId) { const post = savedPosts.find(p => p.id === selectedPostId); if (post) updateSavedPost(post, { status: "published" }); }
      setPublishConsent(false);
      if (voiceEnabledRef.current) speakText("Your approved publish request was sent.");
    } catch(e) { setError(e instanceof Error ? e.message : "Publish failed"); if (voiceEnabledRef.current) speakText("The publish request failed. Check the message on screen."); } finally { setPublishing(false); }
  }

  async function checkTikTokPublishStatus() {
    if (!tiktokPublishId) return;
    try {
      const r = await fetch(`/api/tiktok/status?publishId=${encodeURIComponent(tiktokPublishId)}`, { cache:"no-store" });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error?.message || d.error || "Could not check TikTok status");
      setPublishResult((prev:any)=>({...prev,status:d.data || d}));
      if (d.data?.status === "PUBLISH_COMPLETE" && selectedPostId) { const post = savedPosts.find(p=>p.id===selectedPostId); if (post) updateSavedPost(post,{status:"published"}); }
    } catch(e) { setError(e instanceof Error ? e.message : "Could not check TikTok status"); }
  }

  voiceCommandHandlerRef.current = async (rawCommand: string) => {
    const command = rawCommand.trim();
    const lower = command.toLowerCase().replace(/[?.!]+$/g, "");
    setVoiceStatus(`Command: ${command}`);

    if (/^(stop|stop talking|be quiet|silence)$/.test(lower)) { stopSpeaking(); setVoiceStatus('Listening for “Hey DRAIG”'); return; }
    if (/^(cancel|cancel that|never mind|nevermind)$/.test(lower)) { voicePendingActionRef.current = null; setVoicePendingAction(null); speakText("Cancelled."); return; }
    if (lower === "confirm publish" || lower === "confirm publishing") {
      if (voicePendingActionRef.current !== "publish") { speakText("There is no publish action waiting for confirmation."); return; }
      voicePendingActionRef.current = null; setVoicePendingAction(null);
      await publishVideo(true); return;
    }
    if (/(publish|post it|publish it)/.test(lower)) {
      voicePendingActionRef.current = "publish"; setVoicePendingAction("publish"); setTab("Videos");
      speakText("Publishing is an external action. Say Hey DRAIG, confirm publish to approve it, or say Hey DRAIG, cancel."); return;
    }
    if (/(plan my day|run autopilot|make my plan|today's plan|todays plan)/.test(lower)) {
      setTab("Action Queue"); speakText("I am building today's plan."); await runAutopilot(); speakText("Your DRAIG Autopilot plan is ready."); return;
    }
    if (/(run approved actions|execute approved actions|do approved actions)/.test(lower)) {
      setTab("Action Queue"); speakText("Running approved internal actions. Publishing is excluded unless separately confirmed."); await runApprovedActions(); speakText("Approved internal actions are complete."); return;
    }
    if (/(enable autopilot|turn on autopilot)/.test(lower)) { if (!autopilotEnabled) toggleAutopilot(); speakText("Autopilot is enabled."); return; }
    if (/(disable autopilot|turn off autopilot)/.test(lower)) { if (autopilotEnabled) toggleAutopilot(); speakText("Autopilot is disabled."); return; }

    const ideaMatch = lower.match(/(?:turn|make|use) (?:idea )?(?:number )?(one|two|three|four|five|1|2|3|4|5)(?: into (?:a )?full post)?/);
    if (ideaMatch) {
      const numbers: Record<string,number> = {one:1,two:2,three:3,four:4,five:5,"1":1,"2":2,"3":3,"4":4,"5":5};
      const index = numbers[ideaMatch[1]] - 1; const item = copilotIdeas[index];
      if (!item) { speakText("That idea is not available yet."); return; }
      const brief = `${item.title} — ${item.angle}. Hook: ${item.hook}`; setTab("Create"); speakText(`Creating the full post for idea ${index+1}.`); await generateContent(brief); return;
    }

    if (/(save (this )?(post|content)|save it)/.test(lower)) {
      if (!result) { speakText("There is no generated post to save yet."); return; }
      saveCurrentPost(); speakText("Saved."); return;
    }

    const navTarget = nav.find(n => lower === `open ${n.toLowerCase()}` || lower === `show ${n.toLowerCase()}` || lower === `go to ${n.toLowerCase()}` || lower === n.toLowerCase());
    if (navTarget) { setTab(navTarget); speakText(`Opening ${navTarget}.`); return; }
    if (/(show|open) (my )?(leads|customers|crm)/.test(lower)) { setTab("Sales"); speakText("Opening Sales and CRM."); return; }
    if (/(show|open) (my )?(posts|content|videos)/.test(lower)) { setTab("Videos"); speakText("Opening your content library."); return; }
    if (/(show|open) (analytics|performance|results)/.test(lower)) { setTab("Analytics"); speakText("Opening analytics."); return; }
    if (/(what can you do|help|voice help)/.test(lower)) {
      speakText("You can tell me to open any workspace, create content ideas, turn an idea into a full post, save a post, plan your day, run approved internal actions, control Autopilot, and prepare publishing with a separate confirmation."); return;
    }

    if (/(create|generate|make|give me|write)/.test(lower)) {
      const topic = command.replace(/^(create|generate|make|give me|write)\s+/i, "").trim();
      setTab("Copilot"); speakText("I am creating content ideas from your request."); await generateCopilotIdeas(topic || command); return;
    }

    speakText("I did not recognize that command. Say Hey DRAIG, help to hear examples.");
  };

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">◈</span><span><b>DRAIG</b></span></div>
        <nav>{nav.map(n => <button key={n} className={tab === n ? "nav active" : "nav"} onClick={() => setTab(n)}>{n}</button>)}</nav>
        <div className="side-card"><strong>DRAIG Voice Business AI</strong><span>Say “Hey DRAIG” while voice mode is enabled.</span></div>
      </aside>

      <section className="main">
        <header className="topbar"><div><div className="eyebrow">DRAIG · VOICE BUSINESS AI</div><h1>{tab}</h1></div><div className="voice-topbar"><div className="status-dot"><i/> Gemini direct</div><button className={voiceEnabled ? "voice-button active" : "voice-button"} onClick={voiceEnabled ? stopVoiceMode : startVoiceMode} disabled={!voiceAvailable}>{voiceEnabled ? "● Voice on" : "🎤 Enable voice"}</button></div></header>
        <section className={voiceEnabled ? "voice-dock active" : "voice-dock"}>
          <div><strong>Hey DRAIG</strong><span>{voiceAvailable ? voiceStatus : "Voice recognition is not supported by this browser."}</span>{voiceTranscript && <small>Heard: “{voiceTranscript}”</small>}{voicePendingAction && <small className="voice-warning">Waiting for spoken confirmation: {voicePendingAction}</small>}</div>
          <div className="voice-actions">
            {voiceOptions.length > 0 && <select aria-label="DRAIG voice" value={voiceName} onChange={e=>setVoiceName(e.target.value)}>{voiceOptions.map(v=><option key={`${v.name}-${v.lang}`} value={v.name}>{v.name} · {v.lang}</option>)}</select>}
            <button className="secondary small" onClick={()=>speakText("DRAIG is ready.")}>Test voice</button>
            {voiceEnabled && <button className="secondary small" onClick={stopVoiceMode}>Turn off</button>}
          </div>
        </section>

        {tab === "Dashboard" ? (
          <div className="dashboard-stack">
            <section className="hero-panel">
              <div><span className="kicker">DRAIG V7</span><h2>Plan today’s work and move the business forward.</h2><p>Autopilot can prioritize your business, content, and sales pipeline while the existing creator and CRM tools handle execution.</p></div>
              <div className="button-row"><button className="secondary" onClick={()=>setTab("Action Queue")}>Open Autopilot</button><button className="primary" onClick={runAutopilot} disabled={autopilotLoading}>{autopilotLoading ? "Planning…" : "Plan my day ✦"}</button></div>
            </section>
            <section className="stat-grid">
              <button className="stat-card" onClick={() => setTab("Videos")}><span>Saved packages</span><strong>{counts.total}</strong><small>All local content</small></button>
              <button className="stat-card" onClick={() => { setTab("Videos"); setLibraryFilter("draft"); }}><span>Drafts</span><strong>{counts.drafts}</strong><small>Needs video or review</small></button>
              <button className="stat-card" onClick={() => { setTab("Videos"); setLibraryFilter("ready"); }}><span>Ready</span><strong>{counts.ready}</strong><small>Video-ready content</small></button>
              <button className="stat-card" onClick={() => { setTab("Videos"); setLibraryFilter("published"); }}><span>Published</span><strong>{counts.published}</strong><small>Marked published</small></button>
            </section>
            <section className="stat-grid">
              <button className="stat-card" onClick={() => setTab("Sales")}><span>Active leads</span><strong>{salesStats.leads}</strong><small>Prospects in your pipeline</small></button>
              <button className="stat-card" onClick={() => setTab("Sales")}><span>Customers</span><strong>{salesStats.customers}</strong><small>Converted customers</small></button>
              <button className="stat-card" onClick={() => setTab("Sales")}><span>Pipeline</span><strong>${salesStats.pipeline.toLocaleString()}</strong><small>Potential value</small></button>
              <button className="stat-card" onClick={() => setTab("Sales")}><span>Follow-ups due</span><strong>{salesStats.due}</strong><small>Needs attention</small></button>
            </section>
            <section className="stat-grid">
              <button className="stat-card" onClick={() => setTab("Revenue")}><span>Revenue</span><strong>${revenueTotal.toLocaleString()}</strong><small>{goalProgress}% of goal</small></button>
              <button className="stat-card" onClick={() => setTab("Revenue")}><span>Expenses</span><strong>${expenseTotal.toLocaleString()}</strong><small>Tracked costs</small></button>
              <button className="stat-card" onClick={() => setTab("Revenue")}><span>Profit</span><strong>${profitTotal.toLocaleString()}</strong><small>Revenue minus expenses</small></button>
              <button className="stat-card" onClick={() => setTab("Revenue")}><span>Goal</span><strong>${revenueGoal.toLocaleString()}</strong><small>Current revenue target</small></button>
            </section>
            <section className="panel dashboard-recent"><div className="panel-head inline-head"><div><span className="kicker">RECENT</span><h2>Recent content</h2></div><button className="secondary small" onClick={() => setTab("Videos")}>View library</button></div>
              {savedPosts.length === 0 ? <div className="empty compact"><span>✦</span><p>Your first generated post will appear here.</p></div> : <div className="saved-grid">{savedPosts.slice(0,3).map(post => <article className="saved-card" key={post.id}><div className="saved-card-top"><span className="kicker">{post.platform}</span><span className="saved-status">{post.status}</span></div><h3>{post.title}</h3><p>{post.hook}</p><div className="button-row"><button className="primary small" onClick={() => openSavedPost(post)}>Open</button><button className="secondary small" onClick={() => duplicateSavedPost(post)}>Duplicate</button></div></article>)}</div>}
            </section>
          </div>
          ) : tab === "Orders" ? (
          <div className="dashboard-stack">
            <section className="hero-panel">
              <div><span className="kicker">DRAIG V7</span><h2>Track every customer from order to fulfillment.</h2><p>Record storefront or manual orders, move them through fulfillment, link paid orders to Revenue, and keep customer operations in the same cloud workspace. Payments still happen through your external checkout/contact link.</p></div>
              {websitePublished && <button className="secondary" onClick={()=>window.open("/site", "_blank", "noopener,noreferrer")}>Open storefront ↗</button>}
            </section>
            <section className="stat-grid">
              <div className="stat-card"><span>Orders</span><strong>{orderStats.total}</strong><small>All recorded</small></div>
              <div className="stat-card"><span>Open</span><strong>{orderStats.open}</strong><small>Needs attention</small></div>
              <div className="stat-card"><span>Completed</span><strong>{orderStats.completed}</strong><small>Fulfilled</small></div>
              <div className="stat-card"><span>Order value</span><strong>${orderStats.value.toLocaleString()}</strong><small>Excludes cancelled</small></div>
            </section>
            <section className="panel">
              <div className="panel-head"><div><span className="kicker">NEW ORDER</span><h2>Add a customer order</h2></div></div>
              <div className="form-grid">
                <label>Customer<input value={orderCustomerName} onChange={e=>setOrderCustomerName(e.target.value)} placeholder="Customer name" /></label>
                <label>Contact<input value={orderContact} onChange={e=>setOrderContact(e.target.value)} placeholder="Email, phone, or handle" /></label>
                <label>Product / service<input value={orderItem} onChange={e=>setOrderItem(e.target.value)} placeholder={websitePlan?.products?.[0]?.name || funnelPlan?.offerName || "What they bought"} /></label>
                <label>Amount<input inputMode="decimal" value={orderAmount} onChange={e=>setOrderAmount(e.target.value)} placeholder="0.00" /></label>
                <label>Source<select value={orderSource} onChange={e=>setOrderSource(e.target.value)}><option>Website</option><option>TikTok</option><option>Instagram</option><option>YouTube</option><option>Referral</option><option>Other</option></select></label>
                <label className="wide-label">Notes<input value={orderNotes} onChange={e=>setOrderNotes(e.target.value)} placeholder="Delivery details, request, due date, etc." /></label>
              </div>
              <button className="primary" onClick={addOrder}>Add order</button>
            </section>
            <section className="panel library-panel">
              <div className="panel-head inline-head"><div><span className="kicker">ORDER BOARD</span><h2>Customer operations</h2></div><select value={orderFilter} onChange={e=>setOrderFilter(e.target.value as any)}><option value="all">All</option><option value="new">New</option><option value="paid">Paid</option><option value="fulfilling">Fulfilling</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></div>
              {visibleOrders.length===0 ? <div className="empty compact"><span>◎</span><p>No orders in this view yet.</p></div> : <div className="saved-grid">{visibleOrders.map(o=><article className="saved-card" key={o.id}>
                <div className="saved-card-top"><span className="kicker">{o.source}</span><span className="saved-status">${o.amount.toLocaleString()}</span></div>
                <h3>{o.customerName}</h3><p>{o.item}</p>{o.contact && <p className="muted">{o.contact}</p>}{o.notes && <p className="muted">{o.notes}</p>}
                <label>Status<select value={o.status} onChange={e=>updateOrder(o.id,{status:e.target.value as OrderStatus})}><option value="new">New</option><option value="paid">Paid</option><option value="fulfilling">Fulfilling</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></label>
                <div className="button-row">{!o.revenueLinked && o.amount>0 && <button className="primary small" onClick={()=>linkOrderRevenue(o)}>Add to revenue</button>}{o.revenueLinked && <span className="saved-status">Revenue linked</span>}<button className="secondary small" onClick={()=>deleteOrder(o.id)}>Delete</button></div>
              </article>)}</div>}
              <p className="muted">DRAIG tracks operations; your external checkout/provider remains the source of truth for whether a payment actually cleared. Only link revenue after you verify payment.</p>
            </section>
          </div>
        ) : tab === "Support" ? (
          <div className="workspace-stack">
            <section className="panel">
              <div className="panel-head"><div><span className="kicker">V16 FREE CUSTOMER SUPPORT + RETENTION</span><h2>Take care of customers and earn repeat business.</h2><p>Track support issues, draft helpful replies with Gemini, schedule review requests and re-engagement, and feed customer needs back into Autopilot.</p></div></div>
              <div className="stats-grid"><div className="stat-card"><span>Open support</span><strong>{openSupportCount}</strong><small>Needs attention</small></div><div className="stat-card"><span>Retention due</span><strong>{dueRetentionCount}</strong><small>Follow-ups due</small></div><div className="stat-card"><span>Resolved</span><strong>{supportTickets.filter(t=>t.status==='resolved').length}</strong><small>Support closed</small></div><div className="stat-card"><span>Retention plans</span><strong>{retentionActions.length}</strong><small>Review + re-engage</small></div></div>
            </section>
            <section className="panel"><div className="panel-head"><div><span className="kicker">SUPPORT DESK</span><h2>Add a customer issue</h2></div></div><div className="form-grid"><label>Customer<input value={supportName} onChange={e=>setSupportName(e.target.value)} /></label><label>Contact<input value={supportContact} onChange={e=>setSupportContact(e.target.value)} /></label><label>Priority<select value={supportPriority} onChange={e=>setSupportPriority(e.target.value as any)}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></label><label>Subject<input value={supportSubject} onChange={e=>setSupportSubject(e.target.value)} /></label><label className="wide-label">Customer message<textarea value={supportMessage} onChange={e=>setSupportMessage(e.target.value)} /></label></div><button className="primary" onClick={addSupportTicket}>Add support ticket</button></section>
            <section className="panel"><div className="panel-head inline-head"><div><span className="kicker">TICKETS</span><h2>Customer support queue</h2></div><select value={supportFilter} onChange={e=>setSupportFilter(e.target.value as any)}><option value="all">All</option><option value="open">Open</option><option value="waiting">Waiting</option><option value="resolved">Resolved</option></select></div>{visibleSupportTickets.length===0 ? <div className="empty compact"><span>♡</span><p>No support tickets in this view.</p></div> : <div className="saved-grid">{visibleSupportTickets.map(t=><article className="saved-card" key={t.id}><div className="saved-card-top"><span className="kicker">{t.priority.toUpperCase()}</span><select className="status-select" value={t.status} onChange={e=>updateSupportTicket(t.id,{status:e.target.value as SupportStatus})}><option value="open">open</option><option value="waiting">waiting</option><option value="resolved">resolved</option></select></div><h3>{t.subject}</h3><p><strong>{t.customerName}</strong>{t.contact ? ` · ${t.contact}` : ''}</p><p>{t.message}</p><div className="button-row"><button className="primary small" onClick={()=>generateSupportReply(t)} disabled={supportReplyLoadingId===t.id}>{supportReplyLoadingId===t.id ? 'Drafting…' : 'Draft AI reply ✦'}</button><button className="secondary small" onClick={()=>deleteSupportTicket(t.id)}>Delete</button></div>{supportReplyDrafts[t.id] && <div className="finish-box"><strong>{supportReplyDrafts[t.id].subject}</strong><p>{supportReplyDrafts[t.id].message}</p><button className="secondary small" onClick={()=>navigator.clipboard?.writeText(supportReplyDrafts[t.id].message)}>Copy reply</button></div>}</article>)}</div>}</section>
            <section className="panel"><div className="panel-head"><div><span className="kicker">RETENTION ENGINE</span><h2>Plan reviews, follow-ups, and re-engagement.</h2></div></div><div className="form-grid"><label>Customer<input value={retentionCustomer} onChange={e=>setRetentionCustomer(e.target.value)} /></label><label>Contact<input value={retentionContact} onChange={e=>setRetentionContact(e.target.value)} /></label><label>Action<select value={retentionKind} onChange={e=>setRetentionKind(e.target.value as any)}><option value="review">Review / testimonial request</option><option value="reengage">Re-engage customer</option><option value="followup">Post-purchase follow-up</option></select></label><label>Due date<input type="date" value={retentionDate} onChange={e=>setRetentionDate(e.target.value)} /></label><label className="wide-label">Notes<input value={retentionNotes} onChange={e=>setRetentionNotes(e.target.value)} /></label></div><button className="primary" onClick={addRetentionAction}>Add retention action</button><div className="calendar-list">{retentionActions.length===0 ? <div className="empty compact"><span>↻</span><p>No retention actions yet.</p></div> : retentionActions.map(a=><article className="calendar-row" key={a.id}><div><strong>{a.customerName}</strong><span>{a.kind} · {a.dueDate}</span></div><button className={a.done ? 'secondary small' : 'primary small'} onClick={()=>updateRetentionAction(a.id,{done:!a.done})}>{a.done ? 'Done' : 'Mark done'}</button><button className="secondary small" onClick={()=>deleteRetentionAction(a.id)}>Delete</button></article>)}</div></section>
          </div>
        ) : tab === "Website" ? (
          <div className="workspace-stack">
            <section className="panel hero-panel">
              <div><span className="kicker">V14 FREE WEBSITE + STORE BUILDER</span><h2>Turn your offer into a public website.</h2><p>Generate a clean one-page storefront from your business and funnel, save it to Neon, then publish it free at <b>/site</b> on this Vercel project.</p></div>
              <div className="button-row"><button className="primary" onClick={buildWebsite} disabled={websiteLoading}>{websiteLoading ? "Building site…" : "Build my website ✦"}</button>{websitePlan && <button className="secondary" onClick={()=>window.open("/site", "_blank", "noopener,noreferrer")}>Open public site ↗</button>}</div>
            </section>
            <section className="panel"><div className="panel-head"><div><span className="kicker">WEBSITE BRIEF</span><h2>What should the site sell?</h2></div></div>
              <textarea value={websiteBrief} onChange={e=>setWebsiteBrief(e.target.value)} placeholder={funnelPlan ? `Example: Build a storefront for ${funnelPlan.offerName}` : businessPlan ? `Example: Build a site for ${businessPlan.offer}` : "Example: A simple landing page selling social media content packages to local businesses."} />
            </section>
            {websitePlan && <>
              <section className="panel"><div className="panel-head inline-head"><div><span className="kicker">SITE PREVIEW</span><h2>{websitePlan.siteName}</h2><p>{websitePlan.tagline}</p></div><span className={websitePublished ? "status-pill published" : "status-pill draft"}>{websitePublished ? "PUBLIC" : "DRAFT"}</span></div>
                <div className="business-summary"><div><b>Headline</b><span>{websitePlan.heroHeadline}</span></div><div><b>Offer cards</b><span>{websitePlan.products.length}</span></div><div><b>Benefits</b><span>{websitePlan.benefits.length}</span></div><div><b>FAQ</b><span>{websitePlan.faq.length}</span></div></div>
                <label>Button / checkout link<input value={websiteActionUrl} onChange={e=>setWebsiteActionUrl(e.target.value)} placeholder="https://your-checkout-or-contact-link" /></label>
                <div className="button-row"><button className="secondary" onClick={saveWebsiteActionUrl}>Save link</button><button className={websitePublished ? "secondary" : "primary"} onClick={toggleWebsitePublished}>{websitePublished ? "Unpublish site" : "Publish site"}</button><button className="secondary" onClick={()=>window.open("/site", "_blank", "noopener,noreferrer")}>Preview / open site ↗</button></div>
                <p className="muted">Publishing only exposes the generated website/store copy. Your leads, revenue, owner key, and private business data stay behind the server-side cloud API.</p>
              </section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">STORE CONTENT</span><h2>{websitePlan.heroHeadline}</h2><p>{websitePlan.heroSubheadline}</p></div></div><div className="saved-grid">{websitePlan.products.map((p,i)=><article className="saved-card" key={i}><span className="kicker">{p.price}</span><h3>{p.name}</h3><p>{p.description}</p><strong>{p.buttonLabel}</strong></article>)}</div></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">ABOUT + FAQ</span><h2>Trust-building copy</h2></div></div><p>{websitePlan.about}</p><div className="settings-list">{websitePlan.faq.map((f,i)=><div key={i}><strong>{f.question}</strong><span>{f.answer}</span></div>)}</div></section>
            </>}
          </div>
         ) : tab === "Funnel" ? (
          <div className="dashboard-stack">
            <section className="hero-panel">
              <div><span className="kicker">V13 FREE OFFER + FUNNEL ENGINE</span><h2>Turn your offer into a simple path from attention to sale.</h2><p>Build a clear offer, free lead magnet, landing-page copy, follow-up sequence, and content angles using the same Gemini setup. DRAIG drafts the funnel; publishing, outreach, checkout, and spending remain under your control.</p></div>
              <button className="primary" onClick={buildFunnel} disabled={funnelLoading}>{funnelLoading ? "Building funnel…" : "Build my funnel ✦"}</button>
            </section>
            <section className="panel">
              <div className="panel-head"><div><span className="kicker">FUNNEL BRIEF</span><h2>What are you selling?</h2></div></div>
              <textarea value={funnelBrief} onChange={e=>setFunnelBrief(e.target.value)} placeholder={businessPlan ? `Example: Build a funnel for ${businessPlan.offer}` : "Example: A $49 social-media content template pack for local service businesses."} />
              {businessPlan && <p className="muted">Your saved business plan is automatically used as context.</p>}
            </section>
            {funnelPlan ? <>
              <section className="panel">
                <div className="panel-head inline-head"><div><span className="kicker">OFFER</span><h2>{funnelPlan.offerName}</h2></div><span className="saved-status">{funnelPlan.price}</span></div>
                <div className="business-summary"><div><b>Audience</b><span>{funnelPlan.audience}</span></div><div><b>Promise</b><span>{funnelPlan.promise}</span></div><div><b>CTA</b><span>{funnelPlan.callToAction}</span></div><div><b>Funnel</b><span>{funnelPlan.funnelName}</span></div></div>
              </section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">LANDING PAGE</span><h2>{funnelPlan.landingHeadline}</h2></div></div><p>{funnelPlan.landingSubheadline}</p><div className="settings-list">{funnelPlan.benefits.map((x,i)=><div key={i}><strong>Benefit {i+1}</strong><span>{x}</span></div>)}</div></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">FREE LEAD MAGNET</span><h2>{funnelPlan.leadMagnetTitle}</h2></div></div><ol className="content-list">{funnelPlan.leadMagnetOutline.map((x,i)=><li key={i}>{x}</li>)}</ol></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">FUNNEL STEPS</span><h2>Customer journey</h2></div></div><ol className="content-list">{funnelPlan.funnelSteps.map((x,i)=><li key={i}>{x}</li>)}</ol></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">FOLLOW-UP SEQUENCE</span><h2>Prepared messages</h2></div></div><div className="saved-grid">{funnelPlan.followupSequence.map((m,i)=><article className="saved-card" key={i}><div className="saved-card-top"><span className="kicker">{m.day}</span></div><h3>{m.subject}</h3><p>{m.message}</p></article>)}</div><p className="muted">These are drafts only. DRAIG does not send messages to real people without your action/approval.</p></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">CONTENT TO FEED THE FUNNEL</span><h2>Starter angles</h2></div></div><div className="saved-grid">{funnelPlan.contentAngles.map((x,i)=><article className="saved-card" key={i}><h3>{x}</h3><button className="secondary small" onClick={()=>useFunnelContentIdea(x)}>Create post</button></article>)}</div></section>
            </> : <div className="panel empty"><span>✦</span><p>Build your first funnel and DRAIG will save it locally and to Cloud Sync.</p></div>}
          </div>
         ) : tab === "Revenue" ? (
          <div className="dashboard-stack">
            <section className="hero-panel">
              <div><span className="kicker">V14 FREE REVENUE ENGINE</span><h2>Track the money and decide the next best move.</h2><p>Revenue Engine combines your business plan, pipeline, content, revenue, and expenses to recommend the highest-leverage action to move toward your goal. It does not promise income or spend money automatically.</p></div>
              <button className="primary" onClick={generateRevenueAdvice} disabled={revenueLoading}>{revenueLoading ? "Analyzing…" : "Find my next money move ✦"}</button>
            </section>
            <section className="stat-grid">
              <div className="stat-card"><span>Revenue</span><strong>${revenueTotal.toLocaleString()}</strong><small>{goalProgress}% of goal</small></div>
              <div className="stat-card"><span>Expenses</span><strong>${expenseTotal.toLocaleString()}</strong><small>Recorded costs</small></div>
              <div className="stat-card"><span>Profit</span><strong>${profitTotal.toLocaleString()}</strong><small>Before taxes/fees not entered</small></div>
              <div className="stat-card"><span>Goal</span><strong>${revenueGoal.toLocaleString()}</strong><small>Editable below</small></div>
            </section>
            <section className="panel"><div className="panel-head"><div><span className="kicker">MONEY TRACKER</span><h2>Add revenue or an expense</h2></div></div>
              <div className="form-grid"><label>Revenue goal<input type="number" min="0" value={revenueGoal} onChange={e=>{const g=Math.max(0,Number(e.target.value||0)); persistRevenue(revenueEntries,g,revenueAdvice);}} /></label><label>Type<select value={moneyKind} onChange={e=>setMoneyKind(e.target.value as "revenue"|"expense")}><option value="revenue">Revenue</option><option value="expense">Expense</option></select></label><label>Amount<input inputMode="decimal" value={moneyAmount} onChange={e=>setMoneyAmount(e.target.value)} placeholder="100" /></label><label>Date<input type="date" value={moneyDate} onChange={e=>setMoneyDate(e.target.value)} /></label><label className="wide-label">Label<input value={moneyLabel} onChange={e=>setMoneyLabel(e.target.value)} placeholder="Example: Client payment or Canva subscription" /></label></div><button className="primary" onClick={addMoneyEntry}>Add entry</button>
            </section>
            {revenueAdvice && <section className="panel"><div className="panel-head"><div><span className="kicker">NEXT BEST MONEY MOVE</span><h2>{revenueAdvice.nextMove}</h2></div></div><div className="success">{revenueAdvice.summary}</div><p><strong>Why:</strong> {revenueAdvice.why}</p><p><strong>Target:</strong> {revenueAdvice.target}</p><div className="settings-list">{revenueAdvice.actions.map((a,i)=><div key={i}><strong>Step {i+1}</strong><span>{a}</span></div>)}</div></section>}
            <section className="panel library-panel"><div className="panel-head inline-head"><div><span className="kicker">LEDGER</span><h2>Recent money activity</h2></div><span className="muted">{revenueEntries.length} entries</span></div>{revenueEntries.length===0?<div className="empty compact"><span>$</span><p>Add your first revenue or expense entry.</p></div>:<div className="saved-grid">{revenueEntries.map(e=><article className="saved-card" key={e.id}><div className="saved-card-top"><span className="kicker">{e.kind.toUpperCase()}</span><span className="saved-status">{e.date}</span></div><h3>{e.label}</h3><p>${e.amount.toLocaleString()}</p><button className="secondary small" onClick={()=>deleteMoneyEntry(e.id)}>Delete</button></article>)}</div>}</section>
          </div>
        ) : tab === "Action Queue" ? (
          <div className="dashboard-stack">
            <section className="hero-panel">
              <div><span className="kicker">DRAIG V7 EXECUTION ENGINE</span><h2>Turn the daily AI plan into controlled business actions.</h2><p>V7 turns Autopilot plans into executable actions. Safe work can create drafts, prepare follow-ups, update internal CRM data, refresh funnel/site copy, and record results. Publishing and other external/high-impact actions stay approval-gated.</p></div>
              <div className="button-row"><button className={autopilotEnabled ? "primary" : "secondary"} onClick={toggleAutopilot}>{autopilotEnabled ? "Autopilot ON" : "Turn Autopilot ON"}</button><button className="primary" onClick={runAutopilot} disabled={autopilotLoading}>{autopilotLoading ? "Planning today…" : "Run Autopilot now ✦"}</button></div>
            </section>
            <section className="stat-grid">
              <div className="stat-card"><span>Pending</span><strong>{autopilotTasks.filter(t=>canonicalActionStatus(t.status)==="pending").length}</strong><small>Waiting for approval</small></div>
              <div className="stat-card"><span>Approved</span><strong>{autopilotTasks.filter(t=>canonicalActionStatus(t.status)==="approved").length}</strong><small>Ready to execute</small></div>
              <div className="stat-card"><span>Completed</span><strong>{autopilotTasks.filter(t=>canonicalActionStatus(t.status)==="completed").length}</strong><small>Execution finished</small></div>
              <div className="stat-card"><span>Mode</span><strong>{autopilotEnabled ? "ON" : "OFF"}</strong><small>Local + cloud state</small></div>
            </section>
            <section className="panel library-panel">
              <div className="panel-head inline-head"><div><span className="kicker">TODAY</span><h2>Autonomous action queue</h2></div><span className="muted">{autopilotTasks.length} tasks</span></div>
              {autopilotSummary && <div className="success">{autopilotSummary}</div>}
              {error && <div className="error">{error}</div>}
              {autopilotTasks.length===0 ? <div className="empty"><span>✦</span><p>Tap Run Autopilot now to generate today's operating plan from your real DRAIG data.</p></div> : <><div className="button-row" style={{paddingBottom:14}}><button className="primary" onClick={runApprovedActions} disabled={Boolean(executionBusyId) || !autopilotTasks.some(t=>canonicalActionStatus(t.status)==="approved" && t.actionType!=="publish")}>{executionBusyId ? "Executing…" : "Run approved safe actions ✦"}</button></div><div className="saved-grid">{autopilotTasks.map(task=>{const s=canonicalActionStatus(task.status); return <article className="saved-card" key={task.id}><div className="saved-card-top"><span className="kicker">{task.priority.toUpperCase()} · {task.actionType}</span><span className={`saved-status action-${s}`}>{s}</span></div><h3>{task.title}</h3><p>{task.reason}</p>{task.requiresApproval && s==="pending" && <div className="muted">Approval required before this action can execute.</div>}{task.result && <div className="success">{task.result}</div>}{task.error && <div className="error compact-error">{task.error}</div>}<div className="button-row">{s==="pending" && <button className="primary small" onClick={()=>updateAutopilotTask(task.id,{status:"approved"})}>Approve</button>}{["approved","failed"].includes(s) && <button className="primary small" disabled={executionBusyId===task.id} onClick={()=>executeAutopilotTask(task)}>{executionBusyId===task.id ? "Running…" : s==="failed" ? "Retry" : "Execute"}</button>}<button className="secondary small" onClick={()=>openAutopilotTask(task)}>Open workspace</button></div></article>})}</div></>}
            </section>
            <section className="panel library-panel"><div className="panel-head inline-head"><div><span className="kicker">EXECUTION HISTORY</span><h2>What V7 actually did</h2></div><span className="muted">{executionLog.length} events</span></div>{executionLog.length===0?<div className="empty compact"><span>◎</span><p>Executed actions will be recorded here and fed back into Analytics.</p></div>:<div className="calendar-list">{executionLog.slice(0,20).map(x=><article className="calendar-row" key={x.id}><div><strong>{x.title}</strong><span>{x.actionType} · {x.status} · {new Date(x.createdAt).toLocaleString()}<br/>{x.message}</span></div></article>)}</div>}</section>
            <section className="panel placeholder"><div className="panel-head"><div><span className="kicker">AUTONOMY GUARDRAILS</span><h2>What V7 can execute</h2></div></div><div className="settings-list"><div><strong>Automatic</strong><span>Create content drafts, prepare lead follow-ups, update internal CRM status from verified recorded orders, refresh funnel/website copy, run internal reviews, and log execution results.</span></div><div><strong>Approval required</strong><span>Publishing, contacting real people, spending money, changing external accounts, deleting important data, and legal/financial actions. Approval unlocks execution only when the required connector/data is actually available.</span></div><div><strong>Free mode limitation</strong><span>Cloud mode persists business state and can execute safe content, follow-up-draft, and internal-review tasks on the daily Vercel schedule after the app is closed. Free Vercel scheduling is daily, not continuous.</span></div></div></section>
          </div>
        ) : tab === "Business" ? (
          <div className="creator-grid">
            <section className="panel composer">
              <div className="panel-head"><div><span className="kicker">V8 FREE BUSINESS BUILDER</span><h2>Start your online business</h2></div></div>
              <p className="muted" style={{padding:"0 20px"}}>Describe what you want to sell, what you are good at, or the audience you want to help. The AI will create a practical starter business plan using your existing Gemini setup.</p>
              <textarea value={businessBrief} onChange={e=>setBusinessBrief(e.target.value)} placeholder="Example: I want a simple online business I can run from my iPhone. I like AI and social media and want to start with almost no money." />
              <button className="primary wide" onClick={buildBusiness} disabled={businessLoading || !businessBrief.trim()}>{businessLoading ? "Building your business…" : "Build my business ✦"}</button>
              {error && <div className="error">{error}</div>}
              {businessPlan && <div className="button-row" style={{padding:"14px 20px 0"}}><button className="secondary" onClick={()=>{ setCopilotTopic(businessPlan.niche); setTab("Copilot"); }}>Create marketing ideas →</button><button className="secondary" onClick={()=>{ setIdea(businessPlan.offer); setTab("Create"); }}>Create first post →</button></div>}
            </section>
            <section className="panel output">
              <div className="panel-head"><div><span className="kicker">BUSINESS PLAN</span><h2>{businessPlan?.businessName || "Your plan will appear here"}</h2></div></div>
              {!businessPlan ? <div className="empty"><span>✦</span><p>Build a business to get your niche, offer, pricing, launch steps, products, marketing channels, and first content ideas.</p></div> : <div className="result">
                <div className="business-summary"><div><b>Niche</b><span>{businessPlan.niche}</span></div><div><b>Target customer</b><span>{businessPlan.targetCustomer}</span></div><div><b>Problem solved</b><span>{businessPlan.problemSolved}</span></div><div><b>Business model</b><span>{businessPlan.businessModel}</span></div><div><b>Offer</b><span>{businessPlan.offer}</span></div><div><b>Starter pricing</b><span>{businessPlan.pricing}</span></div></div>
                <label>Positioning<textarea readOnly value={businessPlan.positioning} /></label>
                <div className="two"><div><label>First products / services</label><ol>{businessPlan.firstProducts.map((x,i)=><li key={i}>{x}</li>)}</ol></div><div><label>Marketing channels</label><ol>{businessPlan.marketingChannels.map((x,i)=><li key={i}>{x}</li>)}</ol></div></div>
                <label>Launch steps</label><ol>{businessPlan.launchSteps.map((x,i)=><li key={i}>{x}</li>)}</ol>
                <label>First content ideas</label><ol>{businessPlan.first10Posts.map((x,i)=><li key={i}>{x}</li>)}</ol>
                <div className="video-job"><strong>30-day goal</strong><p>{businessPlan.thirtyDayGoal}</p></div>
                <p className="muted">Saved locally on this device. No paid business API is required.</p>
              </div>}
            </section>
          </div>
        ) : tab === "Sales" ? (
          <div className="sales-stack">
            <section className="panel sales-form">
              <div className="panel-head"><div><span className="kicker">V9 FREE SALES + LEADS</span><h2>Track leads, customers, and follow-ups</h2></div></div>
              <div className="lead-form-grid">
                <label>Name<input value={leadName} onChange={e=>setLeadName(e.target.value)} placeholder="Jane Smith" /></label>
                <label>Contact<input value={leadContact} onChange={e=>setLeadContact(e.target.value)} placeholder="email, @handle, or phone" /></label>
                <label>Source<select value={leadSource} onChange={e=>setLeadSource(e.target.value)}><option>TikTok</option><option>Instagram</option><option>YouTube</option><option>Referral</option><option>Website</option><option>Other</option></select></label>
                <label>Offer<input value={leadOffer} onChange={e=>setLeadOffer(e.target.value)} placeholder={businessPlan?.offer || "What are you selling?"} /></label>
                <label>Potential value ($)<input inputMode="decimal" value={leadValue} onChange={e=>setLeadValue(e.target.value.replace(/[^0-9.]/g,""))} placeholder="100" /></label>
                <label>Follow-up date<input type="date" value={leadFollowUpDate} onChange={e=>setLeadFollowUpDate(e.target.value)} /></label>
              </div>
              <label className="lead-notes">Notes<textarea value={leadNotes} onChange={e=>setLeadNotes(e.target.value)} placeholder="What did they ask about? What should you remember?" /></label>
              <button className="primary" style={{margin:"0 20px 20px"}} onClick={addLead}>Add lead +</button>
              {error && <div className="error">{error}</div>}
            </section>
            <section className="stat-grid">
              <button className="stat-card" onClick={()=>setLeadFilter("all")}><span>Active leads</span><strong>{salesStats.leads}</strong><small>Open prospects</small></button>
              <button className="stat-card" onClick={()=>setLeadFilter("customer")}><span>Customers</span><strong>{salesStats.customers}</strong><small>Won business</small></button>
              <button className="stat-card" onClick={()=>setLeadFilter("all")}><span>Pipeline value</span><strong>${salesStats.pipeline.toLocaleString()}</strong><small>Potential revenue</small></button>
              <button className="stat-card" onClick={()=>setLeadFilter("all")}><span>Follow-ups due</span><strong>{salesStats.due}</strong><small>Due today or earlier</small></button>
            </section>
            <section className="panel lead-list-panel">
              <div className="panel-head inline-head"><div><span className="kicker">CRM</span><h2>Leads & customers</h2></div><select className="status-select" value={leadFilter} onChange={e=>setLeadFilter(e.target.value as "all"|LeadStatus)}><option value="all">All</option><option value="new">New</option><option value="contacted">Contacted</option><option value="interested">Interested</option><option value="customer">Customer</option><option value="lost">Lost</option></select></div>
              {visibleLeads.length === 0 ? <div className="empty compact"><span>◎</span><p>Add your first prospect above. Your leads stay saved locally on this device.</p></div> : <div className="lead-grid">{visibleLeads.map(lead => <article className="lead-card" key={lead.id}>
                <div className="lead-card-head"><div><h3>{lead.name}</h3><span>{lead.contact || "No contact added"}</span></div><select className="status-select" value={lead.status} onChange={e=>updateLead(lead.id,{status:e.target.value as LeadStatus})}><option value="new">New</option><option value="contacted">Contacted</option><option value="interested">Interested</option><option value="customer">Customer</option><option value="lost">Lost</option></select></div>
                <div className="lead-meta"><span>{lead.source}</span><span>{lead.offer || "No offer"}</span><span>${Number(lead.value||0).toLocaleString()}</span></div>
                <label>Follow-up<input type="date" value={lead.followUpDate} onChange={e=>updateLead(lead.id,{followUpDate:e.target.value})} /></label>
                {lead.notes && <p>{lead.notes}</p>}
                <div className="button-row"><button className="secondary small" onClick={()=>generateLeadFollowup(lead)} disabled={followupLoadingId===lead.id}>{followupLoadingId===lead.id ? "Writing…" : "AI follow-up"}</button><button className="secondary small" onClick={()=>deleteLead(lead.id)}>Delete</button></div>
                {followupDrafts[lead.id] && <div className="followup-draft"><strong>{followupDrafts[lead.id].subject}</strong><p>{followupDrafts[lead.id].message}</p><button className="primary small" onClick={async()=>{try{await navigator.clipboard.writeText(followupDrafts[lead.id].message)}catch{}}}>Copy message</button></div>}
              </article>)}</div>}
            </section>
          </div>
        ) : tab === "Copilot" ? (
          <div className="creator-grid">
            <section className="panel composer">
              <div className="panel-head"><div><span className="kicker">CONTENT COPILOT</span><h2>What should you post next?</h2></div></div>
              <p className="muted">Enter a niche, product, audience, or topic. DRAIG will create five distinct post ideas using your existing Gemini setup.</p>
              <textarea value={copilotTopic} onChange={e => setCopilotTopic(e.target.value)} placeholder="Example: AI tools for small business owners" />
              <div className="controls"><label>Platform<select value={platform} onChange={e=>setPlatform(e.target.value)}><option>TikTok / Reels / Shorts</option><option>TikTok</option><option>Instagram Reels</option><option>YouTube Shorts</option></select></label><label>Tone<select value={tone} onChange={e=>setTone(e.target.value)}><option value="high-energy">High-energy</option><option value="funny">Funny</option><option value="educational">Educational</option><option value="storytelling">Storytelling</option><option value="professional">Professional</option></select></label></div>
              <button className="primary wide" onClick={()=>generateCopilotIdeas()} disabled={copilotLoading || !copilotTopic.trim()}>{copilotLoading ? "Finding ideas…" : "Generate 5 ideas ✦"}</button>
              {error && <div className="error">{error}</div>}
            </section>
            <section className="panel output">
              <div className="panel-head"><div><span className="kicker">IDEA QUEUE</span><h2>Pick your next post</h2></div></div>
              {copilotIdeas.length === 0 ? <div className="empty"><span>✦</span><p>Your next five content ideas will appear here.</p></div> : <div className="saved-grid">{copilotIdeas.map((item,i)=><article className="saved-card" key={`${item.title}-${i}`}><div className="saved-card-top"><span className="kicker">IDEA {i+1}</span></div><h3>{item.title}</h3><p>{item.angle}</p><div className="hook">“{item.hook}”</div><button className="primary wide" onClick={()=>useCopilotIdea(item)}>Turn into full post →</button></article>)}</div>}
            </section>
          </div>
        ) : tab === "Launch Accounts" ? (
          <div className="dashboard-stack">
            <section className="hero-panel"><div><span className="kicker">V8 ACCOUNT LAUNCH ASSISTANT</span><h2>Build a new social brand before you sign up.</h2><p>DRAIG prepares the brand, usernames, bios, profile concept, first-week content, and every setup step. You complete the platform-controlled signup, CAPTCHA, verification, age/identity checks, and acceptance of terms yourself.</p></div>{accountLaunchPlan && <div className="button-row"><button className="secondary" onClick={()=>setTab("Accounts")}>Connect finished accounts</button></div>}</section>
            <section className="panel composer"><div className="panel-head"><div><span className="kicker">1 · BRAND BRIEF</span><h2>What account do you want to launch?</h2></div></div><textarea value={accountLaunchBrief} onChange={e=>setAccountLaunchBrief(e.target.value)} placeholder="Example: A faceless TikTok + Instagram brand about free AI tools and simple money-saving tips for beginners. Friendly, trustworthy, no hype."/><button className="primary wide" onClick={buildAccountLaunch} disabled={accountLaunchLoading || !accountLaunchBrief.trim()}>{accountLaunchLoading ? "Building launch kit…" : "Build my account launch kit ✦"}</button>{error && <div className="error">{error}</div>}</section>
            {!accountLaunchPlan ? <section className="panel empty"><span>✦</span><p>Your full account launch kit will appear here.</p></section> : <>
              <section className="panel"><div className="panel-head inline-head"><div><span className="kicker">BRAND KIT</span><h2>{accountLaunchPlan.brandName}</h2></div><span className="saved-status">{accountLaunchPlan.category}</span></div><div className="settings-list"><div><strong>Audience</strong><span>{accountLaunchPlan.audience}</span></div><div><strong>Positioning</strong><span>{accountLaunchPlan.positioning}</span></div><div><strong>Display name</strong><span>{accountLaunchPlan.displayName}</span></div><div><strong>First-week goal</strong><span>{accountLaunchPlan.firstWeekGoal}</span></div></div></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">USERNAME IDEAS</span><h2>Pick a handle to check on each platform</h2></div></div><p className="muted">These are ideas only. DRAIG does not claim they are available or reserve them.</p><div className="saved-grid">{accountLaunchPlan.usernameIdeas.map((u,i)=><article className="saved-card" key={`${u}-${i}`}><h3>@{u.replace(/^@/,"")}</h3><button className="secondary small" onClick={()=>copyLaunchText(u.replace(/^@/,""))}>Copy</button></article>)}</div></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">PROFILE COPY</span><h2>Paste-ready bios</h2></div></div><div className="saved-grid"><article className="saved-card"><span className="kicker">TIKTOK BIO</span><p>{accountLaunchPlan.tiktokBio}</p><button className="secondary small" onClick={()=>copyLaunchText(accountLaunchPlan.tiktokBio)}>Copy bio</button></article><article className="saved-card"><span className="kicker">INSTAGRAM BIO</span><p>{accountLaunchPlan.instagramBio}</p><button className="secondary small" onClick={()=>copyLaunchText(accountLaunchPlan.instagramBio)}>Copy bio</button></article><article className="saved-card"><span className="kicker">YOUTUBE DESCRIPTION</span><p>{accountLaunchPlan.youtubeDescription}</p><button className="secondary small" onClick={()=>copyLaunchText(accountLaunchPlan.youtubeDescription)}>Copy description</button></article></div><div className="settings-list" style={{marginTop:16}}><div><strong>Profile image prompt</strong><span>{accountLaunchPlan.profileImagePrompt}</span></div><div><strong>Banner prompt</strong><span>{accountLaunchPlan.bannerPrompt}</span></div><div><strong>Link-in-bio text</strong><span>{accountLaunchPlan.linkInBioText}</span></div></div></section>
              <section className="panel"><div className="panel-head inline-head"><div><span className="kicker">2 · CREATE ACCOUNTS</span><h2>Open the official platforms</h2></div><span className="muted">Human signup required</span></div><div className="button-row"><a className="primary" href="https://www.tiktok.com/signup" target="_blank" rel="noreferrer">Open TikTok signup ↗</a><a className="primary" href="https://www.instagram.com/accounts/emailsignup/" target="_blank" rel="noreferrer">Open Instagram signup ↗</a><a className="primary" href="https://www.youtube.com/" target="_blank" rel="noreferrer">Open YouTube ↗</a></div><p className="muted">For your security, DRAIG never enters passwords, verification codes, CAPTCHAs, identity documents, or accepts platform terms for you.</p></section>
              <section className="panel"><div className="panel-head inline-head"><div><span className="kicker">SETUP CHECKLIST</span><h2>{accountLaunchCompleted.length}/{accountLaunchPlan.launchChecklist.length} steps complete</h2></div></div><div className="saved-grid">{accountLaunchPlan.launchChecklist.map((step,i)=><article className="saved-card" key={`${step.title}-${i}`}><div className="saved-card-top"><span className="kicker">{step.platform}</span><span className="saved-status">{step.humanRequired ? "YOU DO THIS" : "GUIDED"}</span></div><h3>{step.title}</h3><p>{step.instruction}</p><button className={accountLaunchCompleted.includes(i) ? "secondary wide" : "primary wide"} onClick={()=>toggleAccountLaunchStep(i)}>{accountLaunchCompleted.includes(i) ? "✓ Completed" : "Mark complete"}</button></article>)}</div></section>
              <section className="panel"><div className="panel-head"><div><span className="kicker">FIRST 7 POSTS</span><h2>Launch-week content plan</h2></div></div><div className="saved-grid">{accountLaunchPlan.first7Posts.map((post,i)=><article className="saved-card" key={`${post.day}-${i}`}><div className="saved-card-top"><span className="kicker">{post.day}</span><span className="saved-status">{post.platform}</span></div><h3>{post.title}</h3><div className="hook">“{post.hook}”</div><p>{post.goal}</p><button className="primary wide" onClick={()=>{setIdea(`${post.title}. Hook: ${post.hook}. Goal: ${post.goal}`);setPlatform(post.platform);setTab("Create");}}>Create this post →</button></article>)}</div></section>
              <section className="panel placeholder"><div className="panel-head"><div><span className="kicker">SAFETY</span><h2>Human-only signup steps stay human</h2></div></div><div className="settings-list">{accountLaunchPlan.safetyNotes.map((note,i)=><div key={i}><strong>Guardrail {i+1}</strong><span>{note}</span></div>)}</div></section>
            </>}
          </div>
        ) : tab === "Inbox" ? (
          <div className="dashboard-stack">
            <section className="hero-panel"><div><span className="kicker">V8 INSTAGRAM INBOX</span><h2>Reply to real Instagram conversations with approval.</h2><p>DRAIG can sync conversations from your connected Instagram Professional account and send replies only to people who already messaged your account. It will not cold-DM strangers.</p></div><button className="primary" onClick={loadInstagramConversations} disabled={instagramLoading}>{instagramLoading ? "Syncing…" : "Refresh inbox"}</button></section>
            {!accounts.some(a=>a.platform==="instagram" && a.connected) ? <section className="panel"><div className="error">Connect an Instagram Professional account in Accounts first.</div><button className="primary" onClick={()=>setTab("Accounts")}>Open Accounts</button></section> : <section className="panel library-panel"><div className="panel-head inline-head"><div><span className="kicker">CONVERSATIONS</span><h2>Instagram messages</h2></div><span className="muted">{instagramConversations.length} conversations</span></div>{instagramMessageStatus && <div className={instagramMessageStatus.toLowerCase().includes("sent") ? "success" : "error compact-error"}>{instagramMessageStatus}</div>}{instagramLoading ? <div className="empty compact"><span>◎</span><p>Loading Instagram conversations…</p></div> : instagramConversations.length===0 ? <div className="empty compact"><span>◎</span><p>No conversations returned yet. Instagram messaging only supports people who have already contacted the professional account.</p></div> : <div className="saved-grid">{instagramConversations.map(convo=>{ const recipient=instagramRecipient(convo); const messages=convo.messages?.data || []; const latest=messages[0]; return <article className="saved-card" key={convo.id}><div className="saved-card-top"><span className="kicker">INSTAGRAM</span><span className="saved-status">{convo.updated_time ? new Date(convo.updated_time).toLocaleString() : "conversation"}</span></div><h3>{recipient?.username ? `@${recipient.username}` : recipient?.name || "Instagram user"}</h3><p>{latest?.message || "Media or conversation activity"}</p><label>Approved reply<textarea value={instagramReplyDrafts[convo.id] || ""} onChange={e=>setInstagramReplyDrafts(prev=>({...prev,[convo.id]:e.target.value}))} placeholder="Write or paste the reply you want DRAIG to send." /></label><button className="primary wide" disabled={instagramSendingId===convo.id || !(instagramReplyDrafts[convo.id] || "").trim()} onClick={()=>sendInstagramReply(convo)}>{instagramSendingId===convo.id ? "Sending…" : "Approve & send reply"}</button></article>})}</div>}</section>}
            <section className="panel placeholder"><div className="panel-head"><div><span className="kicker">MESSAGE GUARDRAILS</span><h2>What V7 will and will not send</h2></div></div><div className="settings-list"><div><strong>Instagram</strong><span>Can reply through Meta's official API after you approve the exact message, when the recipient already initiated a conversation.</span></div><div><strong>TikTok</strong><span>Publishing is supported through TikTok's Content Posting API. TikTok does not provide a general outbound DM API for this use case, so DRAIG keeps TikTok DMs manual.</span></div><div><strong>Approval</strong><span>No real message is sent from this inbox until you press Approve & send reply.</span></div></div></section>
          </div>
        ) : tab === "Accounts" ? (
          <div className="panel accounts-panel"><div className="panel-head"><div><span className="kicker">V8 SOCIAL CONNECTIONS</span><h2>Connect real publishing accounts</h2></div></div><div className="success">The free manual Publish Assistant still works with no developer accounts. Connecting official developer apps unlocks direct execution without paying DRAIG.</div><p className="muted">TikTok Direct Post requires Content Posting API approval. Instagram direct publishing/messaging requires an Instagram Professional account linked to a Facebook Page and the Meta permissions requested during OAuth.</p><div className="account-grid">{["tiktok","instagram","youtube"].map(p => { const a=accounts.find(x=>x.platform===p); const label=p === "tiktok" ? "TikTok" : p === "instagram" ? "Instagram" : "YouTube"; const profile=a?.profile?.username ? `@${a.profile.username}` : a?.profile?.display_name || a?.profile?.snippet?.title || a?.profile?.name || ""; return <div className="account-card" key={p}><div><strong>{label}</strong><span>{a?.connected ? (profile || "Connected") : "Not connected"}</span></div>{a?.connected ? <div style={{display:"flex",gap:10,alignItems:"center"}}><span className="connected">● Connected</span><button className="secondary small" onClick={() => disconnectAccount(p)} disabled={disconnecting === p}>{disconnecting === p ? "Disconnecting…" : "Disconnect"}</button></div> : <a className="primary small" href={`/api/oauth/${p}/start`}>Connect</a>}</div>})}</div><div className="settings-list" style={{marginTop:18}}><div><strong>TikTok setup</strong><span>Add TIKTOK_CLIENT_KEY and TIKTOK_CLIENT_SECRET, register the callback URL, enable Login Kit + Content Posting API, and request video.publish.</span></div><div><strong>Instagram setup</strong><span>Add META_APP_ID and META_APP_SECRET, use a Business/Creator Instagram account linked to a Facebook Page, and configure the Instagram webhook if you want inbound event capture.</span></div></div></div>
        ) : tab === "Create" ? (
          <div className="creator-grid">
            <section className="panel composer">
              <div className="panel-head"><div><span className="kicker">1 · IDEA</span><h2>What should we create?</h2></div></div>
              <textarea value={idea} onChange={e => setIdea(e.target.value)} placeholder="Example: 3 AI tools that can save a small business owner 5 hours every week" />
              <div className="controls">
                <label>Platform<select value={platform} onChange={e => setPlatform(e.target.value)}><option>TikTok / Reels / Shorts</option><option>TikTok</option><option>Instagram Reels</option><option>YouTube Shorts</option></select></label>
                <label>Tone<select value={tone} onChange={e => setTone(e.target.value)}><option value="high-energy">High-energy</option><option value="funny">Funny</option><option value="educational">Educational</option><option value="storytelling">Storytelling</option><option value="professional">Professional</option></select></label>
              </div>
              <button className="primary wide" onClick={()=>generateContent()} disabled={loading || !idea.trim()}>{loading ? "Creating package…" : "Generate content ✦"}</button>
              {error && <div className="error">{error}</div>}
            </section>

            <section className="panel output">
              <div className="panel-head"><div><span className="kicker">2 · AI PACKAGE</span><h2>Your content</h2></div></div>
              {!result ? <div className="empty"><span>✦</span><p>Your script, caption, hashtags and shot list will appear here.</p></div> : <div className="result">
                <h3>{result.title}</h3><div className="hook">“{result.hook}”</div>{result.aiModel && <div className="muted" style={{marginBottom: 14}}>Powered by {result.aiProvider} · {result.aiModel}</div>}
                <label>Script<textarea value={result.script} readOnly /></label>
                <div className="two"><div><label>Caption<textarea value={result.caption} readOnly /></label></div><div><label>CTA<textarea value={result.callToAction} readOnly /></label></div></div>
                <div><label>Hashtags<div className="tags">{result.hashtags.map(h => <span key={h}>{h}</span>)}</div></label></div>
                <div><label>Visual plan<ol>{result.visualPlan.map((s,i)=><li key={i}>{s}</li>)}</ol></label></div>
                <div className="button-row"><button className="secondary wide" onClick={saveCurrentPost}>Save to Library</button><button className="primary wide" onClick={createVideo} disabled={videoLoading}>{videoLoading ? "Preparing free video…" : "Create free video with HeyGen 🎬"}</button></div>
                {video && <div className="video-job"><strong>{video.status === "ready-to-create" ? "Free video ready" : video.status === "ready-local" ? "Finished video saved locally" : `Video status: ${video.status}`}</strong><p>{video.error}</p>{video.status === "ready-to-create" && heygenPrompt && <><div className="button-row"><button className="secondary wide" onClick={copyHeygenPrompt}>Copy HeyGen prompt</button><button className="primary wide" onClick={() => window.open("https://app.heygen.com/", "_blank", "noopener,noreferrer")}>Open HeyGen ↗</button></div><label>HeyGen prompt<textarea value={heygenPrompt} readOnly /></label></>}{video.videoUrl && <video src={video.videoUrl} controls playsInline />}</div>}
                {video?.status === "ready-to-create" && <div className="finish-box"><span className="kicker">3 · VIDEO READY</span><h3>Bring your finished HeyGen video back</h3><p className="muted">Free mode keeps uploaded video files on this device. If HeyGen gives you a public video URL, save that URL to enable publishing through connected accounts.</p><label className="file-picker">Attach finished video<input type="file" accept="video/*" onChange={e => attachFinishedVideo(e.target.files?.[0] || null)} /></label><div className="url-row"><input value={finishedVideoUrl} onChange={e => setFinishedVideoUrl(e.target.value)} placeholder="https://public-video-url..."/><button className="secondary" onClick={saveFinishedVideoUrl}>Save video URL</button></div></div>}
                {video?.status === "ready-local" && <div className="finish-box"><span className="kicker">READY LOCALLY</span><h3>{video.fileName || "Finished video"}</h3><p className="muted">This file is saved free on this device. To publish through DRAIG, paste a public URL for the finished video.</p><div className="url-row"><input value={finishedVideoUrl} onChange={e => setFinishedVideoUrl(e.target.value)} placeholder="https://public-video-url..."/><button className="secondary" onClick={saveFinishedVideoUrl}>Add public URL</button></div></div>}
                {video?.videoUrl && <div className="publish-box"><span className="kicker">4 · FREE PUBLISH ASSISTANT</span><h3>Publish without a paid posting service</h3><p className="muted">Copy your caption, save or open the finished video, then open the social platform and upload it yourself. This path does not require TikTok, Meta, or YouTube developer credentials.</p><div className="button-row"><button className="secondary wide" onClick={copyPublishCaption}>Copy caption + hashtags</button><button className="secondary wide" onClick={saveVideoToDevice}>{video.localFile ? "Save / open video" : "Download / open video"}</button></div><div className="button-row"><button className="primary wide" onClick={() => openManualPublisher("tiktok")}>Open TikTok ↗</button><button className="primary wide" onClick={() => openManualPublisher("instagram")}>Open Instagram ↗</button><button className="primary wide" onClick={() => openManualPublisher("youtube")}>Open YouTube ↗</button></div>{publishResult?.manual && <div className="success">{publishResult.message}</div>}</div>}
                {video?.videoUrl && !video.localFile && accounts.some(a=>a.connected) && <div className="publish-box"><span className="kicker">V7 · DIRECT EXECUTION</span><h3>Publish through the platform's official API</h3><p className="muted">Review the final media, caption, account, disclosure settings, and privacy before approval. TikTok requires fresh creator settings and may keep unaudited app posts private until app review is complete.</p><div className="controls"><label>Account<select value={publishPlatform} onChange={e=>{setPublishPlatform(e.target.value);setPublishConsent(false);}}>{accounts.filter(a=>a.connected).map(a=><option key={a.platform} value={a.platform}>{a.platform}</option>)}</select></label>{publishPlatform === "tiktok" && <label>Privacy<select value={privacyLevel} onChange={e=>setPrivacyLevel(e.target.value)}><option value="">Select privacy…</option>{(creatorInfo?.privacy_level_options || []).map((x:string)=><option key={x}>{x}</option>)}</select></label>}</div>{publishPlatform === "tiktok" && creatorInfo && <div className="success">Posting as {creatorInfo.creator_nickname || "connected TikTok creator"}. Available privacy: {(creatorInfo.privacy_level_options || []).join(", ") || "none returned"}.</div>}<div className="approval-checks"><label><input type="checkbox" checked={isAigc} onChange={e=>setIsAigc(e.target.checked)} /> AI-generated content</label><label><input type="checkbox" checked={promotesOwnBusiness} onChange={e=>setPromotesOwnBusiness(e.target.checked)} /> Promotes my own business</label><label><input type="checkbox" checked={paidPartnership} onChange={e=>setPaidPartnership(e.target.checked)} /> Paid partnership / branded content</label><label><input type="checkbox" checked={publishConsent} onChange={e=>setPublishConsent(e.target.checked)} /> I reviewed this post and approve publishing it to the selected real account.</label></div><button className="primary wide" onClick={()=>publishVideo(false)} disabled={publishing || !publishConsent || (publishPlatform === "tiktok" && !privacyLevel)}>{publishing ? "Publishing…" : "Approve & publish 🚀"}</button>{publishResult && !publishResult.manual && <div className="success">{publishResult.published ? "Published successfully." : publishResult.pending ? "Platform accepted the post and processing is still underway." : "Publish request accepted."}{tiktokPublishId ? ` TikTok publish ID: ${tiktokPublishId}` : ""}{publishResult.status?.status ? ` Status: ${publishResult.status.status}` : ""}</div>}{tiktokPublishId && <button className="secondary wide" onClick={checkTikTokPublishStatus}>Check TikTok publish status</button>}</div>}
              </div>}
            </section>
          </div>
        ) : tab === "Videos" ? (
          <div className="panel library-panel"><div className="panel-head inline-head"><div><span className="kicker">CONTENT LIBRARY</span><h2>Saved posts</h2></div><span className="muted">{filteredPosts.length} of {savedPosts.length}</span></div>
            <div className="library-tools"><input value={libraryQuery} onChange={e => setLibraryQuery(e.target.value)} placeholder="Search title, idea, hook…"/><select value={libraryFilter} onChange={e => setLibraryFilter(e.target.value)}><option value="all">All statuses</option><option value="draft">Draft</option><option value="ready">Ready</option><option value="published">Published</option></select></div>
            {filteredPosts.length === 0 ? <div className="empty"><span>✦</span><p>{savedPosts.length ? "No saved posts match your search." : "Save a generated package from Create and it will stay in this browser."}</p></div> : <div className="saved-grid">{filteredPosts.map(post => <article className="saved-card" key={post.id}><div className="saved-card-top"><span className="kicker">{post.platform}</span><select className="status-select" value={post.status} onChange={e => updateSavedPost(post, {status: e.target.value as SavedPost["status"]})}><option value="draft">draft</option><option value="ready">ready</option><option value="published">published</option></select></div><h3>{post.title}</h3><p>{post.hook}</p><div className="saved-meta">{new Date(post.createdAt).toLocaleDateString()} · {post.tone}</div><div className="button-row"><button className="primary small" onClick={() => openSavedPost(post)}>Open</button><button className="secondary small" onClick={() => duplicateSavedPost(post)}>Duplicate</button><button className="secondary small" onClick={() => deleteSavedPost(post.id)}>Delete</button></div></article>)}</div>}
          </div>
        ) : tab === "Calendar" ? (
          <div className="panel library-panel"><div className="panel-head inline-head"><div><span className="kicker">FREE PLANNER</span><h2>Content calendar</h2></div><span className="muted">Local only</span></div><p className="muted calendar-note">Pick a date for each saved post. This is a planning calendar only; it does not run background jobs or claim to auto-publish.</p><div className="calendar-list">{savedPosts.length === 0 ? <div className="empty compact"><span>✦</span><p>Save content first, then plan when to publish it.</p></div> : savedPosts.map(post => <article className="calendar-row" key={post.id}><div><strong>{post.title}</strong><span>{post.platform} · {post.status}</span></div><input type="date" value={scheduleDates[post.id] || ""} onChange={e => setScheduleDates({...scheduleDates, [post.id]: e.target.value})}/><button className="secondary small" onClick={() => openSavedPost(post)}>Open</button></article>)}</div></div>
        ) : tab === "Analytics" ? (
          <div className="dashboard-stack">
            <section className="hero-panel"><div><span className="kicker">FINAL ANALYTICS + OPTIMIZATION ENGINE</span><h2>Teach DRAIG what actually works.</h2><p>Record real performance from posts, campaigns, or offers. DRAIG calculates conversion metrics and uses Gemini to recommend the next experiment. It never invents platform analytics you did not provide.</p></div><button className="primary" onClick={runOptimization} disabled={optimizationLoading || performanceMetrics.length===0}>{optimizationLoading ? "Analyzing…" : "Optimize business ✦"}</button></section>
            <section className="stat-grid">
              <div className="stat-card"><span>CTR</span><strong>{clickRate.toFixed(1)}%</strong><small>{metricTotals.clicks.toLocaleString()} clicks / {metricTotals.impressions.toLocaleString()} impressions</small></div>
              <div className="stat-card"><span>Lead rate</span><strong>{leadRate.toFixed(1)}%</strong><small>{metricTotals.leads} leads</small></div>
              <div className="stat-card"><span>Close rate</span><strong>{closeRate.toFixed(1)}%</strong><small>{metricTotals.sales} sales</small></div>
              <div className="stat-card"><span>Avg. order value</span><strong>${avgOrderValue.toFixed(2)}</strong><small>From tracked outcomes</small></div>
            </section>
            <section className="panel"><div className="panel-head"><div><span className="kicker">RECORD A REAL OUTCOME</span><h2>Add performance data</h2></div></div><div className="form-grid">
              <label>Channel<select value={metricChannel} onChange={e=>setMetricChannel(e.target.value)}><option>TikTok</option><option>Instagram</option><option>YouTube</option><option>Email</option><option>Website</option><option>Other</option></select></label>
              <label>Campaign / post<input value={metricCampaign} onChange={e=>setMetricCampaign(e.target.value)} placeholder="Post or campaign name" /></label>
              <label>Impressions<input inputMode="numeric" value={metricImpressions} onChange={e=>setMetricImpressions(e.target.value)} placeholder="0" /></label>
              <label>Clicks<input inputMode="numeric" value={metricClicks} onChange={e=>setMetricClicks(e.target.value)} placeholder="0" /></label>
              <label>Leads<input inputMode="numeric" value={metricLeads} onChange={e=>setMetricLeads(e.target.value)} placeholder="0" /></label>
              <label>Sales<input inputMode="numeric" value={metricSales} onChange={e=>setMetricSales(e.target.value)} placeholder="0" /></label>
              <label>Revenue<input inputMode="decimal" value={metricRevenue} onChange={e=>setMetricRevenue(e.target.value)} placeholder="0.00" /></label>
              <label>Date<input type="date" value={metricDate} onChange={e=>setMetricDate(e.target.value)} /></label>
              <label className="wide">Notes<input value={metricNotes} onChange={e=>setMetricNotes(e.target.value)} placeholder="What changed, hook, offer, audience…" /></label>
            </div><button className="primary" onClick={addPerformanceMetric}>Save outcome</button></section>
            <section className="panel library-panel"><div className="panel-head inline-head"><div><span className="kicker">EXECUTION FEEDBACK</span><h2>Actions feeding the learning loop</h2></div><span className="muted">{executionLog.filter(x=>x.status==="completed").length} completed</span></div>{executionLog.length===0?<div className="empty compact"><span>◎</span><p>V7 execution results will appear here without inventing performance metrics.</p></div>:<div className="calendar-list">{executionLog.filter(x=>x.status!=="running").slice(0,10).map(x=><article className="calendar-row" key={x.id}><div><strong>{x.title}</strong><span>{x.status} · {x.message}</span></div></article>)}</div>}</section>
            {optimizationAdvice && <section className="panel"><div className="panel-head"><div><span className="kicker">AI OPTIMIZATION</span><h2>{optimizationAdvice.summary}</h2></div></div><h3>What is working</h3><ul>{optimizationAdvice.working.map((x,i)=><li key={i}>{x}</li>)}</ul><h3>What to improve</h3><ul>{optimizationAdvice.improve.map((x,i)=><li key={i}>{x}</li>)}</ul><div className="success"><strong>Next experiment:</strong> {optimizationAdvice.nextExperiment}</div><h3>Actions</h3><ol>{optimizationAdvice.actions.map((x,i)=><li key={i}>{x}</li>)}</ol></section>}
            <section className="panel library-panel"><div className="panel-head inline-head"><div><span className="kicker">OUTCOME LOG</span><h2>Tracked performance</h2></div><span className="muted">{performanceMetrics.length} records</span></div>{performanceMetrics.length===0 ? <div className="empty compact"><span>✦</span><p>Add real results from a post, campaign, or offer to start the learning loop.</p></div> : <div className="calendar-list">{performanceMetrics.map(m=><article className="calendar-row" key={m.id}><div><strong>{m.campaign}</strong><span>{m.channel} · {m.date} · {m.sales} sales · ${m.revenue.toFixed(2)}</span></div><button className="secondary small" onClick={()=>deletePerformanceMetric(m.id)}>Delete</button></article>)}</div>}</section>
          </div>
        ) : tab === "Settings" ? (
          <><div className="panel"><div className="panel-head inline-head"><div><span className="kicker">V8 FREE ACCOUNT LAUNCH + SOCIAL EXECUTION</span><h2>Launch Status</h2></div><button className="primary small" onClick={checkLaunchHealth} disabled={launchHealthLoading}>{launchHealthLoading ? "Checking…" : "Run launch check"}</button></div>{!launchHealth ? <p className="muted">Check the core free launch stack plus optional TikTok/Instagram connectors without exposing secret values.</p> : <><div className={launchHealth.ready ? "success" : "error compact-error"}>{launchHealth.message}</div><div className="stat-grid"><div className="stat-card"><span>Gemini</span><strong>{launchHealth.env.gemini ? "READY" : "MISSING"}</strong><small>{launchHealth.model}</small></div><div className="stat-card"><span>Neon</span><strong>{launchHealth.database.reachable ? "READY" : launchHealth.env.database ? "ERROR" : "MISSING"}</strong><small>{launchHealth.database.cloudStateFound ? "Cloud state found" : "Cloud state check"}</small></div><div className="stat-card"><span>Security</span><strong>{launchHealth.env.ownerKey && launchHealth.env.cronSecret && launchHealth.env.sessionSecret ? "READY" : "CHECK"}</strong><small>Owner + cron + session secrets</small></div><div className="stat-card"><span>Autopilot</span><strong>{launchHealth.env.cronSecret ? "DAILY" : "CHECK"}</strong><small>12:00 UTC free schedule</small></div></div>{launchHealth.social && <div className="stat-grid" style={{marginTop:12}}><div className="stat-card"><span>TikTok API</span><strong>{launchHealth.social.tiktokConfigured ? "CONFIGURED" : "OPTIONAL"}</strong><small>Direct Post connector</small></div><div className="stat-card"><span>Instagram API</span><strong>{launchHealth.social.instagramConfigured ? "CONFIGURED" : "OPTIONAL"}</strong><small>Reels + replies</small></div><div className="stat-card"><span>IG Webhook</span><strong>{launchHealth.social.instagramWebhookConfigured ? "CONFIGURED" : "OPTIONAL"}</strong><small>Inbound event capture</small></div><div className="stat-card"><span>YouTube API</span><strong>{launchHealth.social.youtubeConfigured ? "CONFIGURED" : "OPTIONAL"}</strong><small>Private upload connector</small></div></div>}<p className="muted">APP_URL: {launchHealth.env.appUrl ? "configured" : "missing"} · Version {launchHealth.version}</p></>}</div><div className="panel"><div className="panel-head"><div><span className="kicker">FINAL CLOUD BUSINESS OS</span><h2>Keep DRAIG working when you close the app</h2></div></div><div className="form-grid"><label>Owner key<input type="password" value={cloudOwnerKey} onChange={e=>setCloudOwnerKey(e.target.value)} placeholder="Same value as SOCIALPILOT_OWNER_KEY" /></label><div className="button-row"><button className="primary" onClick={connectCloud} disabled={cloudBusy}>{cloudBusy ? "Syncing…" : "Connect & load cloud"}</button><button className="secondary" onClick={()=>pullCloudState()} disabled={cloudBusy || !cloudOwnerKey}>Load cloud state</button></div></div><div className={cloudStatus === "Cloud connected" ? "success" : "muted"}>{cloudStatus}{lastCloudSync ? ` · Last sync ${lastCloudSync}` : ""}</div><p className="muted">Your database URL and cron secret stay on the server. Only your owner key is entered here, and it is saved on this device so your private cloud state can be loaded.</p></div><div className="panel placeholder"><div className="panel-head"><div><span className="kicker">CONFIGURATION</span><h2>DRAIG settings</h2></div></div><div className="settings-list"><div><strong>Cloud persistence</strong><span>Neon Postgres keeps your business plan, leads, content metadata, and Autopilot queue and V8 execution history online instead of only in this browser.</span></div><div><strong>Scheduled Autopilot</strong><span>Vercel runs the cloud Autopilot route once per day on the free Hobby schedule when Autopilot is ON.</span></div><div><strong>Approval center</strong><span>Publishing, contacting real people, spending money, account changes, destructive actions, and legal/financial actions remain approval-gated.</span></div><div><strong>Video files</strong><span>Large local video files remain on your device in free mode; their content records and public URLs can still sync to cloud state.</span></div></div></div></>
        ) : (
          <div className="panel placeholder"><div className="panel-head"><div><span className="kicker">NEXT MODULE</span><h2>{tab}</h2></div></div><p className="muted">This workspace is ready for the next DRAIG module.</p></div>
        )}
      </section>
    </main>
  );
}
